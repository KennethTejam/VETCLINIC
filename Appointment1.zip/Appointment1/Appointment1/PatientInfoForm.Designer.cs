﻿namespace Appointment1
{
    partial class PatientInfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Label_OwnerName = new Label();
            Label_PetName = new Label();
            Label_Breed = new Label();
            Label_Age = new Label();
            Label_Gender = new Label();
            Label_Contact = new Label();
            Label_Email = new Label();
            Label_AppointmentDate = new Label();
            Label_AppointmentTime = new Label();
            Label_Status = new Label();
            SuspendLayout();
            // 
            // Label_OwnerName
            // 
            Label_OwnerName.AutoSize = true;
            Label_OwnerName.BackColor = Color.Transparent;
            Label_OwnerName.Location = new Point(67, 81);
            Label_OwnerName.Name = "Label_OwnerName";
            Label_OwnerName.Size = new Size(38, 15);
            Label_OwnerName.TabIndex = 10;
            Label_OwnerName.Text = "label1";
            // 
            // Label_PetName
            // 
            Label_PetName.AutoSize = true;
            Label_PetName.BackColor = Color.Transparent;
            Label_PetName.Location = new Point(67, 113);
            Label_PetName.Name = "Label_PetName";
            Label_PetName.Size = new Size(38, 15);
            Label_PetName.TabIndex = 11;
            Label_PetName.Text = "label2";
            Label_PetName.Click += Label_PetName_Click;
            // 
            // Label_Breed
            // 
            Label_Breed.AutoSize = true;
            Label_Breed.BackColor = Color.Transparent;
            Label_Breed.Location = new Point(67, 149);
            Label_Breed.Name = "Label_Breed";
            Label_Breed.Size = new Size(38, 15);
            Label_Breed.TabIndex = 12;
            Label_Breed.Text = "label3";
            // 
            // Label_Age
            // 
            Label_Age.AutoSize = true;
            Label_Age.BackColor = Color.Transparent;
            Label_Age.Location = new Point(382, 79);
            Label_Age.Name = "Label_Age";
            Label_Age.Size = new Size(38, 15);
            Label_Age.TabIndex = 13;
            Label_Age.Text = "label4";
            // 
            // Label_Gender
            // 
            Label_Gender.AutoSize = true;
            Label_Gender.BackColor = Color.Transparent;
            Label_Gender.Location = new Point(382, 113);
            Label_Gender.Name = "Label_Gender";
            Label_Gender.Size = new Size(38, 15);
            Label_Gender.TabIndex = 14;
            Label_Gender.Text = "label5";
            // 
            // Label_Contact
            // 
            Label_Contact.AutoSize = true;
            Label_Contact.BackColor = Color.Transparent;
            Label_Contact.Location = new Point(382, 149);
            Label_Contact.Name = "Label_Contact";
            Label_Contact.Size = new Size(38, 15);
            Label_Contact.TabIndex = 15;
            Label_Contact.Text = "label6";
            // 
            // Label_Email
            // 
            Label_Email.AutoSize = true;
            Label_Email.BackColor = Color.Transparent;
            Label_Email.Location = new Point(67, 270);
            Label_Email.Name = "Label_Email";
            Label_Email.Size = new Size(38, 15);
            Label_Email.TabIndex = 16;
            Label_Email.Text = "label7";
            Label_Email.Click += Label_Email_Click;
            // 
            // Label_AppointmentDate
            // 
            Label_AppointmentDate.AutoSize = true;
            Label_AppointmentDate.BackColor = Color.Transparent;
            Label_AppointmentDate.Location = new Point(67, 300);
            Label_AppointmentDate.Name = "Label_AppointmentDate";
            Label_AppointmentDate.Size = new Size(38, 15);
            Label_AppointmentDate.TabIndex = 17;
            Label_AppointmentDate.Text = "label8";
            // 
            // Label_AppointmentTime
            // 
            Label_AppointmentTime.AutoSize = true;
            Label_AppointmentTime.BackColor = Color.Transparent;
            Label_AppointmentTime.Location = new Point(67, 330);
            Label_AppointmentTime.Name = "Label_AppointmentTime";
            Label_AppointmentTime.Size = new Size(38, 15);
            Label_AppointmentTime.TabIndex = 18;
            Label_AppointmentTime.Text = "label9";
            // 
            // Label_Status
            // 
            Label_Status.AutoSize = true;
            Label_Status.BackColor = Color.Transparent;
            Label_Status.Location = new Point(67, 360);
            Label_Status.Name = "Label_Status";
            Label_Status.Size = new Size(44, 15);
            Label_Status.TabIndex = 19;
            Label_Status.Text = "label10";
            // 
            // PatientInfoForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(704, 441);
            Controls.Add(Label_Status);
            Controls.Add(Label_AppointmentTime);
            Controls.Add(Label_AppointmentDate);
            Controls.Add(Label_Email);
            Controls.Add(Label_Contact);
            Controls.Add(Label_Gender);
            Controls.Add(Label_Age);
            Controls.Add(Label_Breed);
            Controls.Add(Label_PetName);
            Controls.Add(Label_OwnerName);
            Name = "PatientInfoForm";
            Text = "PatientInfoForm";
            Load += PatientInfoForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label Label_OwnerName;
        private Label Label_PetName;
        private Label Label_Breed;
        private Label Label_Age;
        private Label Label_Gender;
        private Label Label_Contact;
        private Label Label_Email;
        private Label Label_AppointmentDate;
        private Label Label_AppointmentTime;
        private Label Label_Status;
    }
}