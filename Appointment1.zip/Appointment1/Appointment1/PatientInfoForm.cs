﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Appointment1
{
    public partial class PatientInfoForm : Form
    {
        PROCESSES process = new PROCESSES();
        private string connString;
        private int appID;
        PrivateFontCollection privateFonts;
        PrivateFontCollection privateFontsbold;
        Font poppinsFont;
        Font poppinsFontlinklabel;
        Font poppinsFontcal;
        Font monthtext;
        public PatientInfoForm(int appID)
        {
            this.appID = appID;
            this.BackColor = Color.FromArgb(218, 177, 126);
            InitializeComponent();
            connString = process.getStringConnection();
            FetchAndDisplayAppointments();
            setFont();
        }
        // Store appID to fetch the pet's record from the database


        // Constructor accepts appID to load the pet's record

        // Fetch and display appointments

        public void setFont()
        {
            privateFonts = new PrivateFontCollection();
            privateFontsbold = new PrivateFontCollection();
            privateFonts.AddFontFile("C:\\Users\\John\\source\\repos\\Appointment1\\Appointment1\\bin\\Debug\\net8.0-windows\\FONTS\\Poppins-Regular.ttf");
            privateFontsbold.AddFontFile("C:\\Users\\John\\source\\repos\\Appointment1\\Appointment1\\bin\\Debug\\net8.0-windows\\FONTS\\Poppins-ExtraBold.ttf");
            poppinsFont = new Font(privateFontsbold.Families[0], 55f);
            poppinsFontlinklabel = new Font(privateFonts.Families[0], 12f);
            poppinsFontcal = new Font(privateFonts.Families[0], 9f);
            monthtext = new Font(privateFonts.Families[0], 12f);
            ///
            ///
            ///
            ///
            ///
            Label_OwnerName.Font = monthtext;
            Label_PetName.Font = monthtext;
            Label_Breed.Font = monthtext;
            Label_Age.Font = monthtext;
            Label_Gender.Font = monthtext;
            Label_Contact.Font = monthtext;
            Label_Email.Font = monthtext;
            Label_AppointmentDate.Font = monthtext;
            Label_AppointmentTime.Font = monthtext;
            Label_Status.Font = monthtext;

        }
        private void FetchAndDisplayAppointments()
        {
            FetchAndAssignAppointmentDetails();
        }

        public void FetchAndAssignAppointmentDetails()
        {
            using (SqlConnection connection = new SqlConnection(connString))
            {
                string query = "SELECT oname, pname, breed, birthday, gender, contactNo, email, FORMAT(appDate, 'dddd, MMMM dd, yyyy') AS appDate ,CONVERT(VARCHAR, appTime, 100) AS appTime, status FROM appointments WHERE appID = @appID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@appID", appID);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // Fetch individual columns from the database
                        string ownerName = reader["oname"]?.ToString() ?? "N/A";
                        string petName = reader["pname"]?.ToString() ?? "N/A";
                        string breed = reader["breed"]?.ToString() ?? "N/A";
                        DateTime birthday = reader["birthday"] != DBNull.Value ? Convert.ToDateTime(reader["birthday"]) : DateTime.MinValue;
                        string gender = reader["gender"]?.ToString() ?? "N/A";
                        string contactNo = reader["contactNo"]?.ToString() ?? "N/A";
                        string email = reader["email"]?.ToString() ?? "N/A";
                        string appDate = reader["appDate"]?.ToString() ?? "N/A";
                        string appTime = reader["apptime"]?.ToString() ?? "N/A";
                        string status = reader["status"]?.ToString() ?? "N/A";

                        // Calculate age from birthday
                        int age = CalculateAge(birthday);

                        // Assign values to labels
                        Label_OwnerName.Text = $"Owner: {ownerName}";
                        Label_PetName.Text = $"Pet: {petName}";
                        Label_Breed.Text = $"Breed: {breed}";
                        Label_Age.Text = $"Age: {age}";
                        Label_Gender.Text = $"Gender: {gender}";
                        Label_Contact.Text = $"Contact: {contactNo}";
                        Label_Email.Text = $"Email: {email}";
                        Label_AppointmentDate.Text = $"Apt Date: {appDate}";
                        Label_AppointmentTime.Text = $"Apt Time: {appTime}";
                        Label_Status.Text = $"Apt Status: {status}";
                    }
                    else
                    {
                        MessageBox.Show("No records found.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error fetching appointment details: " + ex.Message);
                }
            }
        }

        // Method to calculate age from the birthday
        private int CalculateAge(DateTime birthday)
        {
            int age = DateTime.Now.Year - birthday.Year;
            if (DateTime.Now.DayOfYear < birthday.DayOfYear)
            {
                age--;
            }
            return age;
        }

        private void PatientInfoForm_Load(object sender, EventArgs e)
        {

        }



        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Rectangle rectangle = new Rectangle(0, 0, 1080, 50); // X, Y, Width, Height

            // Create a semi-transparent brush
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(151, 97, 51))) // 128 = 50% opacity, Green color
            {
                // Draw the rectangle in the specified position
                e.Graphics.FillRectangle(brush, rectangle);
            }

            Rectangle rectangle2 = new Rectangle(50, 60, 600, 150); // X, Y, Width, Height
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(255, 245, 233))) // 128 = 50% opacity, Green color
            {

                e.Graphics.FillRectangle(brush, rectangle2);
            }

            Rectangle rectangle3 = new Rectangle(50, 250, 600, 150); // X, Y, Width, Height
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(255, 245, 233))) // 128 = 50% opacity, Green color
            {

                e.Graphics.FillRectangle(brush, rectangle3);
            }
        }

        private void Label_PetName_Click(object sender, EventArgs e)
        {

        }

        private void Label_Email_Click(object sender, EventArgs e)
        {

        }
    }
}
