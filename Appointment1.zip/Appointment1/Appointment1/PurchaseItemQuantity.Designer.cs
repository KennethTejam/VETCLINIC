﻿namespace Appointment1
{
    partial class PurchaseItemQuantity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Label_AreYouSure = new Label();
            numericUpDown1 = new NumericUpDown();
            Label_Confirm = new Label();
            Label_Cancel = new Label();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            SuspendLayout();
            // 
            // Label_AreYouSure
            // 
            Label_AreYouSure.AutoSize = true;
            Label_AreYouSure.Location = new Point(179, 58);
            Label_AreYouSure.Name = "Label_AreYouSure";
            Label_AreYouSure.Size = new Size(0, 15);
            Label_AreYouSure.TabIndex = 0;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(179, 106);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(88, 23);
            numericUpDown1.TabIndex = 1;
            numericUpDown1.ValueChanged += numericUpDown1_ValueChanged;
            // 
            // Label_Confirm
            // 
            Label_Confirm.AutoSize = true;
            Label_Confirm.Location = new Point(302, 179);
            Label_Confirm.Name = "Label_Confirm";
            Label_Confirm.Size = new Size(51, 15);
            Label_Confirm.TabIndex = 2;
            Label_Confirm.Text = "Confirm";
            Label_Confirm.Click += Label_Confirm_Click;
            // 
            // Label_Cancel
            // 
            Label_Cancel.AutoSize = true;
            Label_Cancel.Location = new Point(90, 179);
            Label_Cancel.Name = "Label_Cancel";
            Label_Cancel.Size = new Size(43, 15);
            Label_Cancel.TabIndex = 3;
            Label_Cancel.Text = "Cancel";
            Label_Cancel.Click += Label_Cancel_Click;
            // 
            // PurchaseItemQuantity
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(477, 274);
            Controls.Add(Label_Cancel);
            Controls.Add(Label_Confirm);
            Controls.Add(numericUpDown1);
            Controls.Add(Label_AreYouSure);
            Name = "PurchaseItemQuantity";
            Text = "PurchaseItemQuantity";
            Load += PurchaseItemQuantity_Load;
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Label_AreYouSure;
        private NumericUpDown numericUpDown1;
        private Label Label_Confirm;
        private Label Label_Cancel;
    }
}