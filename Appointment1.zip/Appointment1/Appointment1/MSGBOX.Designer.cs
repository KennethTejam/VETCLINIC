﻿namespace Appointment1
{
    partial class MSGBOX
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Button_Ok = new Button();
            textBox1 = new TextBox();
            SuspendLayout();
            // 
            // Button_Ok
            // 
            Button_Ok.Location = new Point(181, 116);
            Button_Ok.Name = "Button_Ok";
            Button_Ok.Size = new Size(75, 23);
            Button_Ok.TabIndex = 1;
            Button_Ok.Text = "OK";
            Button_Ok.UseVisualStyleBackColor = true;
            Button_Ok.Click += Button_Ok_Click;
            // 
            // textBox1
            // 
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Enabled = false;
            textBox1.Location = new Point(47, 25);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(185, 72);
            textBox1.TabIndex = 2;
            // 
            // MSGBOX
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(284, 161);
            Controls.Add(textBox1);
            Controls.Add(Button_Ok);
            Name = "MSGBOX";
            Text = "MSGBOX";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button Button_Ok;
        private TextBox textBox1;
    }
}