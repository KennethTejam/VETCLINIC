﻿namespace Appointment1
{
    partial class frmAppRecord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPetName = new Label();
            lblOwnerName = new Label();
            lblAppointmentDate = new Label();
            lblAppointmentTime = new Label();
            lblStatus = new Label();
            lblPetBreed = new Label();
            lblContact = new Label();
            lblEmail = new Label();
            lblGender = new Label();
            lblAge = new Label();
            txtOwnerName = new TextBox();
            txtPetName = new TextBox();
            txtGender = new TextBox();
            txtPetBreed = new TextBox();
            txtAge = new TextBox();
            txtContact = new TextBox();
            txtEmail = new TextBox();
            txtAppointmentDate = new TextBox();
            txtAppointmentTime = new TextBox();
            txtStatus = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            SuspendLayout();
            // 
            // lblPetName
            // 
            lblPetName.AutoSize = true;
            lblPetName.Location = new Point(96, 56);
            lblPetName.Name = "lblPetName";
            lblPetName.Size = new Size(0, 20);
            lblPetName.TabIndex = 0;
            // 
            // lblOwnerName
            // 
            lblOwnerName.AutoSize = true;
            lblOwnerName.Location = new Point(96, 85);
            lblOwnerName.Name = "lblOwnerName";
            lblOwnerName.Size = new Size(0, 20);
            lblOwnerName.TabIndex = 1;
            // 
            // lblAppointmentDate
            // 
            lblAppointmentDate.AutoSize = true;
            lblAppointmentDate.Location = new Point(96, 119);
            lblAppointmentDate.Name = "lblAppointmentDate";
            lblAppointmentDate.Size = new Size(0, 20);
            lblAppointmentDate.TabIndex = 2;
            // 
            // lblAppointmentTime
            // 
            lblAppointmentTime.AutoSize = true;
            lblAppointmentTime.Location = new Point(96, 149);
            lblAppointmentTime.Name = "lblAppointmentTime";
            lblAppointmentTime.Size = new Size(0, 20);
            lblAppointmentTime.TabIndex = 3;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(96, 180);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(0, 20);
            lblStatus.TabIndex = 4;
            // 
            // lblPetBreed
            // 
            lblPetBreed.AutoSize = true;
            lblPetBreed.Location = new Point(96, 210);
            lblPetBreed.Name = "lblPetBreed";
            lblPetBreed.Size = new Size(0, 20);
            lblPetBreed.TabIndex = 5;
            // 
            // lblContact
            // 
            lblContact.AutoSize = true;
            lblContact.Location = new Point(96, 250);
            lblContact.Name = "lblContact";
            lblContact.Size = new Size(0, 20);
            lblContact.TabIndex = 6;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(96, 347);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(0, 20);
            lblEmail.TabIndex = 7;
            // 
            // lblGender
            // 
            lblGender.AutoSize = true;
            lblGender.Location = new Point(96, 280);
            lblGender.Name = "lblGender";
            lblGender.Size = new Size(0, 20);
            lblGender.TabIndex = 8;
            // 
            // lblAge
            // 
            lblAge.AutoSize = true;
            lblAge.Location = new Point(96, 313);
            lblAge.Name = "lblAge";
            lblAge.Size = new Size(0, 20);
            lblAge.TabIndex = 9;
            // 
            // txtOwnerName
            // 
            txtOwnerName.Location = new Point(152, 53);
            txtOwnerName.Name = "txtOwnerName";
            txtOwnerName.ReadOnly = true;
            txtOwnerName.Size = new Size(162, 27);
            txtOwnerName.TabIndex = 10;
            // 
            // txtPetName
            // 
            txtPetName.Location = new Point(152, 86);
            txtPetName.Name = "txtPetName";
            txtPetName.ReadOnly = true;
            txtPetName.Size = new Size(162, 27);
            txtPetName.TabIndex = 11;
            // 
            // txtGender
            // 
            txtGender.Location = new Point(152, 180);
            txtGender.Name = "txtGender";
            txtGender.ReadOnly = true;
            txtGender.Size = new Size(162, 27);
            txtGender.TabIndex = 12;
            // 
            // txtPetBreed
            // 
            txtPetBreed.Location = new Point(152, 119);
            txtPetBreed.Name = "txtPetBreed";
            txtPetBreed.ReadOnly = true;
            txtPetBreed.Size = new Size(162, 27);
            txtPetBreed.TabIndex = 12;
            // 
            // txtAge
            // 
            txtAge.Location = new Point(152, 152);
            txtAge.Name = "txtAge";
            txtAge.ReadOnly = true;
            txtAge.Size = new Size(162, 27);
            txtAge.TabIndex = 13;
            // 
            // txtContact
            // 
            txtContact.Location = new Point(152, 213);
            txtContact.Name = "txtContact";
            txtContact.ReadOnly = true;
            txtContact.Size = new Size(162, 27);
            txtContact.TabIndex = 14;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(152, 250);
            txtEmail.Name = "txtEmail";
            txtEmail.ReadOnly = true;
            txtEmail.Size = new Size(162, 27);
            txtEmail.TabIndex = 15;
            // 
            // txtAppointmentDate
            // 
            txtAppointmentDate.Location = new Point(152, 280);
            txtAppointmentDate.Name = "txtAppointmentDate";
            txtAppointmentDate.ReadOnly = true;
            txtAppointmentDate.Size = new Size(162, 27);
            txtAppointmentDate.TabIndex = 16;
            // 
            // txtAppointmentTime
            // 
            txtAppointmentTime.Location = new Point(152, 310);
            txtAppointmentTime.Name = "txtAppointmentTime";
            txtAppointmentTime.ReadOnly = true;
            txtAppointmentTime.Size = new Size(162, 27);
            txtAppointmentTime.TabIndex = 17;
            // 
            // txtStatus
            // 
            txtStatus.Location = new Point(152, 343);
            txtStatus.Name = "txtStatus";
            txtStatus.ReadOnly = true;
            txtStatus.Size = new Size(162, 27);
            txtStatus.TabIndex = 18;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(96, 89);
            label1.Name = "label1";
            label1.Size = new Size(50, 20);
            label1.TabIndex = 19;
            label1.Text = "label1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(96, 56);
            label2.Name = "label2";
            label2.Size = new Size(50, 20);
            label2.TabIndex = 19;
            label2.Text = "label1";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(96, 122);
            label3.Name = "label3";
            label3.Size = new Size(50, 20);
            label3.TabIndex = 20;
            label3.Text = "label1";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(96, 155);
            label4.Name = "label4";
            label4.Size = new Size(50, 20);
            label4.TabIndex = 21;
            label4.Text = "label1";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(96, 180);
            label5.Name = "label5";
            label5.Size = new Size(50, 20);
            label5.TabIndex = 22;
            label5.Text = "label1";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(96, 346);
            label6.Name = "label6";
            label6.Size = new Size(50, 20);
            label6.TabIndex = 23;
            label6.Text = "label1";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(96, 216);
            label7.Name = "label7";
            label7.Size = new Size(50, 20);
            label7.TabIndex = 23;
            label7.Text = "label1";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(96, 253);
            label8.Name = "label8";
            label8.Size = new Size(50, 20);
            label8.TabIndex = 24;
            label8.Text = "label1";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(96, 283);
            label9.Name = "label9";
            label9.Size = new Size(50, 20);
            label9.TabIndex = 23;
            label9.Text = "label1";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(96, 313);
            label10.Name = "label10";
            label10.Size = new Size(50, 20);
            label10.TabIndex = 25;
            label10.Text = "label1";
            // 
            // frmAppRecord
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label10);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label9);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtStatus);
            Controls.Add(txtAppointmentTime);
            Controls.Add(txtAppointmentDate);
            Controls.Add(txtEmail);
            Controls.Add(txtContact);
            Controls.Add(txtAge);
            Controls.Add(txtPetBreed);
            Controls.Add(txtGender);
            Controls.Add(txtPetName);
            Controls.Add(txtOwnerName);
            Controls.Add(lblAge);
            Controls.Add(lblGender);
            Controls.Add(lblEmail);
            Controls.Add(lblContact);
            Controls.Add(lblPetBreed);
            Controls.Add(lblStatus);
            Controls.Add(lblAppointmentTime);
            Controls.Add(lblAppointmentDate);
            Controls.Add(lblOwnerName);
            Controls.Add(lblPetName);
            Name = "frmAppRecord";
            Text = "Patient Information";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPetName;
        private Label lblOwnerName;
        private Label lblAppointmentDate;
        private Label lblAppointmentTime;
        private Label lblStatus;
        private Label lblPetBreed;
        private Label lblContact;
        private Label lblEmail;
        private Label lblGender;
        private Label lblAge;
        private TextBox txtOwnerName;
        private TextBox txtPetName;
        private TextBox txtGender;
        private TextBox txtPetBreed;
        private TextBox txtAge;
        private TextBox txtContact;
        private TextBox txtEmail;
        private TextBox txtAppointmentDate;
        private TextBox txtAppointmentTime;
        private TextBox txtStatus;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
    }
}