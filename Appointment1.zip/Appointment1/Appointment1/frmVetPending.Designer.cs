﻿namespace Appointment1
{
    partial class frmVetPending
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Label_Homepage = new Label();
            Label_ManageAccount = new Label();
            Label_History = new Label();
            txtSearch = new TextBox();
            cbSort = new ComboBox();
            lblDone = new Label();
            lblPending = new Label();
            pAppointment = new Panel();
            SuspendLayout();
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = SystemColors.Control;
            Label_Homepage.BorderStyle = BorderStyle.Fixed3D;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = SystemColors.ControlText;
            Label_Homepage.Location = new Point(105, 22);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Size = new Size(140, 34);
            Label_Homepage.TabIndex = 25;
            Label_Homepage.Text = "Homepage";
            Label_Homepage.Click += Label_Homepage_Click;
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.BorderStyle = BorderStyle.Fixed3D;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.Location = new Point(448, 22);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Size = new Size(210, 34);
            Label_ManageAccount.TabIndex = 24;
            Label_ManageAccount.Text = "Manage Account";
            Label_ManageAccount.Click += Label_ManageAccount_Click;
            // 
            // Label_History
            // 
            Label_History.AutoSize = true;
            Label_History.BorderStyle = BorderStyle.Fixed3D;
            Label_History.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_History.Location = new Point(259, 22);
            Label_History.Name = "Label_History";
            Label_History.Size = new Size(179, 34);
            Label_History.TabIndex = 23;
            Label_History.Text = "Appointments";
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(528, 80);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(141, 27);
            txtSearch.TabIndex = 22;
            // 
            // cbSort
            // 
            cbSort.FormattingEnabled = true;
            cbSort.Location = new Point(544, 128);
            cbSort.Name = "cbSort";
            cbSort.Size = new Size(151, 28);
            cbSort.TabIndex = 21;
            // 
            // lblDone
            // 
            lblDone.AutoSize = true;
            lblDone.Location = new Point(393, 164);
            lblDone.Name = "lblDone";
            lblDone.Size = new Size(45, 20);
            lblDone.TabIndex = 20;
            lblDone.Text = "Done";
            lblDone.Click += lblDone_Click;
            // 
            // lblPending
            // 
            lblPending.AutoSize = true;
            lblPending.Location = new Point(170, 164);
            lblPending.Name = "lblPending";
            lblPending.Size = new Size(62, 20);
            lblPending.TabIndex = 19;
            lblPending.Text = "Pending";
            // 
            // pAppointment
            // 
            pAppointment.AutoScroll = true;
            pAppointment.Location = new Point(152, 256);
            pAppointment.Name = "pAppointment";
            pAppointment.Size = new Size(297, 172);
            pAppointment.TabIndex = 18;
            // 
            // frmVetPending
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_History);
            Controls.Add(txtSearch);
            Controls.Add(cbSort);
            Controls.Add(lblDone);
            Controls.Add(lblPending);
            Controls.Add(pAppointment);
            Name = "frmVetPending";
            Text = "Form5";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Label_Homepage;
        private Label Label_ManageAccount;
        private Label Label_History;
        private TextBox txtSearch;
        private ComboBox cbSort;
        private Label lblDone;
        private Label lblPending;
        private Panel pAppointment;
    }
}