﻿namespace Appointment1
{
    partial class frmVetPending
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVetPending));
            Label_Homepage = new Label();
            Label_ManageAccount = new Label();
            Label_History = new Label();
            txtSearch = new TextBox();
            cbSort = new ComboBox();
            lblDone = new Label();
            lblPending = new Label();
            pAppointment = new Panel();
            label2 = new Label();
            label1 = new Label();
            Label_Username = new Label();
            Label_Welcome = new Label();
            Clinic_MainLogo = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)Clinic_MainLogo).BeginInit();
            SuspendLayout();
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = SystemColors.Control;
            Label_Homepage.BorderStyle = BorderStyle.Fixed3D;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = SystemColors.ControlText;
            Label_Homepage.Location = new Point(550, 133);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Size = new Size(112, 27);
            Label_Homepage.TabIndex = 25;
            Label_Homepage.Text = "Homepage";
            Label_Homepage.Click += Label_Homepage_Click;
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.BorderStyle = BorderStyle.Fixed3D;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.Location = new Point(850, 133);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Size = new Size(165, 27);
            Label_ManageAccount.TabIndex = 24;
            Label_ManageAccount.Text = "Manage Account";
            Label_ManageAccount.Click += Label_ManageAccount_Click;
            // 
            // Label_History
            // 
            Label_History.AutoSize = true;
            Label_History.BorderStyle = BorderStyle.Fixed3D;
            Label_History.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_History.Location = new Point(685, 133);
            Label_History.Name = "Label_History";
            Label_History.Size = new Size(141, 27);
            Label_History.TabIndex = 23;
            Label_History.Text = "Appointments";
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(609, 312);
            txtSearch.Margin = new Padding(3, 2, 3, 2);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(124, 23);
            txtSearch.TabIndex = 22;
            // 
            // cbSort
            // 
            cbSort.FormattingEnabled = true;
            cbSort.Location = new Point(609, 369);
            cbSort.Margin = new Padding(3, 2, 3, 2);
            cbSort.Name = "cbSort";
            cbSort.Size = new Size(133, 23);
            cbSort.TabIndex = 21;
            // 
            // lblDone
            // 
            lblDone.AutoSize = true;
            lblDone.BorderStyle = BorderStyle.Fixed3D;
            lblDone.Font = new Font("Palatino Linotype", 12F, FontStyle.Italic);
            lblDone.Location = new Point(459, 220);
            lblDone.Name = "lblDone";
            lblDone.Size = new Size(46, 25);
            lblDone.TabIndex = 20;
            lblDone.Text = "Done";
            lblDone.Click += lblDone_Click;
            // 
            // lblPending
            // 
            lblPending.AutoSize = true;
            lblPending.BorderStyle = BorderStyle.Fixed3D;
            lblPending.Font = new Font("Palatino Linotype", 12F, FontStyle.Italic);
            lblPending.Location = new Point(264, 220);
            lblPending.Name = "lblPending";
            lblPending.Size = new Size(66, 25);
            lblPending.TabIndex = 19;
            lblPending.Text = "Pending";
            lblPending.Click += lblPending_Click;
            // 
            // pAppointment
            // 
            pAppointment.AutoScroll = true;
            pAppointment.Location = new Point(178, 279);
            pAppointment.Margin = new Padding(3, 2, 3, 2);
            pAppointment.Name = "pAppointment";
            pAppointment.Size = new Size(398, 277);
            pAppointment.TabIndex = 18;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Green;
            label2.Location = new Point(609, 346);
            label2.Name = "label2";
            label2.Size = new Size(216, 21);
            label2.TabIndex = 40;
            label2.Text = "Sort Ascending or Descending";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Green;
            label1.Location = new Point(609, 279);
            label1.Name = "label1";
            label1.Size = new Size(379, 21);
            label1.TabIndex = 39;
            label1.Text = "Search for Keywords: Name of Owner // Name of Pet";
            // 
            // Label_Username
            // 
            Label_Username.AutoSize = true;
            Label_Username.Font = new Font("Sitka Subheading", 27.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Label_Username.Location = new Point(208, 79);
            Label_Username.Name = "Label_Username";
            Label_Username.Size = new Size(268, 53);
            Label_Username.TabIndex = 43;
            Label_Username.Text = "@GMAIL.COM";
            // 
            // Label_Welcome
            // 
            Label_Welcome.AutoSize = true;
            Label_Welcome.Font = new Font("Sitka Subheading", 36F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Label_Welcome.Location = new Point(208, 10);
            Label_Welcome.Name = "Label_Welcome";
            Label_Welcome.Size = new Size(286, 69);
            Label_Welcome.TabIndex = 42;
            Label_Welcome.Text = "WELCOME!";
            // 
            // Clinic_MainLogo
            // 
            Clinic_MainLogo.Image = (Image)resources.GetObject("Clinic_MainLogo.Image");
            Clinic_MainLogo.Location = new Point(33, 23);
            Clinic_MainLogo.Name = "Clinic_MainLogo";
            Clinic_MainLogo.Size = new Size(164, 150);
            Clinic_MainLogo.SizeMode = PictureBoxSizeMode.Zoom;
            Clinic_MainLogo.TabIndex = 41;
            Clinic_MainLogo.TabStop = false;
            // 
            // frmVetPending
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 681);
            Controls.Add(Label_Username);
            Controls.Add(Label_Welcome);
            Controls.Add(Clinic_MainLogo);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_History);
            Controls.Add(txtSearch);
            Controls.Add(cbSort);
            Controls.Add(lblDone);
            Controls.Add(lblPending);
            Controls.Add(pAppointment);
            Margin = new Padding(3, 2, 3, 2);
            Name = "frmVetPending";
            Text = "Form5";
            ((System.ComponentModel.ISupportInitialize)Clinic_MainLogo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Label_Homepage;
        private Label Label_ManageAccount;
        private Label Label_History;
        private TextBox txtSearch;
        private ComboBox cbSort;
        private Label lblDone;
        private Label lblPending;
        private Panel pAppointment;
        private Label label2;
        private Label label1;
        private Label Label_Username;
        private Label Label_Welcome;
        private PictureBox Clinic_MainLogo;
    }
}