﻿namespace Appointment1
{
    partial class Staff_Checkout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            panel1 = new Panel();
            Label_Checkout = new Label();
            Cancel = new Label();
            Label_Cashier = new Label();
            panel2 = new Panel();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(131, 22);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(143, 33);
            textBox1.TabIndex = 0;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // panel1
            // 
            panel1.AutoScroll = true;
            panel1.Location = new Point(0, 61);
            panel1.Name = "panel1";
            panel1.Size = new Size(274, 275);
            panel1.TabIndex = 2;
            panel1.Paint += panel1_Paint;
            // 
            // Label_Checkout
            // 
            Label_Checkout.AutoSize = true;
            Label_Checkout.Location = new Point(585, 461);
            Label_Checkout.Name = "Label_Checkout";
            Label_Checkout.Size = new Size(67, 15);
            Label_Checkout.TabIndex = 4;
            Label_Checkout.Text = "CHECKOUT";
            // 
            // Cancel
            // 
            Cancel.AutoSize = true;
            Cancel.Location = new Point(30, 461);
            Cancel.Name = "Cancel";
            Cancel.Size = new Size(67, 15);
            Cancel.TabIndex = 5;
            Cancel.Text = "CHECKOUT";
            // 
            // Label_Cashier
            // 
            Label_Cashier.AutoSize = true;
            Label_Cashier.Location = new Point(385, 22);
            Label_Cashier.Name = "Label_Cashier";
            Label_Cashier.Size = new Size(46, 15);
            Label_Cashier.TabIndex = 6;
            Label_Cashier.Text = "Cashier";
            // 
            // panel2
            // 
            panel2.AutoScroll = true;
            panel2.BackColor = Color.Transparent;
            panel2.Location = new Point(368, 40);
            panel2.Name = "panel2";
            panel2.Size = new Size(274, 275);
            panel2.TabIndex = 3;
            // 
            // Staff_Checkout
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveBorder;
            ClientSize = new Size(664, 337);
            Controls.Add(panel2);
            Controls.Add(Label_Cashier);
            Controls.Add(Cancel);
            Controls.Add(Label_Checkout);
            Controls.Add(panel1);
            Controls.Add(textBox1);
            Name = "Staff_Checkout";
            Text = "   ";
            Load += Staff_Checkout_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Panel panel1;
        private Label Label_Checkout;
        private Label Cancel;
        private Label Label_Cashier;
        public Panel panel2;
    }
}