﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Appointment1
{
    public partial class Staff_Checkout : Form
    {
        SqlConnection conn;
        PROCESSES process = new PROCESSES();
        PrivateFontCollection privateFonts;
        PrivateFontCollection privateFontsbold;
        Font poppinsFont;
        Font poppinsFontlinklabel;
        Font poppinsFontcal;
        Font monthtext;
        Font sidebtns;
        private int productcounter = 0;
        public int size = 20;
        double[] productpricearray;
        int[] productidarray;
        int[] productqtyarray;
        string[] productnamearray;

        public Staff_Checkout()
        {
            InitializeComponent();
            setFont();
            productpricearray = new double[size];
            productidarray = new int[size];
            productqtyarray = new int[size];
            productnamearray = new string[size];
            
            conn = process.getConnection();
            loaddefault();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                loaddefault();

            }
            else
            {
                searchbar();
            }
        }
        public void setFont()
        {
            privateFonts = new PrivateFontCollection();
            privateFontsbold = new PrivateFontCollection();
            privateFonts.AddFontFile("C:\\Users\\John\\source\\repos\\Appointment1\\Appointment1\\bin\\Debug\\net8.0-windows\\FONTS\\Poppins-Regular.ttf");
            privateFontsbold.AddFontFile("C:\\Users\\John\\source\\repos\\Appointment1\\Appointment1\\bin\\Debug\\net8.0-windows\\FONTS\\Poppins-ExtraBold.ttf");
            poppinsFont = new Font(privateFontsbold.Families[0], 55f);
            poppinsFontlinklabel = new Font(privateFonts.Families[0], 12f);
            poppinsFontcal = new Font(privateFonts.Families[0], 9f);
            monthtext = new Font(privateFontsbold.Families[0], 12f);
            sidebtns = new Font(privateFontsbold.Families[0], 13f);

        }

        public void loaddefault()
        {

            panel1.Controls.Clear();
            string name = textBox1.Text.Trim();
            string query = "SELECT * FROM inventory";

            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@name", name + "%");

                SqlDataReader reader = command.ExecuteReader();
                int i = 30;
                while (reader.Read())
                {
                    Label lbl = new Label();
                    lbl.Text = (reader["product_name"]).ToString();
                    lbl.AutoSize = true;
                    lbl.Size = new Size(20, 30);
                    lbl.Location = new Point(20, 1 * i);
                    lbl.Font = poppinsFontcal;
                    panel1.Controls.Add(lbl);
                    i += 30;
                    int productid = Convert.ToInt32(reader["productid"]);
                    lbl.Click += (sender, e) =>
                    {

                        MessageBox.Show(productid + "");



                    };
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }


        public void searchbar()
        {
            panel1.Controls.Clear();
            string name = textBox1.Text.Trim();
            string query = "SELECT * FROM inventory WHERE product_name LIKE @name";

            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@name", name + "%");

                SqlDataReader reader = command.ExecuteReader();
                int i = 30;
                while (reader.Read())
                {
                    Label lbl = new Label();
                    lbl.Text = (reader["product_name"]).ToString();
                    lbl.AutoSize = true;
                    lbl.Size = new Size(20, 30);
                    lbl.Location = new Point(20, 1 * i);
                    lbl.Font = poppinsFontcal;
                    panel1.Controls.Add(lbl);
                    i += 30;
                    int productid = Convert.ToInt32(reader["productid"]);
                    string productname = reader["product_name"].ToString();
                    int productprice = Convert.ToInt32(reader["price"]);
                    lbl.Click += (sender, e) =>
                    {
                        PurchaseItemQuantity piq = new PurchaseItemQuantity(productname, productprice, productid);
                        piq.ShowDialog();

                        




                    };
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }

        private void Staff_Checkout_Load(object sender, EventArgs e)
        {

        }

        public void GetValues(string productname, int productprice, int productid, int quantity)
        {
            productpricearray[productcounter] = productprice;
            productidarray[productcounter] = productid;
            productqtyarray[productcounter] = quantity;
            productnamearray[productcounter] = productname;
            int x = 30;  // Initialize position variable
            int f = 0;    // Initialize counter variable

            
                Label lebels = new Label(); // Create a new label

                // Set label properties
                lebels.Text = "pogi"; // Access product name at index f
                lebels.AutoSize = true;
                lebels.Size = new Size(50, 30);
                lebels.Location = new Point(20, x);  // Set position dynamically using x
                lebels.Font = poppinsFont;

                lebels.Visible = true;

                // Add the label to the panel
                panel2.Controls.Add(lebels);
                panel2.Focus();
                // Update counter and position for next label
                
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
