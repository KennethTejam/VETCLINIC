using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.Design;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;
using System.Security.Policy;
using System.Diagnostics.Eventing.Reader;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Reflection.Emit;
using System.Drawing.Text;


namespace Appointment1
{

    public partial class Login : Form
    {
        public int userid;
        SqlConnection conn;
        PROCESSES process = new PROCESSES();

        public Login(int userid)
        {
            InitializeComponent();
            this.userid = userid;
            if (userid > 0)
            {
                Homepage homepage = new Homepage(userid);
                homepage.Show();
                this.Hide();
            }
            
            
            conn = process.getConnection();
            setText();
            
        }
        public void setText() {
            PrivateFontCollection privateFonts = new PrivateFontCollection();
            privateFonts.AddFontFile("C:\\Users\\John\\source\\repos\\Appointment1\\Appointment1\\bin\\Debug\\net8.0-windows\\FONTS\\Poppins-Regular.ttf");
            Font poppinsFont = new Font(privateFonts.Families[0], 15f);
            Font poppinsFontlinklabel = new Font(privateFonts.Families[0], 12f);
            Label_Email.Font = poppinsFont;
            Label_Password.Font = poppinsFont;
            LinkLabel_ChangePassword.Font = poppinsFontlinklabel;
            LinkLabel_Signup.Font = poppinsFontlinklabel;
            Label_Welcome.Font = poppinsFont;
            Button_Login.Font = poppinsFont;

            TextBox_Email.Font = poppinsFont;
            TextBox_Password.Font = poppinsFont;
            Label_Email.Text = "Email";
            Label_Password.Text = "Password";
            LinkLabel_ChangePassword.Text = "Forgot Password?";
            LinkLabel_Signup.Text = "Don't have an account? Sign Up here!";
            Label_Welcome.Text = "Welcome to the Clinic!";
            Button_Login.Text = "Log in";
            Button_Login.BackColor = Color.FromArgb(233, 200, 168);
            
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void LinkLabel_Signup_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            Signup signup = new Signup();
            signup.Show();
            this.Hide();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void Button_Login_Click(object sender, EventArgs e)
        {

            string useremail, user_password;

            useremail = TextBox_Email.Text;
            user_password = TextBox_Password.Text;

            int userid = process.login_CheckAccount(useremail, user_password);
            string role = process.getPosition(useremail, user_password);
            if (role == "Vet")
            {
                string name = process.getUserEmail(userid);
                string msg = "Welcome DOCTOR " + name + "!";
                MSGBOX msgbox = new MSGBOX(msg);
                msgbox.ShowDialog();
                frmVetHP homepage = new frmVetHP(userid);
                homepage.Show();
                this.Hide();
            }
            else if (role == "Staff")
            {
                string name = process.getUserEmail(userid);
                string msg = "Welcome ADMIN " + name + "!";
                MSGBOX msgbox = new MSGBOX(msg);
                msgbox.ShowDialog();
                Homepage homepage = new Homepage(userid);
                homepage.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid login details!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                TextBox_Email.Clear();
                TextBox_Password.Clear();
                TextBox_Email.Focus();
            }

        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        public void GetUserInfo()
        {
            string useremail = TextBox_Email.Text;
            string password = TextBox_Password.Text;
            if (useremail == "" || password == "")
            {
                Button_Login.Enabled = false;
            }
            else { Button_Login.Enabled = true; }
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void TextBox_Email_TextChanged(object sender, EventArgs e)
        {
            GetUserInfo();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void TextBox_Password_TextChanged(object sender, EventArgs e)
        {
            GetUserInfo();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void Login_Load(object sender, EventArgs e)
        {

        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void LinkLabel_ChangePassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ForgotPassword forgotpassword = new ForgotPassword();
            forgotpassword.Show();
            this.Hide();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (PictureBox_PasswordViewer.ImageLocation == @"hide.png")
            {
                PictureBox_PasswordViewer.ImageLocation = @"view.png";
                TextBox_Password.UseSystemPasswordChar = true;
            }
            else
            {
                PictureBox_PasswordViewer.ImageLocation = @"hide.png";
                TextBox_Password.UseSystemPasswordChar = false;
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // Define the dimensions of the rectangle
            Rectangle rectangle = new Rectangle(220, 50, 630, 550); // X, Y, Width, Height
            int cornerRadius = 30; // Radius of the curved corners

            // Create a GraphicsPath for the rounded rectangle
            using (System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath())
            {
                // Top-left corner
                path.AddArc(rectangle.Left, rectangle.Top, cornerRadius * 2, cornerRadius * 2, 180, 90);
                // Top-right corner
                path.AddArc(rectangle.Right - cornerRadius * 2, rectangle.Top, cornerRadius * 2, cornerRadius * 2, 270, 90);
                // Bottom-right corner
                path.AddArc(rectangle.Right - cornerRadius * 2, rectangle.Bottom - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 0, 90);
                // Bottom-left corner
                path.AddArc(rectangle.Left, rectangle.Bottom - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 90, 90);
                path.CloseFigure(); // Close the path to form a complete rounded rectangle

                // Create a semi-transparent brush
                using (SolidBrush brush = new SolidBrush(Color.FromArgb(200, 233, 200, 168))) // 200 = 80% opacity
                {
                    // Fill the rounded rectangle
                    e.Graphics.FillPath(brush, path);
                }

                // Create a pen for the border
                using (Pen pen = new Pen(Color.Black, 2)) // Black border with 2px thickness
                {
                    // Draw the border of the rounded rectangle
                    e.Graphics.DrawPath(pen, path);
                }
            }
        }

        private void Label_Welcome_Click(object sender, EventArgs e)
        {

        }

    }
}       
