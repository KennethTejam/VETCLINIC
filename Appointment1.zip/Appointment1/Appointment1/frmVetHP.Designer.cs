﻿namespace Appointment1
{
    partial class frmVetHP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pAppointment = new Panel();
            Label_Homepage = new Label();
            Label_ManageAccount = new Label();
            Label_History = new Label();
            Label_Username = new Label();
            Label_Welcome = new Label();
            SuspendLayout();
            // 
            // pAppointment
            // 
            pAppointment.AutoScroll = true;
            pAppointment.Location = new Point(416, 226);
            pAppointment.Name = "pAppointment";
            pAppointment.Size = new Size(386, 243);
            pAppointment.TabIndex = 2;
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = SystemColors.Control;
            Label_Homepage.BorderStyle = BorderStyle.Fixed3D;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = SystemColors.ControlText;
            Label_Homepage.Location = new Point(304, 164);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Size = new Size(140, 34);
            Label_Homepage.TabIndex = 14;
            Label_Homepage.Text = "Homepage";
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.BorderStyle = BorderStyle.Fixed3D;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.Location = new Point(647, 164);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Size = new Size(210, 34);
            Label_ManageAccount.TabIndex = 13;
            Label_ManageAccount.Text = "Manage Account";
            Label_ManageAccount.Click += Label_ManageAccount_Click;
            // 
            // Label_History
            // 
            Label_History.AutoSize = true;
            Label_History.BorderStyle = BorderStyle.Fixed3D;
            Label_History.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_History.Location = new Point(450, 164);
            Label_History.Name = "Label_History";
            Label_History.Size = new Size(179, 34);
            Label_History.TabIndex = 12;
            Label_History.Text = "Appointments";
            Label_History.Click += Label_History_Click;
            // 
            // Label_Username
            // 
            Label_Username.AutoSize = true;
            Label_Username.Font = new Font("Sitka Subheading", 27.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Label_Username.Location = new Point(214, 96);
            Label_Username.Name = "Label_Username";
            Label_Username.Size = new Size(339, 68);
            Label_Username.TabIndex = 16;
            Label_Username.Text = "@GMAIL.COM";
            // 
            // Label_Welcome
            // 
            Label_Welcome.AutoSize = true;
            Label_Welcome.Font = new Font("Sitka Subheading", 36F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Label_Welcome.Location = new Point(30, 9);
            Label_Welcome.Name = "Label_Welcome";
            Label_Welcome.Size = new Size(358, 87);
            Label_Welcome.TabIndex = 15;
            Label_Welcome.Text = "WELCOME!";
            // 
            // frmVetHP
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1030, 553);
            Controls.Add(Label_Username);
            Controls.Add(Label_Welcome);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_History);
            Controls.Add(pAppointment);
            Name = "frmVetHP";
            Text = "Hompage";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pAppointment;
        private Label Label_Homepage;
        private Label Label_ManageAccount;
        private Label Label_History;
        private Label Label_Username;
        private Label Label_Welcome;
    }
}