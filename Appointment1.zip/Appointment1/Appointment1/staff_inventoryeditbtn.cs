﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appointment1
{
    public partial class staff_inventoryeditbtn : Form
    {
        PROCESSES process = new PROCESSES();
        SqlConnection conn;
        PrivateFontCollection privateFonts;
        PrivateFontCollection privateFontsbold;
        ContextMenuStrip contextMenu = new ContextMenuStrip();
        ContextMenuStrip recordMenu = new ContextMenuStrip();
        Font poppinsFont;
        Font poppinsFontlinklabel;
        Font poppinsFontcal;
        Font monthtext;
        Font sidebtns;

        public staff_inventoryeditbtn()
        {
            InitializeComponent();
            this.BackColor = Color.FromArgb(255, 243, 233);
            conn = process.getConnection();
            showProductHistory();
            setFont();
        }
        public void setFont()
        {
            privateFonts = new PrivateFontCollection();
            privateFontsbold = new PrivateFontCollection();
            privateFonts.AddFontFile("C:\\Users\\John\\source\\repos\\Appointment1\\Appointment1\\bin\\Debug\\net8.0-windows\\FONTS\\Poppins-Regular.ttf");
            privateFontsbold.AddFontFile("C:\\Users\\John\\source\\repos\\Appointment1\\Appointment1\\bin\\Debug\\net8.0-windows\\FONTS\\Poppins-ExtraBold.ttf");
            poppinsFont = new Font(privateFontsbold.Families[0], 55f);
            poppinsFontlinklabel = new Font(privateFonts.Families[0], 12f);
            poppinsFontcal = new Font(privateFonts.Families[0], 11f);
            monthtext = new Font(privateFontsbold.Families[0], 12f);
            sidebtns = new Font(privateFonts.Families[0], 13f);
            TextBox_ProductName.Font = monthtext;
            TextBox_Quantity.Font = monthtext;
            TextBox_ProductType.Font = monthtext;
            Numeric_ProductPrice.Font = monthtext;
            label1.Font = poppinsFontcal;
            comboBox1.Font = poppinsFontcal;
            label5.Font = poppinsFontcal;
            label4.Font = poppinsFontcal;
            label3.Font = poppinsFontcal;
            label2.Font = poppinsFontcal;
            label1.Font = poppinsFontcal;
            TextBox_ProductName.BackColor = Color.FromArgb(255, 243, 233);
            TextBox_Quantity.BackColor = Color.FromArgb(255, 243, 233);
            TextBox_ProductType.BackColor = Color.FromArgb(255, 243, 233);
            Numeric_ProductPrice.BackColor = Color.FromArgb(255, 243, 233);
            comboBox1.BackColor = Color.FromArgb(255, 243, 233);

            button1.BackColor = Color.FromArgb(255, 243, 233); ;
            Button_Cancel.BackColor = Color.FromArgb(255, 243, 233); ;
            button1.Font = sidebtns;
            Button_Cancel.Font = sidebtns;
        }
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        public void showProductHistory()
        {
            string query = "SELECT * FROM inventory;";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();


                while (reader.Read())
                {
                    string fullname = $"ID: {reader["productid"]} ";
                    comboBox1.Items.Add(fullname);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading inventory: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(comboBox1.Text.Substring(4));
            showinfo(id);
        }

        public void showinfo(int id)
        {
            string query = "SELECT * FROM inventory WHERE productid = @id";

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@id", id);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    TextBox_ProductName.Text = reader["product_name"].ToString();
                    TextBox_ProductType.Text = reader["type"].ToString();
                    TextBox_Quantity.Text = reader["quantity"].ToString();
                    Numeric_ProductPrice.Text = reader["price"].ToString();
                    TextBox_ProductName.Enabled = true;
                    TextBox_ProductType.Enabled = true;
                    TextBox_Quantity.Enabled = true;
                    Numeric_ProductPrice.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Product not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading inventory: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(TextBox_ProductName.Text) || string.IsNullOrEmpty(TextBox_ProductType.Text) || string.IsNullOrEmpty(TextBox_Quantity.Text))
            {
                MessageBox.Show("Fill up the required product details!");
                return;
            }
            else
            {
                updateproduct();
                this.Close();
            }
        }
        public void updateproduct()
        {
            string name = TextBox_ProductName.Text;
            string type = TextBox_ProductType.Text;
            int quantity = Convert.ToInt32(TextBox_Quantity.Text);
            double price = Convert.ToDouble(Numeric_ProductPrice.Value);
            string idstring = comboBox1.Text.Substring(4).Trim();
            int id = Convert.ToInt32(idstring);
            try
            {
                conn.Open();
                string query = "UPDATE inventory SET product_name = @name, quantity = @qty, price = @price, type = @type WHERE productid = @productid";

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@name", name);
                    command.Parameters.AddWithValue("@qty", quantity);
                    command.Parameters.AddWithValue("@price", price);
                    command.Parameters.AddWithValue("@type", type);
                    command.Parameters.AddWithValue("@productid", id);
                    command.ExecuteNonQuery();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Rectangle rectangle = new Rectangle(40, 30, 350, 350); // X, Y, Width, Height

            // Create a semi-transparent brush
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(233, 200, 168))) // 128 = 50% opacity, Green color
            {
                // Draw the rectangle in the specified position
                e.Graphics.FillRectangle(brush, rectangle);
            }

        }

        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
