﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appointment1
{
    public partial class PurchaseItemQuantity : Form
    {
        private string ProductName;
        private int productprice,productid;
        public PurchaseItemQuantity(string productname, int productprice, int productid)
        {
            InitializeComponent();
            this.ProductName = productname;
            this.productprice = productprice;
            this.productid = productid;
            Label_AreYouSure.Text = "Are you sure to purchase " + productname + " for " + productprice + "?";
        }

        private void PurchaseItemQuantity_Load(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void Label_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Label_Confirm_Click(object sender, EventArgs e)
        {
            int quantity = Convert.ToInt32(numericUpDown1.Value);
            if (numericUpDown1.Value != 0)
            {
                Staff_Checkout stf = new Staff_Checkout();
                stf.GetValues(ProductName, productprice,productid,quantity);
                this.Hide();
            }
            else
            {
                MessageBox.Show("WrongPassword!"); ;
                return;
            }
        }
    }
}
