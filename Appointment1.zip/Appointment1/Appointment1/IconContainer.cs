﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appointment1
{
    public partial class IconContainer : Form
    {
        string imgloc;
        int userid;
        PROCESSES process = new PROCESSES();
        PrivateFontCollection privateFonts;
        PrivateFontCollection privateFontsbold;

        Font poppinsFont;
        Font poppinsFontlinklabel;
        Font poppinsFontlinklabeltxtbx;
        public IconContainer(int userid)
        {
            InitializeComponent();
            this.BackColor = Color.FromArgb(215, 175, 125);
            this.userid = userid;
            setBackColor();
        }

        public void setBackColor()
        {
            privateFonts = new PrivateFontCollection();
            privateFontsbold = new PrivateFontCollection();
            privateFonts.AddFontFile("C:\\Users\\John\\source\\repos\\Appointment1\\Appointment1\\bin\\Debug\\net8.0-windows\\FONTS\\Poppins-Regular.ttf");
            privateFontsbold.AddFontFile("C:\\Users\\John\\source\\repos\\Appointment1\\Appointment1\\bin\\Debug\\net8.0-windows\\FONTS\\Poppins-ExtraBold.ttf");
            poppinsFont = new Font(privateFontsbold.Families[0], 55f);
            poppinsFontlinklabel = new Font(privateFonts.Families[0], 12f);
            poppinsFontlinklabeltxtbx = new Font(privateFonts.Families[0], 10f);
            radioButton1.BackColor = Color.FromArgb(255, 245, 233);
            radioButton2.BackColor = Color.FromArgb(255, 245, 233);
            radioButton3.BackColor = Color.FromArgb(255, 245, 233);
            radioButton4.BackColor = Color.FromArgb(255, 245, 233);
            radioButton5.BackColor = Color.FromArgb(255, 245, 233);
            radioButton6.BackColor = Color.FromArgb(255, 245, 233);
            radioButton7.BackColor = Color.FromArgb(255, 245, 233);
            radioButton9.BackColor = Color.FromArgb(255, 245, 233);
            /////
            /////
            radioButton1.Padding = new Padding(5, 5, 5, 5);
            radioButton2.Padding = new Padding(5, 5, 5, 5);
            radioButton3.Padding = new Padding(5, 5, 5, 5);
            radioButton4.Padding = new Padding(5, 5, 5, 5);
            radioButton5.Padding = new Padding(5, 5, 5, 5);
            radioButton6.Padding = new Padding(5, 5, 5, 5);
            radioButton7.Padding = new Padding(5, 5, 5, 5);
            radioButton9.Padding = new Padding(5, 5, 5, 5);
            Button_Confirm.Font = poppinsFontlinklabel;
            Button_Back.Font = poppinsFontlinklabel;
            Button_Confirm.BackColor = Color.FromArgb(255,245,233); 
            Button_Back.BackColor = Color.FromArgb(255, 245, 233); 
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            imgloc = "Bird.png";
            resetForeColor();
            radioButton1.ForeColor = Color.Red;

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            imgloc = "Dogtor.png";
            resetForeColor();
            radioButton2.ForeColor = Color.Red;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            imgloc = "Sheep.png";
            resetForeColor();
            radioButton3.ForeColor = Color.Red;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            imgloc = "Cat.png";
            resetForeColor();
            radioButton4.ForeColor = Color.Red;
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            imgloc = "Pig.png";
            resetForeColor();
            radioButton9.ForeColor = Color.Red;
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            imgloc = "GuineaPig.png";
            resetForeColor();
            radioButton7.ForeColor = Color.Red;
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            imgloc = "Penguin.png";
            resetForeColor();
            radioButton6.ForeColor = Color.Red;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            imgloc = "Tiger.png";
            resetForeColor();
            radioButton1.ForeColor = Color.Red;
        }

        private void Button_Confirm_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(imgloc))
            {
                return;
            }
            else
            {
                process.Addicontodb(userid, imgloc);
            }
            this.Close();
        }

        private void Button_Back_Click(object sender, EventArgs e)
        {
                this.Close();
        }
        private void resetForeColor() {


            radioButton1.ForeColor = Color.Black;
            radioButton2.ForeColor = Color.Black;
            radioButton3.ForeColor = Color.Black;
            radioButton4.ForeColor = Color.Black;
            radioButton9.ForeColor = Color.Black;
            radioButton7.ForeColor = Color.Black;
            radioButton5.ForeColor = Color.Black;
            radioButton6.ForeColor = Color.Black;



        }




    }
}
