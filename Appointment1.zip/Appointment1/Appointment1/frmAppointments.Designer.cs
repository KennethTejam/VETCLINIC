﻿namespace Appointment1
{
    partial class frmAppointments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label10 = new Label();
            label8 = new Label();
            label7 = new Label();
            label9 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtStatus = new TextBox();
            txtAppointmentTime = new TextBox();
            txtAppointmentDate = new TextBox();
            txtEmail = new TextBox();
            txtContact = new TextBox();
            txtAge = new TextBox();
            txtPetBreed = new TextBox();
            txtGender = new TextBox();
            txtPetName = new TextBox();
            txtOwnerName = new TextBox();
            lblAge = new Label();
            lblGender = new Label();
            lblEmail = new Label();
            lblContact = new Label();
            lblPetBreed = new Label();
            lblStatus = new Label();
            lblAppointmentTime = new Label();
            lblAppointmentDate = new Label();
            lblOwnerName = new Label();
            lblPetName = new Label();
            btnNext = new Button();
            SuspendLayout();
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(143, 238);
            label10.Name = "label10";
            label10.Size = new Size(38, 15);
            label10.TabIndex = 55;
            label10.Text = "label1";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(143, 193);
            label8.Name = "label8";
            label8.Size = new Size(38, 15);
            label8.TabIndex = 54;
            label8.Text = "label1";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(143, 165);
            label7.Name = "label7";
            label7.Size = new Size(38, 15);
            label7.TabIndex = 53;
            label7.Text = "label1";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(143, 215);
            label9.Name = "label9";
            label9.Size = new Size(38, 15);
            label9.TabIndex = 52;
            label9.Text = "label1";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(143, 262);
            label6.Name = "label6";
            label6.Size = new Size(38, 15);
            label6.TabIndex = 51;
            label6.Text = "label1";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(143, 138);
            label5.Name = "label5";
            label5.Size = new Size(38, 15);
            label5.TabIndex = 50;
            label5.Text = "label1";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(143, 119);
            label4.Name = "label4";
            label4.Size = new Size(38, 15);
            label4.TabIndex = 49;
            label4.Text = "label1";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(143, 94);
            label3.Name = "label3";
            label3.Size = new Size(38, 15);
            label3.TabIndex = 48;
            label3.Text = "label1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(143, 45);
            label2.Name = "label2";
            label2.Size = new Size(38, 15);
            label2.TabIndex = 47;
            label2.Text = "label1";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(143, 70);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 46;
            label1.Text = "label1";
            // 
            // txtStatus
            // 
            txtStatus.Location = new Point(192, 260);
            txtStatus.Margin = new Padding(3, 2, 3, 2);
            txtStatus.Name = "txtStatus";
            txtStatus.ReadOnly = true;
            txtStatus.Size = new Size(142, 23);
            txtStatus.TabIndex = 45;
            // 
            // txtAppointmentTime
            // 
            txtAppointmentTime.Location = new Point(192, 236);
            txtAppointmentTime.Margin = new Padding(3, 2, 3, 2);
            txtAppointmentTime.Name = "txtAppointmentTime";
            txtAppointmentTime.ReadOnly = true;
            txtAppointmentTime.Size = new Size(142, 23);
            txtAppointmentTime.TabIndex = 44;
            // 
            // txtAppointmentDate
            // 
            txtAppointmentDate.Location = new Point(192, 213);
            txtAppointmentDate.Margin = new Padding(3, 2, 3, 2);
            txtAppointmentDate.Name = "txtAppointmentDate";
            txtAppointmentDate.ReadOnly = true;
            txtAppointmentDate.Size = new Size(142, 23);
            txtAppointmentDate.TabIndex = 43;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(192, 190);
            txtEmail.Margin = new Padding(3, 2, 3, 2);
            txtEmail.Name = "txtEmail";
            txtEmail.ReadOnly = true;
            txtEmail.Size = new Size(142, 23);
            txtEmail.TabIndex = 42;
            // 
            // txtContact
            // 
            txtContact.Location = new Point(192, 163);
            txtContact.Margin = new Padding(3, 2, 3, 2);
            txtContact.Name = "txtContact";
            txtContact.ReadOnly = true;
            txtContact.Size = new Size(142, 23);
            txtContact.TabIndex = 41;
            // 
            // txtAge
            // 
            txtAge.Location = new Point(192, 117);
            txtAge.Margin = new Padding(3, 2, 3, 2);
            txtAge.Name = "txtAge";
            txtAge.ReadOnly = true;
            txtAge.Size = new Size(142, 23);
            txtAge.TabIndex = 40;
            // 
            // txtPetBreed
            // 
            txtPetBreed.Location = new Point(192, 92);
            txtPetBreed.Margin = new Padding(3, 2, 3, 2);
            txtPetBreed.Name = "txtPetBreed";
            txtPetBreed.ReadOnly = true;
            txtPetBreed.Size = new Size(142, 23);
            txtPetBreed.TabIndex = 39;
            // 
            // txtGender
            // 
            txtGender.Location = new Point(192, 138);
            txtGender.Margin = new Padding(3, 2, 3, 2);
            txtGender.Name = "txtGender";
            txtGender.ReadOnly = true;
            txtGender.Size = new Size(142, 23);
            txtGender.TabIndex = 38;
            // 
            // txtPetName
            // 
            txtPetName.Location = new Point(192, 68);
            txtPetName.Margin = new Padding(3, 2, 3, 2);
            txtPetName.Name = "txtPetName";
            txtPetName.ReadOnly = true;
            txtPetName.Size = new Size(142, 23);
            txtPetName.TabIndex = 37;
            // 
            // txtOwnerName
            // 
            txtOwnerName.Location = new Point(192, 43);
            txtOwnerName.Margin = new Padding(3, 2, 3, 2);
            txtOwnerName.Name = "txtOwnerName";
            txtOwnerName.ReadOnly = true;
            txtOwnerName.Size = new Size(142, 23);
            txtOwnerName.TabIndex = 36;
            // 
            // lblAge
            // 
            lblAge.AutoSize = true;
            lblAge.Location = new Point(143, 238);
            lblAge.Name = "lblAge";
            lblAge.Size = new Size(0, 15);
            lblAge.TabIndex = 35;
            // 
            // lblGender
            // 
            lblGender.AutoSize = true;
            lblGender.Location = new Point(143, 213);
            lblGender.Name = "lblGender";
            lblGender.Size = new Size(0, 15);
            lblGender.TabIndex = 34;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(143, 263);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(0, 15);
            lblEmail.TabIndex = 33;
            // 
            // lblContact
            // 
            lblContact.AutoSize = true;
            lblContact.Location = new Point(143, 190);
            lblContact.Name = "lblContact";
            lblContact.Size = new Size(0, 15);
            lblContact.TabIndex = 32;
            // 
            // lblPetBreed
            // 
            lblPetBreed.AutoSize = true;
            lblPetBreed.Location = new Point(143, 160);
            lblPetBreed.Name = "lblPetBreed";
            lblPetBreed.Size = new Size(0, 15);
            lblPetBreed.TabIndex = 31;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(143, 138);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(0, 15);
            lblStatus.TabIndex = 30;
            // 
            // lblAppointmentTime
            // 
            lblAppointmentTime.AutoSize = true;
            lblAppointmentTime.Location = new Point(143, 115);
            lblAppointmentTime.Name = "lblAppointmentTime";
            lblAppointmentTime.Size = new Size(0, 15);
            lblAppointmentTime.TabIndex = 29;
            // 
            // lblAppointmentDate
            // 
            lblAppointmentDate.AutoSize = true;
            lblAppointmentDate.Location = new Point(143, 92);
            lblAppointmentDate.Name = "lblAppointmentDate";
            lblAppointmentDate.Size = new Size(0, 15);
            lblAppointmentDate.TabIndex = 28;
            // 
            // lblOwnerName
            // 
            lblOwnerName.AutoSize = true;
            lblOwnerName.Location = new Point(143, 67);
            lblOwnerName.Name = "lblOwnerName";
            lblOwnerName.Size = new Size(0, 15);
            lblOwnerName.TabIndex = 27;
            // 
            // lblPetName
            // 
            lblPetName.AutoSize = true;
            lblPetName.Location = new Point(143, 45);
            lblPetName.Name = "lblPetName";
            lblPetName.Size = new Size(0, 15);
            lblPetName.TabIndex = 26;
            // 
            // btnNext
            // 
            btnNext.Location = new Point(500, 290);
            btnNext.Margin = new Padding(3, 2, 3, 2);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(82, 22);
            btnNext.TabIndex = 56;
            btnNext.Text = "Next";
            btnNext.UseVisualStyleBackColor = true;
            btnNext.Click += btnNext_Click;
            // 
            // frmAppointments
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 681);
            Controls.Add(btnNext);
            Controls.Add(label10);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label9);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtStatus);
            Controls.Add(txtAppointmentTime);
            Controls.Add(txtAppointmentDate);
            Controls.Add(txtEmail);
            Controls.Add(txtContact);
            Controls.Add(txtAge);
            Controls.Add(txtPetBreed);
            Controls.Add(txtGender);
            Controls.Add(txtPetName);
            Controls.Add(txtOwnerName);
            Controls.Add(lblAge);
            Controls.Add(lblGender);
            Controls.Add(lblEmail);
            Controls.Add(lblContact);
            Controls.Add(lblPetBreed);
            Controls.Add(lblStatus);
            Controls.Add(lblAppointmentTime);
            Controls.Add(lblAppointmentDate);
            Controls.Add(lblOwnerName);
            Controls.Add(lblPetName);
            Margin = new Padding(3, 2, 3, 2);
            Name = "frmAppointments";
            Text = "Form4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label10;
        private Label label8;
        private Label label7;
        private Label label9;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtStatus;
        private TextBox txtAppointmentTime;
        private TextBox txtAppointmentDate;
        private TextBox txtEmail;
        private TextBox txtContact;
        private TextBox txtAge;
        private TextBox txtPetBreed;
        private TextBox txtGender;
        private TextBox txtPetName;
        private TextBox txtOwnerName;
        private Label lblAge;
        private Label lblGender;
        private Label lblEmail;
        private Label lblContact;
        private Label lblPetBreed;
        private Label lblStatus;
        private Label lblAppointmentTime;
        private Label lblAppointmentDate;
        private Label lblOwnerName;
        private Label lblPetName;
        private Button btnNext;
    }
}