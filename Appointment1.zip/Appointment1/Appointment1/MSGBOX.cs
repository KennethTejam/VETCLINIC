﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appointment1
{
    public partial class MSGBOX : Form
    {
        public MSGBOX(string msg)
        {
            InitializeComponent();
            textBox1.Text = msg;
        }

        private void Button_Ok_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
