﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appointment1
{
    public partial class staff_historylist : Form

    { 
        PROCESSES process = new PROCESSES();
        SqlConnection conn;
        public staff_historylist()
        {
            conn =process.getConnection();
            InitializeComponent();
            getInventoryList();
        }

        public void getInventoryList()
        {
            string query = "SELECT * FROM inventoryhistory";
            try
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataReader reader = cmd.ExecuteReader();

                    int i = 0;
                    while (reader.Read())
                    {
                        Label lblAppointment = new Label();
                        if (reader["field_name"].ToString() == "price")
                        {
                            lblAppointment.Text = $"Price of product {reader["product_id"]}\nChanged from: {reader["old_value"]}\n To : {reader["new_value"]}\nTime: {reader["timestamp"]} \nBy:  {reader["user_id"]}";
                        }
                        else if (reader["field_name"].ToString() == "quantity")
                        {
                            lblAppointment.Text = $"Quantity of product {reader["product_id"]}\nChanged from: {reader["old_value"]}\n To : {reader["new_value"]}\nTime: {reader["timestamp"]} \nBy:  {reader["user_id"]}";
                        }
                        else if (reader["field_name"].ToString() == "name")
                        {
                            lblAppointment.Text = $"Name of product {reader["product_id"]}\nChanged from: {reader["old_value"]}\n To : {reader["new_value"]}\nTime: {reader["timestamp"]} \nBy:  {reader["user_id"]}";
                        }
                        lblAppointment.BorderStyle = BorderStyle.FixedSingle;
                        lblAppointment.Size = new Size(250, 70);
                        lblAppointment.Location = new Point(10, 10 + (i * 71));
                        lblAppointment.Font = new Font("Segoe UI", 7.75f, FontStyle.Bold);
                        int hstryID = Convert.ToInt32(reader["history_id"]);
                        lblAppointment.Click += (sender, e) => showinventoryeditbtn(hstryID);

                        panel1.Controls.Add(lblAppointment);
                        i++;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading appointments: " + ex.Message);
            }
            finally { conn.Close(); }
        }

        private void showinventoryeditbtn(int hstryID)
        {
            staff_inventoryeditbtn staff_Inventoryeditbtn = new staff_inventoryeditbtn();
            staff_Inventoryeditbtn.Show();
        }
    }
}
