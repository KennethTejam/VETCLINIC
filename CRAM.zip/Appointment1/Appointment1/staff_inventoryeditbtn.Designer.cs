﻿namespace Appointment1
{
    partial class staff_inventoryeditbtn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            TextBox_Quantity = new TextBox();
            comboBox1 = new ComboBox();
            TextBox_ProductType = new TextBox();
            Numeric_ProductPrice = new NumericUpDown();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            TextBox_ProductName = new TextBox();
            bindingSource1 = new BindingSource(components);
            button1 = new Button();
            Button_Cancel = new Button();
            ((System.ComponentModel.ISupportInitialize)Numeric_ProductPrice).BeginInit();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).BeginInit();
            SuspendLayout();
            // 
            // TextBox_Quantity
            // 
            TextBox_Quantity.Enabled = false;
            TextBox_Quantity.ForeColor = Color.Black;
            TextBox_Quantity.Location = new Point(200, 220);
            TextBox_Quantity.Name = "TextBox_Quantity";
            TextBox_Quantity.Size = new Size(120, 23);
            TextBox_Quantity.TabIndex = 0;
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.ForeColor = Color.Black;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(230, 70);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(74, 23);
            comboBox1.TabIndex = 1;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // TextBox_ProductType
            // 
            TextBox_ProductType.BackColor = SystemColors.Window;
            TextBox_ProductType.Enabled = false;
            TextBox_ProductType.ForeColor = Color.Black;
            TextBox_ProductType.Location = new Point(200, 175);
            TextBox_ProductType.Name = "TextBox_ProductType";
            TextBox_ProductType.Size = new Size(173, 23);
            TextBox_ProductType.TabIndex = 2;
            // 
            // Numeric_ProductPrice
            // 
            Numeric_ProductPrice.Enabled = false;
            Numeric_ProductPrice.ForeColor = Color.Black;
            Numeric_ProductPrice.Location = new Point(200, 265);
            Numeric_ProductPrice.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            Numeric_ProductPrice.Name = "Numeric_ProductPrice";
            Numeric_ProductPrice.Size = new Size(120, 23);
            Numeric_ProductPrice.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.ForeColor = Color.Black;
            label1.Location = new Point(110, 70);
            label1.Name = "label1";
            label1.Size = new Size(74, 15);
            label1.TabIndex = 4;
            label1.Text = "PRODUCT ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.ForeColor = Color.Black;
            label2.Location = new Point(60, 220);
            label2.Name = "label2";
            label2.Size = new Size(66, 15);
            label2.TabIndex = 5;
            label2.Text = "QUANTITY:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.ForeColor = Color.Black;
            label3.Location = new Point(60, 175);
            label3.Name = "label3";
            label3.Size = new Size(92, 15);
            label3.TabIndex = 6;
            label3.Text = "PRODUCT TYPE:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.ForeColor = Color.Black;
            label4.Location = new Point(60, 265);
            label4.Name = "label4";
            label4.Size = new Size(97, 15);
            label4.TabIndex = 7;
            label4.Text = "PRODUCT PRICE:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.ForeColor = Color.Black;
            label5.Location = new Point(60, 130);
            label5.Name = "label5";
            label5.Size = new Size(100, 15);
            label5.TabIndex = 9;
            label5.Text = "PRODUCT NAME:";
            // 
            // TextBox_ProductName
            // 
            TextBox_ProductName.Enabled = false;
            TextBox_ProductName.ForeColor = Color.Black;
            TextBox_ProductName.Location = new Point(200, 130);
            TextBox_ProductName.Name = "TextBox_ProductName";
            TextBox_ProductName.Size = new Size(173, 23);
            TextBox_ProductName.TabIndex = 8;
            // 
            // button1
            // 
            button1.AutoSize = true;
            button1.ForeColor = Color.Black;
            button1.Location = new Point(300, 320);
            button1.Name = "button1";
            button1.Size = new Size(75, 25);
            button1.TabIndex = 10;
            button1.Text = "EDIT";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Button_Cancel
            // 
            Button_Cancel.AutoSize = true;
            Button_Cancel.ForeColor = Color.Black;
            Button_Cancel.Location = new Point(60, 320);
            Button_Cancel.Name = "Button_Cancel";
            Button_Cancel.Size = new Size(75, 25);
            Button_Cancel.TabIndex = 12;
            Button_Cancel.Text = "CANCEL";
            Button_Cancel.UseVisualStyleBackColor = true;
            Button_Cancel.Click += Button_Cancel_Click;
            // 
            // staff_inventoryeditbtn
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(434, 411);
            Controls.Add(Button_Cancel);
            Controls.Add(button1);
            Controls.Add(label5);
            Controls.Add(TextBox_ProductName);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(Numeric_ProductPrice);
            Controls.Add(TextBox_ProductType);
            Controls.Add(comboBox1);
            Controls.Add(TextBox_Quantity);
            Name = "staff_inventoryeditbtn";
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)Numeric_ProductPrice).EndInit();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox TextBox_Quantity;
        private ComboBox comboBox1;
        private TextBox TextBox_ProductType;
        private NumericUpDown Numeric_ProductPrice;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox TextBox_ProductName;
        private BindingSource bindingSource1;
        private Button button1;
        private Button Button_Cancel;
    }
}