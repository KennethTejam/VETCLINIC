﻿namespace Appointment1
{
    partial class frmFollowUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnConfirm = new Button();
            cb1 = new CheckBox();
            cb2 = new CheckBox();
            cb3 = new CheckBox();
            cb4 = new CheckBox();
            cb5 = new CheckBox();
            cb10 = new CheckBox();
            cb9 = new CheckBox();
            cb8 = new CheckBox();
            cb7 = new CheckBox();
            cb6 = new CheckBox();
            SuspendLayout();
            // 
            // btnConfirm
            // 
            btnConfirm.Location = new Point(425, 302);
            btnConfirm.Margin = new Padding(3, 2, 3, 2);
            btnConfirm.Name = "btnConfirm";
            btnConfirm.Size = new Size(120, 74);
            btnConfirm.TabIndex = 7;
            btnConfirm.Text = "confirm";
            btnConfirm.UseVisualStyleBackColor = true;
            btnConfirm.Click += btnConfirm_Click;
            // 
            // cb1
            // 
            cb1.AutoSize = true;
            cb1.BackColor = Color.Transparent;
            cb1.Font = new Font("Segoe UI", 14.25F);
            cb1.Location = new Point(36, 55);
            cb1.Margin = new Padding(3, 2, 3, 2);
            cb1.Name = "cb1";
            cb1.Size = new Size(187, 29);
            cb1.TabIndex = 8;
            cb1.Text = "Distemper Vaccine";
            cb1.UseVisualStyleBackColor = false;
            // 
            // cb2
            // 
            cb2.AutoSize = true;
            cb2.BackColor = Color.Transparent;
            cb2.Font = new Font("Segoe UI", 14.25F);
            cb2.Location = new Point(36, 79);
            cb2.Margin = new Padding(3, 2, 3, 2);
            cb2.Name = "cb2";
            cb2.Size = new Size(188, 29);
            cb2.TabIndex = 9;
            cb2.Text = "Parvovirus Vaccine";
            cb2.UseVisualStyleBackColor = false;
            // 
            // cb3
            // 
            cb3.AutoSize = true;
            cb3.BackColor = Color.Transparent;
            cb3.Font = new Font("Segoe UI", 14.25F);
            cb3.Location = new Point(36, 106);
            cb3.Margin = new Padding(3, 2, 3, 2);
            cb3.Name = "cb3";
            cb3.Size = new Size(323, 29);
            cb3.TabIndex = 10;
            cb3.Text = "Bordetella (Kennel Cough) Vaccine";
            cb3.UseVisualStyleBackColor = false;
            // 
            // cb4
            // 
            cb4.AutoSize = true;
            cb4.BackColor = Color.Transparent;
            cb4.Font = new Font("Segoe UI", 14.25F);
            cb4.Location = new Point(36, 129);
            cb4.Margin = new Padding(3, 2, 3, 2);
            cb4.Name = "cb4";
            cb4.Size = new Size(166, 29);
            cb4.TabIndex = 11;
            cb4.Text = "Dental Cleaning";
            cb4.UseVisualStyleBackColor = false;
            // 
            // cb5
            // 
            cb5.AutoSize = true;
            cb5.BackColor = Color.Transparent;
            cb5.Font = new Font("Segoe UI", 14.25F);
            cb5.Location = new Point(36, 151);
            cb5.Margin = new Padding(3, 2, 3, 2);
            cb5.Name = "cb5";
            cb5.Size = new Size(162, 29);
            cb5.TabIndex = 12;
            cb5.Text = "Heartworm Test";
            cb5.UseVisualStyleBackColor = false;
            // 
            // cb10
            // 
            cb10.AutoSize = true;
            cb10.BackColor = Color.Transparent;
            cb10.Font = new Font("Segoe UI", 14.25F);
            cb10.Location = new Point(36, 274);
            cb10.Margin = new Padding(3, 2, 3, 2);
            cb10.Name = "cb10";
            cb10.Size = new Size(156, 29);
            cb10.TabIndex = 17;
            cb10.Text = "Rabies Vaccine";
            cb10.UseVisualStyleBackColor = false;
            // 
            // cb9
            // 
            cb9.AutoSize = true;
            cb9.BackColor = Color.Transparent;
            cb9.Font = new Font("Segoe UI", 14.25F);
            cb9.Location = new Point(36, 246);
            cb9.Margin = new Padding(3, 2, 3, 2);
            cb9.Name = "cb9";
            cb9.Size = new Size(129, 29);
            cb9.TabIndex = 16;
            cb9.Text = "Deworming";
            cb9.UseVisualStyleBackColor = false;
            // 
            // cb8
            // 
            cb8.AutoSize = true;
            cb8.BackColor = Color.Transparent;
            cb8.Font = new Font("Segoe UI", 14.25F);
            cb8.Location = new Point(36, 219);
            cb8.Margin = new Padding(3, 2, 3, 2);
            cb8.Name = "cb8";
            cb8.Size = new Size(211, 29);
            cb8.TabIndex = 15;
            cb8.Text = "Leptospirosis Vaccine";
            cb8.UseVisualStyleBackColor = false;
            // 
            // cb7
            // 
            cb7.AutoSize = true;
            cb7.BackColor = Color.Transparent;
            cb7.Font = new Font("Segoe UI", 14.25F);
            cb7.Location = new Point(36, 196);
            cb7.Margin = new Padding(3, 2, 3, 2);
            cb7.Name = "cb7";
            cb7.Size = new Size(236, 29);
            cb7.TabIndex = 14;
            cb7.Text = "Flea and Tick Prevention";
            cb7.UseVisualStyleBackColor = false;
            // 
            // cb6
            // 
            cb6.AutoSize = true;
            cb6.BackColor = Color.Transparent;
            cb6.Font = new Font("Segoe UI", 14.25F);
            cb6.Location = new Point(36, 174);
            cb6.Margin = new Padding(3, 2, 3, 2);
            cb6.Name = "cb6";
            cb6.Size = new Size(220, 29);
            cb6.TabIndex = 13;
            cb6.Text = "Annual Wellness Exam";
            cb6.UseVisualStyleBackColor = false;
            // 
            // frmFollowUp
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(567, 409);
            Controls.Add(cb10);
            Controls.Add(cb9);
            Controls.Add(cb8);
            Controls.Add(cb7);
            Controls.Add(cb6);
            Controls.Add(cb5);
            Controls.Add(cb4);
            Controls.Add(cb3);
            Controls.Add(cb2);
            Controls.Add(cb1);
            Controls.Add(btnConfirm);
            Margin = new Padding(3, 2, 3, 2);
            Name = "frmFollowUp";
            Text = "Form4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnConfirm;
        private CheckBox cb1;
        private CheckBox cb2;
        private CheckBox cb3;
        private CheckBox cb4;
        private CheckBox cb5;
        private CheckBox cb10;
        private CheckBox cb9;
        private CheckBox cb8;
        private CheckBox cb7;
        private CheckBox cb6;
    }
}