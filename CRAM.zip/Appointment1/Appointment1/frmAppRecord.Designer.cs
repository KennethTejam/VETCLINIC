﻿namespace Appointment1
{
    partial class frmAppRecord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPet = new Label();
            txtEmail = new TextBox();
            txtContact = new TextBox();
            txtAge = new TextBox();
            txtPetBreed = new TextBox();
            txtGender = new TextBox();
            txtPetName = new TextBox();
            txtOwnerName = new TextBox();
            lblAppointmentTime = new Label();
            lblAppointmentDate = new Label();
            lblOwnerName = new Label();
            lblPetName = new Label();
            receiptPanel = new Panel();
            pendingPanel = new Panel();
            lblGender = new Label();
            lblAge = new Label();
            lblContact = new Label();
            lblEmail = new Label();
            lblOwner = new Label();
            lblBreed = new Label();
            lblPast = new Label();
            lblUpcoming = new Label();
            SuspendLayout();
            // 
            // lblPet
            // 
            lblPet.AutoSize = true;
            lblPet.BackColor = Color.Transparent;
            lblPet.Font = new Font("Segoe UI", 14.25F);
            lblPet.Location = new Point(71, 167);
            lblPet.Name = "lblPet";
            lblPet.Size = new Size(47, 25);
            lblPet.TabIndex = 74;
            lblPet.Text = "PET:";
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Segoe UI", 14.25F);
            txtEmail.Location = new Point(256, 391);
            txtEmail.Margin = new Padding(3, 2, 3, 2);
            txtEmail.Name = "txtEmail";
            txtEmail.ReadOnly = true;
            txtEmail.Size = new Size(142, 33);
            txtEmail.TabIndex = 71;
            // 
            // txtContact
            // 
            txtContact.Font = new Font("Segoe UI", 14.25F);
            txtContact.Location = new Point(256, 352);
            txtContact.Margin = new Padding(3, 2, 3, 2);
            txtContact.Name = "txtContact";
            txtContact.ReadOnly = true;
            txtContact.Size = new Size(142, 33);
            txtContact.TabIndex = 70;
            // 
            // txtAge
            // 
            txtAge.Font = new Font("Segoe UI", 14.25F);
            txtAge.Location = new Point(256, 304);
            txtAge.Margin = new Padding(3, 2, 3, 2);
            txtAge.Name = "txtAge";
            txtAge.ReadOnly = true;
            txtAge.Size = new Size(142, 33);
            txtAge.TabIndex = 69;
            // 
            // txtPetBreed
            // 
            txtPetBreed.Font = new Font("Segoe UI", 14.25F);
            txtPetBreed.Location = new Point(256, 211);
            txtPetBreed.Margin = new Padding(3, 2, 3, 2);
            txtPetBreed.Name = "txtPetBreed";
            txtPetBreed.ReadOnly = true;
            txtPetBreed.Size = new Size(142, 33);
            txtPetBreed.TabIndex = 68;
            // 
            // txtGender
            // 
            txtGender.Font = new Font("Segoe UI", 14.25F);
            txtGender.Location = new Point(256, 256);
            txtGender.Margin = new Padding(3, 2, 3, 2);
            txtGender.Name = "txtGender";
            txtGender.ReadOnly = true;
            txtGender.Size = new Size(142, 33);
            txtGender.TabIndex = 67;
            // 
            // txtPetName
            // 
            txtPetName.Font = new Font("Segoe UI", 14.25F);
            txtPetName.Location = new Point(256, 163);
            txtPetName.Margin = new Padding(3, 2, 3, 2);
            txtPetName.Name = "txtPetName";
            txtPetName.ReadOnly = true;
            txtPetName.Size = new Size(142, 33);
            txtPetName.TabIndex = 66;
            // 
            // txtOwnerName
            // 
            txtOwnerName.Font = new Font("Segoe UI", 14.25F);
            txtOwnerName.Location = new Point(256, 115);
            txtOwnerName.Margin = new Padding(3, 2, 3, 2);
            txtOwnerName.Name = "txtOwnerName";
            txtOwnerName.ReadOnly = true;
            txtOwnerName.Size = new Size(142, 33);
            txtOwnerName.TabIndex = 65;
            // 
            // lblAppointmentTime
            // 
            lblAppointmentTime.AutoSize = true;
            lblAppointmentTime.Font = new Font("Segoe UI", 14.25F);
            lblAppointmentTime.Location = new Point(71, 212);
            lblAppointmentTime.Name = "lblAppointmentTime";
            lblAppointmentTime.Size = new Size(0, 25);
            lblAppointmentTime.TabIndex = 58;
            // 
            // lblAppointmentDate
            // 
            lblAppointmentDate.AutoSize = true;
            lblAppointmentDate.Font = new Font("Segoe UI", 14.25F);
            lblAppointmentDate.Location = new Point(71, 189);
            lblAppointmentDate.Name = "lblAppointmentDate";
            lblAppointmentDate.Size = new Size(0, 25);
            lblAppointmentDate.TabIndex = 57;
            // 
            // lblOwnerName
            // 
            lblOwnerName.AutoSize = true;
            lblOwnerName.Font = new Font("Segoe UI", 14.25F);
            lblOwnerName.Location = new Point(71, 164);
            lblOwnerName.Name = "lblOwnerName";
            lblOwnerName.Size = new Size(0, 25);
            lblOwnerName.TabIndex = 56;
            // 
            // lblPetName
            // 
            lblPetName.AutoSize = true;
            lblPetName.Font = new Font("Segoe UI", 14.25F);
            lblPetName.Location = new Point(71, 142);
            lblPetName.Name = "lblPetName";
            lblPetName.Size = new Size(0, 25);
            lblPetName.TabIndex = 55;
            // 
            // receiptPanel
            // 
            receiptPanel.AutoScroll = true;
            receiptPanel.BackColor = Color.Transparent;
            receiptPanel.Location = new Point(520, 65);
            receiptPanel.Margin = new Padding(3, 2, 3, 2);
            receiptPanel.Name = "receiptPanel";
            receiptPanel.Size = new Size(426, 231);
            receiptPanel.TabIndex = 83;
            // 
            // pendingPanel
            // 
            pendingPanel.AutoScroll = true;
            pendingPanel.BackColor = Color.Transparent;
            pendingPanel.Location = new Point(520, 360);
            pendingPanel.Margin = new Padding(3, 2, 3, 2);
            pendingPanel.Name = "pendingPanel";
            pendingPanel.Size = new Size(426, 217);
            pendingPanel.TabIndex = 84;
            // 
            // lblGender
            // 
            lblGender.AutoSize = true;
            lblGender.BackColor = Color.Transparent;
            lblGender.Font = new Font("Segoe UI", 14.25F);
            lblGender.Location = new Point(71, 254);
            lblGender.Name = "lblGender";
            lblGender.Size = new Size(87, 25);
            lblGender.TabIndex = 85;
            lblGender.Text = "GENDER:";
            // 
            // lblAge
            // 
            lblAge.AutoSize = true;
            lblAge.BackColor = Color.Transparent;
            lblAge.Font = new Font("Segoe UI", 14.25F);
            lblAge.Location = new Point(71, 305);
            lblAge.Name = "lblAge";
            lblAge.Size = new Size(51, 25);
            lblAge.TabIndex = 86;
            lblAge.Text = "AGE:";
            // 
            // lblContact
            // 
            lblContact.AutoSize = true;
            lblContact.BackColor = Color.Transparent;
            lblContact.Font = new Font("Segoe UI", 14.25F);
            lblContact.Location = new Point(71, 353);
            lblContact.Name = "lblContact";
            lblContact.Size = new Size(179, 25);
            lblContact.TabIndex = 87;
            lblContact.Text = "CONTACT NUMBER:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.BackColor = Color.Transparent;
            lblEmail.Font = new Font("Segoe UI", 14.25F);
            lblEmail.Location = new Point(71, 392);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(69, 25);
            lblEmail.TabIndex = 88;
            lblEmail.Text = "EMAIL:";
            // 
            // lblOwner
            // 
            lblOwner.AutoSize = true;
            lblOwner.BackColor = Color.Transparent;
            lblOwner.Font = new Font("Segoe UI", 14.25F);
            lblOwner.Location = new Point(71, 121);
            lblOwner.Name = "lblOwner";
            lblOwner.Size = new Size(83, 25);
            lblOwner.TabIndex = 89;
            lblOwner.Text = "OWNER:";
            // 
            // lblBreed
            // 
            lblBreed.AutoSize = true;
            lblBreed.BackColor = Color.Transparent;
            lblBreed.Font = new Font("Segoe UI", 14.25F);
            lblBreed.Location = new Point(71, 214);
            lblBreed.Name = "lblBreed";
            lblBreed.Size = new Size(71, 25);
            lblBreed.TabIndex = 90;
            lblBreed.Text = "BREED:";
            // 
            // lblPast
            // 
            lblPast.AutoSize = true;
            lblPast.BackColor = Color.Transparent;
            lblPast.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblPast.ForeColor = SystemColors.ButtonHighlight;
            lblPast.Location = new Point(520, 9);
            lblPast.Name = "lblPast";
            lblPast.Size = new Size(72, 32);
            lblPast.TabIndex = 91;
            lblPast.Text = "PAST";
            // 
            // lblUpcoming
            // 
            lblUpcoming.AutoSize = true;
            lblUpcoming.BackColor = Color.Transparent;
            lblUpcoming.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblUpcoming.ForeColor = SystemColors.ButtonHighlight;
            lblUpcoming.Location = new Point(520, 305);
            lblUpcoming.Name = "lblUpcoming";
            lblUpcoming.Size = new Size(146, 32);
            lblUpcoming.TabIndex = 92;
            lblUpcoming.Text = "UPCOMING";
            // 
            // frmAppRecord
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1022, 681);
            Controls.Add(lblUpcoming);
            Controls.Add(lblPast);
            Controls.Add(lblBreed);
            Controls.Add(lblOwner);
            Controls.Add(lblEmail);
            Controls.Add(lblContact);
            Controls.Add(lblAge);
            Controls.Add(lblGender);
            Controls.Add(pendingPanel);
            Controls.Add(receiptPanel);
            Controls.Add(lblPet);
            Controls.Add(txtEmail);
            Controls.Add(txtContact);
            Controls.Add(txtAge);
            Controls.Add(txtPetBreed);
            Controls.Add(txtGender);
            Controls.Add(txtPetName);
            Controls.Add(txtOwnerName);
            Controls.Add(lblAppointmentTime);
            Controls.Add(lblAppointmentDate);
            Controls.Add(lblOwnerName);
            Controls.Add(lblPetName);
            Margin = new Padding(3, 2, 3, 2);
            Name = "frmAppRecord";
            Text = "Patient Information";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label8;
        private Label label7;
        private Label label9;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label lblPet;
        private TextBox txtStatus;
        private TextBox txtAppointmentDate;
        private TextBox txtEmail;
        private TextBox txtContact;
        private TextBox txtAge;
        private TextBox txtPetBreed;
        private TextBox txtGender;
        private TextBox txtPetName;
        private TextBox txtOwnerName;
        private Label lblPetBreed;
        private Label lblStatus;
        private Label lblAppointmentTime;
        private Label lblAppointmentDate;
        private Label lblOwnerName;
        private Label lblPetName;
        private Panel receiptPanel;
        private Panel pendingPanel;
        private Label lblGender;
        private Label lblAge;
        private Label lblContact;
        private Label lblEmail;
        private Label lblOwner;
        private Label lblBreed;
        private Label lblPast;
        private Label lblUpcoming;
    }
}