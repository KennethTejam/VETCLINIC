﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Appointment1
{
    public partial class ManageAccount : Form
    {
        public string username, db_datejoined, db_email, db_pin, db_password, db_position, db_fullname;
        SqlConnection conn;
        public int userid;
        PROCESSES process = new PROCESSES();
        private bool isVerified = false;
        ContextMenuStrip contextMenu = new ContextMenuStrip();
        ContextMenuStrip recordMenu = new ContextMenuStrip();
        PrivateFontCollection privateFonts;
        PrivateFontCollection privateFontsbold;
        
        Font poppinsFont;
        Font poppinsFontlinklabel;
        public ManageAccount(int userid)
        {
            InitializeComponent();
            this.userid = userid;
            this.BackColor = Color.FromArgb(215, 175, 125);
            if (userid < 0)
            {
                this.Hide();
                Login login = new Login(userid);
                login.Show();
            }
            else
            {
                string useremail = process.getUserEmail(userid);

            }
            conn = process.getConnection();
            showContextMenurecord();
            setFont();
            AssignValues();
            setPicture();
        }

        public void showContextMenurecord()
        {
            ToolStripMenuItem changepass = new ToolStripMenuItem("Manage Account");
            ToolStripMenuItem logoutItem = new ToolStripMenuItem("Logout");
            ToolStripMenuItem newrecord = new ToolStripMenuItem("New Patient");
            ToolStripMenuItem existingrecord = new ToolStripMenuItem("Existing Patient");
            contextMenu.Font = new Font("Arial", 15, FontStyle.Bold);
            recordMenu.Font = new Font("Arial", 15, FontStyle.Bold);
            contextMenu.Items.Add(changepass);
            contextMenu.Items.Add(logoutItem);
            recordMenu.Items.Add(newrecord);
            recordMenu.Items.Add(existingrecord);
            changepass.Click += (sender, e) =>
            {
                ManageAccount changepass = new ManageAccount(userid);
                changepass.Show();
                this.Hide();
            };
            logoutItem.Click += (sender, e) =>
            {
                userid = -1;
                Login login = new Login(userid);
                login.Show();
                this.Hide();
            };

            newrecord.Click += (sender, e) =>
            {
                AddRecord changepass = new AddRecord(userid);
                changepass.Show();
                this.Hide();
            };
            existingrecord.Click += (sender, e) =>
            {
                ExistingRecord changepass = new ExistingRecord(userid);
                changepass.Show();
                this.Hide();
            };

            Label_ManageAccount.ContextMenuStrip = contextMenu;
            Label_ManageAccount.MouseEnter += (sender, e) =>
            {
                contextMenu.Show(Label_ManageAccount, Label_ManageAccount.PointToClient(Cursor.Position));
            };

            Label_Appointment.ContextMenuStrip = recordMenu;
            Label_Appointment.MouseEnter += (sender, e) =>
            {
                recordMenu.Show(Label_Appointment, Label_Appointment.PointToClient(Cursor.Position));
            };
        }

        public void setPicture()
        {
            Picture_Icon.ImageLocation = process.GetPicture(userid);
        }
        public void setFont()
        {
            privateFonts = new PrivateFontCollection();
            privateFontsbold = new PrivateFontCollection();
            privateFonts.AddFontFile("Poppins-Regular.ttf");
            privateFontsbold.AddFontFile("Poppins-ExtraBold.ttf");
            poppinsFont = new Font(privateFontsbold.Families[0], 55f);
            poppinsFontlinklabel = new Font(privateFonts.Families[0], 12f);
            Label_Welcome.Font = poppinsFont;
            Label_Welcome.ForeColor = Color.White;
            Label_ManageAccount.Font = poppinsFontlinklabel;
            Label_Appointment.Font = poppinsFontlinklabel;
            Label_Homepage.Font = poppinsFontlinklabel;
            Label_History.Font = poppinsFontlinklabel;
            Label_Shop.Font = poppinsFontlinklabel;
            Picture_Icon.BackColor = Color.FromArgb(255, 245, 233);


            Label_ManageAccount.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_ManageAccount.ClientRectangle.X, Label_ManageAccount.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.Right - cornerRadius, Label_ManageAccount.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.Right - cornerRadius, Label_ManageAccount.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.X, Label_ManageAccount.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_ManageAccount.Region = new Region(path);
                }
                Label_ManageAccount.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_ManageAccount.Text, Label_ManageAccount.Font, Label_ManageAccount.ClientRectangle, Label_ManageAccount.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };



            Label_Appointment.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Appointment.ClientRectangle.X, Label_Appointment.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Appointment.ClientRectangle.Right - cornerRadius, Label_Appointment.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Appointment.ClientRectangle.Right - cornerRadius, Label_Appointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Appointment.ClientRectangle.X, Label_Appointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Appointment.Region = new Region(path);
                }
                Label_Appointment.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Appointment.Text, Label_Appointment.Font, Label_Appointment.ClientRectangle, Label_Appointment.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };


            Label_History.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_History.ClientRectangle.X, Label_History.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_History.ClientRectangle.Right - cornerRadius, Label_History.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_History.ClientRectangle.Right - cornerRadius, Label_History.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_History.ClientRectangle.X, Label_History.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_History.Region = new Region(path);
                }
                Label_History.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_History.Text, Label_History.Font, Label_History.ClientRectangle, Label_History.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };


            Label_Homepage.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Homepage.ClientRectangle.X, Label_Homepage.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Homepage.ClientRectangle.Right - cornerRadius, Label_Homepage.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Homepage.ClientRectangle.Right - cornerRadius, Label_Homepage.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Homepage.ClientRectangle.X, Label_Homepage.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Homepage.Region = new Region(path);
                }
                Label_Homepage.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Homepage.Text, Label_Homepage.Font, Label_Homepage.ClientRectangle, Label_Homepage.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };

            Label_Shop.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Shop.ClientRectangle.X, Label_Shop.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Shop.ClientRectangle.Right - cornerRadius, Label_Shop.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Shop.ClientRectangle.Right - cornerRadius, Label_Shop.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Shop.ClientRectangle.X, Label_Shop.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Shop.Region = new Region(path);
                }
                Label_Shop.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Shop.Text, Label_Shop.Font, Label_Shop.ClientRectangle, Label_Shop.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };

        }

        public void AssignValues()
        {
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }

            try
            {
                string query = "SELECT * FROM userinfo WHERE userid = @userid;";

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@userid", userid);

                    SqlDataAdapter sdae = new SqlDataAdapter(command);
                    DataTable dtable = new DataTable();
                    sdae.Fill(dtable);

                    if (dtable.Rows.Count > 0)
                    {
                        db_email = dtable.Rows[0]["email"].ToString();
                        db_pin = dtable.Rows[0]["pin"].ToString();
                        db_password = dtable.Rows[0]["pass"].ToString();
                        db_datejoined = Convert.ToDateTime(dtable.Rows[0]["datecreated"]).ToString("MM/dd/yyyy");
                        db_fullname = $"{dtable.Rows[0]["fname"]} {dtable.Rows[0]["mname"]} {dtable.Rows[0]["lname"]}".Trim();
                        db_position = dtable.Rows[0]["position"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("No user found with that email.");
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {

                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            Label_MemberSince.Font = poppinsFontlinklabel;

            Label_MemberSince.TextAlign = ContentAlignment.MiddleCenter;
            Label_MemberSince.Text = "Member Since: " + db_datejoined + "\n" + db_fullname + "\n" + db_position;
            TextBox_ChangePin.Text = db_pin;
            TextBox_ChangeEmail.Text = db_email;
            TextBox_ChangePassword.Text = db_password;
            Label_MemberSince.ForeColor = Color.FromArgb(255, 245, 233);
        }



        public DialogResult ConfirmChange()
        {

            return MessageBox.Show("Are you sure you want to proceed?",
                          "Confirmation",
                          MessageBoxButtons.YesNo,
                          MessageBoxIcon.Question);
        }



        public void ChangeGo(string choice)
        {
            string query, pin = TextBox_ChangePin.Text, pass = TextBox_ChangePassword.Text, email = TextBox_ChangeEmail.Text;
            if (choice == "Pin") { query = "Update UserInfo set pin = @pin WHERE userid = @userid"; }
            else if (choice == "Pass") { query = "Update UserInfo set pass WHERE userid = @userid= @password"; }
            else if (choice == "Email") { query = "Update UserInfo set email = @email WHERE userid = @userid"; }
            else { query = ""; }
            try
            {
                conn.Open();


                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@password", pass);
                    command.Parameters.AddWithValue("@email", email);
                    command.Parameters.AddWithValue("@pin", pin);
                    command.Parameters.AddWithValue("@userid", userid);

                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Change successful!");

            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }


        public void OpenMessageBox(int userid)
        {

            String text = "Verify Password to continue...";
            var msgBox = new customMessageBox(text, userid);

            msgBox.ShowDialog(); // This will block interaction with other forms until it's closed
            isVerified = msgBox.IsVerified;

        }

        private void Label_Homepage_Click(object sender, EventArgs e)
        {
            Homepage homepage = new Homepage(userid);
            homepage.Show();
            this.Hide();
        }

        private void Label_Appointment_Click(object sender, EventArgs e)
        {
            HistoryRecordsPending recordhistory = new HistoryRecordsPending(userid);
            recordhistory.Show();
            this.Hide();
        }

        private void TextBox_ChangeEmail_TextChanged(object sender, EventArgs e)
        {
            Button_EmailConfirm.Enabled = true;
        }

        private void TextBox_ChangePin_TextChanged(object sender, EventArgs e)
        {
            Button_PinConfirm.Enabled = true;
        }

        private void TextBox_ChangePassword_TextChanged(object sender, EventArgs e)
        {
            Button_PassConfirm.Enabled = true;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (isVerified == false) { OpenMessageBox(userid); }
            else
            {

                if (TextBox_ChangeEmail.Enabled == false)
                {
                    TextBox_ChangeEmail.AcceptsReturn = true;
                    TextBox_ChangeEmail.Enabled = true;
                    Button_EmailConfirm.Visible = true;
                }
                else
                {
                    TextBox_ChangeEmail.AcceptsReturn = false;
                    TextBox_ChangeEmail.Enabled = false;
                    Button_EmailConfirm.Visible = false;
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (isVerified == false) { OpenMessageBox(userid); }
            else
            {
                if (TextBox_ChangePin.Enabled == false)
                {
                    TextBox_ChangePin.AcceptsReturn = true;
                    TextBox_ChangePin.Enabled = true;
                    Button_PinConfirm.Visible = true;
                }
                else
                {
                    TextBox_ChangePin.AcceptsReturn = false;
                    TextBox_ChangePin.Enabled = false;
                    Button_PinConfirm.Visible = false;
                }
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (isVerified == false) { OpenMessageBox(userid); }
            else
            {

                if (TextBox_ChangePassword.Enabled == false)
                {
                    TextBox_ChangePassword.AcceptsReturn = true;
                    TextBox_ChangePassword.Enabled = true;
                    Button_PassConfirm.Visible = true;
                }
                else
                {
                    TextBox_ChangePassword.AcceptsReturn = false;
                    TextBox_ChangePassword.Enabled = false;
                    Button_PassConfirm.Visible = false;
                }
            }
        }

        private void Button_EmailConfirm_Click(object sender, EventArgs e)
        {
            string choice = "Email";
            DialogResult result = ConfirmChange();
            if (result == DialogResult.Yes) { }
            else return;

            ChangeGo(choice);
            Button_EmailConfirm.Visible = false;
            TextBox_ChangeEmail.Enabled = false;
        }

        private void Button_PinConfirm_Click(object sender, EventArgs e)
        {
            string choice = "Pin";
            DialogResult result = ConfirmChange();
            if (result == DialogResult.Yes) { }
            else return;
            ChangeGo(choice);
            Button_PinConfirm.Visible = false;
            TextBox_ChangePin.Enabled = false;
        }

        private void Button_PassConfirm_Click(object sender, EventArgs e)
        {
            string choice = "Pass";
            DialogResult result = ConfirmChange();
            if (result == DialogResult.Yes) { }
            else return;
            ChangeGo(choice);
            Button_PassConfirm.Visible = false;
            TextBox_ChangePassword.Enabled = false;
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Rectangle rectangle = new Rectangle(0, 0, 1080, 160); // X, Y, Width, Height


            using (SolidBrush brush = new SolidBrush(Color.FromArgb(151, 97, 51))) // 128 = 50% opacity, Green color
            {

                e.Graphics.FillRectangle(brush, rectangle);
            }
            using (Pen pen = new Pen(Color.Black, 2))
            {
                e.Graphics.DrawRectangle(pen, rectangle);
            }

            Rectangle rectanglebg = new Rectangle(350, 180, 550, 420); // X, Y, Width, Height


            using (SolidBrush brush = new SolidBrush(Color.FromArgb(255, 245, 233))) // 128 = 50% opacity, Green color
            {

                e.Graphics.FillRectangle(brush, rectanglebg);
            }
            Rectangle rectangleicon = new Rectangle(82, 230, 197, 187);
            using (Pen pen = new Pen(Color.Black, 2))
            {
                e.Graphics.DrawRectangle(pen, rectangleicon);
            }
        }

        private void Label_Shop_Click(object sender, EventArgs e)
        {
            staff_inventory staffinventory = new staff_inventory(userid);
            staffinventory.Show();
            this.Hide();
        }

        private void Picture_Icon_Click(object sender, EventArgs e)
        {
            IconContainer icon = new IconContainer(userid);
            icon.ShowDialog();
            setPicture();
            /*ManageAccount mngacc = new ManageAccount(userid);
            this.Show();
            this.Hide();*/
        }
    }
}
