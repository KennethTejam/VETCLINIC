﻿namespace Appointment1
{
    partial class HistoryRecordsPending
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HistoryRecordsPending));
            pAppointment = new Panel();
            cbSort = new ComboBox();
            txtSearch = new TextBox();
            label1 = new Label();
            label2 = new Label();
            Label_Shop = new Label();
            pictureBox1 = new PictureBox();
            Label_Homepage = new Label();
            Label_ManageAccount = new Label();
            Label_History = new Label();
            Label_Appointment = new Label();
            Label_Welcome = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pAppointment
            // 
            pAppointment.AutoScroll = true;
            pAppointment.Font = new Font("Microsoft Sans Serif", 14.25F);
            pAppointment.Location = new Point(61, 244);
            pAppointment.Margin = new Padding(3, 2, 3, 2);
            pAppointment.Name = "pAppointment";
            pAppointment.Size = new Size(527, 298);
            pAppointment.TabIndex = 0;
            // 
            // cbSort
            // 
            cbSort.Font = new Font("Microsoft Sans Serif", 14.25F);
            cbSort.FormattingEnabled = true;
            cbSort.Location = new Point(644, 310);
            cbSort.Margin = new Padding(3, 2, 3, 2);
            cbSort.Name = "cbSort";
            cbSort.Size = new Size(133, 32);
            cbSort.TabIndex = 6;
            // 
            // txtSearch
            // 
            txtSearch.Font = new Font("Microsoft Sans Serif", 14.25F);
            txtSearch.Location = new Point(644, 257);
            txtSearch.Margin = new Padding(3, 2, 3, 2);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(133, 29);
            txtSearch.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 14.25F);
            label1.ForeColor = Color.Green;
            label1.Location = new Point(537, 304);
            label1.Name = "label1";
            label1.Size = new Size(0, 24);
            label1.TabIndex = 37;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 14.25F);
            label2.ForeColor = Color.Green;
            label2.Location = new Point(537, 357);
            label2.Name = "label2";
            label2.Size = new Size(0, 24);
            label2.TabIndex = 38;
            // 
            // Label_Shop
            // 
            Label_Shop.AutoSize = true;
            Label_Shop.BackColor = Color.Transparent;
            Label_Shop.Cursor = Cursors.Hand;
            Label_Shop.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Shop.ForeColor = Color.Black;
            Label_Shop.ImageAlign = ContentAlignment.MiddleRight;
            Label_Shop.Location = new Point(541, 117);
            Label_Shop.Name = "Label_Shop";
            Label_Shop.Padding = new Padding(10, 3, 10, 3);
            Label_Shop.Size = new Size(78, 31);
            Label_Shop.TabIndex = 46;
            Label_Shop.Text = "Shop";
            Label_Shop.Click += Label_Shop_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(741, 8);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(291, 95);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 45;
            pictureBox1.TabStop = false;
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = Color.Transparent;
            Label_Homepage.Cursor = Cursors.Hand;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = Color.Black;
            Label_Homepage.Location = new Point(28, 117);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Padding = new Padding(10, 3, 10, 3);
            Label_Homepage.Size = new Size(130, 31);
            Label_Homepage.TabIndex = 44;
            Label_Homepage.Text = "Homepage";
            Label_Homepage.Click += Label_Homepage_Click;
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.BackColor = Color.Transparent;
            Label_ManageAccount.Cursor = Cursors.No;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.ForeColor = Color.Black;
            Label_ManageAccount.ImageAlign = ContentAlignment.MiddleRight;
            Label_ManageAccount.Location = new Point(644, 117);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Padding = new Padding(10, 3, 10, 3);
            Label_ManageAccount.Size = new Size(183, 31);
            Label_ManageAccount.TabIndex = 43;
            Label_ManageAccount.Text = "Manage Account";
            // 
            // Label_History
            // 
            Label_History.AutoSize = true;
            Label_History.BackColor = Color.Transparent;
            Label_History.Cursor = Cursors.Hand;
            Label_History.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_History.ForeColor = Color.Black;
            Label_History.ImageAlign = ContentAlignment.MiddleRight;
            Label_History.Location = new Point(345, 117);
            Label_History.Name = "Label_History";
            Label_History.Padding = new Padding(10, 3, 10, 3);
            Label_History.Size = new Size(171, 31);
            Label_History.TabIndex = 42;
            Label_History.Text = "Patient Records";
            // 
            // Label_Appointment
            // 
            Label_Appointment.AutoSize = true;
            Label_Appointment.BackColor = Color.Transparent;
            Label_Appointment.Cursor = Cursors.Hand;
            Label_Appointment.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Appointment.ForeColor = Color.Black;
            Label_Appointment.ImageAlign = ContentAlignment.MiddleRight;
            Label_Appointment.Location = new Point(183, 117);
            Label_Appointment.Name = "Label_Appointment";
            Label_Appointment.Padding = new Padding(10, 3, 10, 3);
            Label_Appointment.Size = new Size(137, 31);
            Label_Appointment.TabIndex = 41;
            Label_Appointment.Text = "Add Record";
            // 
            // Label_Welcome
            // 
            Label_Welcome.AutoSize = true;
            Label_Welcome.BackColor = Color.Transparent;
            Label_Welcome.Font = new Font("Sitka Subheading", 36F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Label_Welcome.Location = new Point(29, -9);
            Label_Welcome.Name = "Label_Welcome";
            Label_Welcome.Size = new Size(286, 69);
            Label_Welcome.TabIndex = 40;
            Label_Welcome.Text = "WELCOME!";
            // 
            // HistoryRecordsPending
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 681);
            Controls.Add(Label_Shop);
            Controls.Add(pictureBox1);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_History);
            Controls.Add(Label_Appointment);
            Controls.Add(Label_Welcome);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtSearch);
            Controls.Add(cbSort);
            Controls.Add(pAppointment);
            Margin = new Padding(3, 2, 3, 2);
            Name = "HistoryRecordsPending";
            Text = "Appointments - Pending";
            Load += HistoryRecordsPending_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pAppointment;
        private ComboBox cbSort;
        private TextBox txtSearch;
        private Label label1;
        private Label label2;
        private Label Label_Shop;
        private PictureBox pictureBox1;
        private Label Label_Homepage;
        private Label Label_ManageAccount;
        private Label Label_History;
        private Label Label_Appointment;
        private Label Label_Welcome;
    }
}