﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;


namespace Appointment1
{
    public partial class Homepage : Form
    {
        public int userid;
        ContextMenuStrip contextMenu = new ContextMenuStrip();
        ContextMenuStrip recordMenu = new ContextMenuStrip();
        SqlConnection conn;
        PROCESSES process = new PROCESSES();
        int month, year;
        PrivateFontCollection privateFonts;
        PrivateFontCollection privateFontsbold;
        Font poppinsFont;
        Font poppinsFontlinklabel;
        Font poppinsFontcal;
        Font monthtext;
        public Homepage(int userid)
        {

            this.BackColor = Color.FromArgb(215, 175, 125);
            InitializeComponent();
            this.userid = userid;
            Label_Homepage.BackColor = Color.LightSkyBlue;
            DayContainer.BackColor = Color.FromArgb(255, 245, 233);
            if (userid < 0)
            {
                Login login = new Login(userid);
                login.Show();
                this.Hide();
            }
            else
            {
                string useremail = process.getUserEmail(userid);

            }

            conn = process.getConnection();
            showContextMenu();
            setFont();
            DateTime now = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
            month = now.Month;
            year = now.Year;
            calendar();
            showAppList(now);
        }
        public void showContextMenu()
        {
            ToolStripMenuItem changepass = new ToolStripMenuItem("Manage Account");
            ToolStripMenuItem logoutItem = new ToolStripMenuItem("Logout");
            ToolStripMenuItem newrecord = new ToolStripMenuItem("New Patient");
            ToolStripMenuItem existingrecord = new ToolStripMenuItem("Existing Patient");
            contextMenu.Font = new Font("Arial", 15, FontStyle.Bold);
            recordMenu.Font = new Font("Arial", 15, FontStyle.Bold);
            contextMenu.Items.Add(changepass);
            contextMenu.Items.Add(logoutItem);
            recordMenu.Items.Add(newrecord);
            recordMenu.Items.Add(existingrecord);
            changepass.Click += (sender, e) =>
            {
                ManageAccount changepass = new ManageAccount(userid);
                changepass.Show();
                this.Hide();
            };
            logoutItem.Click += (sender, e) =>
            {
                userid = -1;
                Login login = new Login(userid);
                login.Show();
                this.Hide();
            };

            newrecord.Click += (sender, e) =>
            {
                AddRecord changepass = new AddRecord(userid);
                changepass.Show();
                this.Hide();
            };
            existingrecord.Click += (sender, e) =>
            {
                ExistingRecord changepass = new ExistingRecord(userid);
                changepass.Show();
                this.Hide();
            };

            Label_ManageAccount.ContextMenuStrip = contextMenu;
            Label_ManageAccount.MouseEnter += (sender, e) =>
            {
                contextMenu.Show(Label_ManageAccount, Label_ManageAccount.PointToClient(Cursor.Position));
            };

            Label_Appointment.ContextMenuStrip = recordMenu;
            Label_Appointment.MouseEnter += (sender, e) =>
            {
                recordMenu.Show(Label_Appointment, Label_Appointment.PointToClient(Cursor.Position));
            };
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void calendar()
        {
            DayContainer.Controls.Clear();
            string monthname = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            

            Label_MANDY.Text = (monthname + " " + year).ToString();
            DateTime startofmonth = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            int daysoftheweek = Convert.ToInt32(startofmonth.DayOfWeek.ToString("d")) + 1;
            for (int i = 1; i < daysoftheweek; i++)
            {
                UserControl_Calendar uccalendar = new UserControl_Calendar();
                DayContainer.Controls.Add(uccalendar);
            }
            for (int i = 1; i <= days; i++)
            {

                UserControldays ucdays = new UserControldays();
                
                ucdays.BackColor = Color.Empty;
                ucdays.days(i, month, year);
                DayContainer.Controls.Add(ucdays);
                ucdays.Click += (sender, e) =>
                {
                    int day = Convert.ToInt32(ucdays.Label_Day.Text);

                    DateTime clickeddate = new DateTime(year, month, day);
                    showAppList(clickeddate);
                };
                ucdays.Label_Day.Click += (sender, e) =>
                {
                        int day = Convert.ToInt32(ucdays.Label_Day.Text);
                    DateTime clickeddate = new DateTime(year, month, day);
                        showAppList(clickeddate);
                    calendar();



                };
            }




        }

        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        public void showAppList(DateTime clickeddate)
        {
            int month = clickeddate.Month;
            int year = clickeddate.Year;
            int day = clickeddate.Day;
            string monthname = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);

            Label_Date.Text = monthname + " " + day + ", " + year;



            string query = @"
                SELECT appID, pname AS PetName, oname AS OwnerName, 
                       CONVERT(VARCHAR, appTime, 100) AS AppointmentTime
                FROM Appointments  
                WHERE appDate = @dateandtime AND status = 'Pending'";
            LoadPendingAppointments(query, clickeddate);
        }

        public void setFont()
        {
            privateFonts = new PrivateFontCollection();
            privateFontsbold = new PrivateFontCollection();
            privateFonts.AddFontFile("Poppins-Regular.ttf");
            privateFontsbold.AddFontFile("Poppins-ExtraBold.ttf");
            poppinsFont = new Font(privateFontsbold.Families[0], 55f);
            poppinsFontlinklabel = new Font(privateFonts.Families[0], 12f);
            poppinsFontcal = new Font(privateFonts.Families[0], 9f);
            monthtext = new Font(privateFontsbold.Families[0], 22f);
            ///
            ///
            ///
            ///
            ///
            Label_Date.Font = poppinsFontlinklabel;
            Label_DailyDashboard.Font = monthtext;
            Label_Welcome.Font = poppinsFont;
            Label_Welcome.ForeColor = Color.White;
            Label_ManageAccount.Font = poppinsFontlinklabel;
            Label_Appointment.Font = poppinsFontlinklabel;
            Label_Homepage.Font = poppinsFontlinklabel;
            Label_History.Font = poppinsFontlinklabel;
            Label_MANDY.Font = monthtext;
            Label_Sunday.Font = poppinsFontcal;
            Label_Monday.Font = poppinsFontcal;
            Label_Tuesday.Font = poppinsFontcal;
            Label_Wednesday.Font = poppinsFontcal;
            Label_Thursday.Font = poppinsFontcal;
            Label_Friday.Font = poppinsFontcal;
            Label_Saturday.Font = poppinsFontcal;
            Label_Shop.Font = poppinsFontlinklabel;
            Button_Next.Font = poppinsFontlinklabel;
            Button_Previous.Font = poppinsFontlinklabel;
            Button_Next.BackColor = Color.FromArgb(151, 97, 51);
            Button_Previous.BackColor = Color.FromArgb(151, 97, 51);
            Button_Next.ForeColor = Color.White;
            Button_Previous.ForeColor = Color.White;
            Label_ManageAccount.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_ManageAccount.ClientRectangle.X, Label_ManageAccount.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.Right - cornerRadius, Label_ManageAccount.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.Right - cornerRadius, Label_ManageAccount.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.X, Label_ManageAccount.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_ManageAccount.Region = new Region(path);
                }
                Label_ManageAccount.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_ManageAccount.Text, Label_ManageAccount.Font, Label_ManageAccount.ClientRectangle, Label_ManageAccount.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };

            Label_Shop.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Shop.ClientRectangle.X, Label_Shop.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Shop.ClientRectangle.Right - cornerRadius, Label_Shop.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Shop.ClientRectangle.Right - cornerRadius, Label_Shop.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Shop.ClientRectangle.X, Label_Shop.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Shop.Region = new Region(path);
                }
                Label_Shop.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Shop.Text, Label_Shop.Font, Label_Shop.ClientRectangle, Label_Shop.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };

            Label_Appointment.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Appointment.ClientRectangle.X, Label_Appointment.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Appointment.ClientRectangle.Right - cornerRadius, Label_Appointment.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Appointment.ClientRectangle.Right - cornerRadius, Label_Appointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Appointment.ClientRectangle.X, Label_Appointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Appointment.Region = new Region(path);
                }
                Label_Appointment.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Appointment.Text, Label_Appointment.Font, Label_Appointment.ClientRectangle, Label_Appointment.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };


            Label_History.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_History.ClientRectangle.X, Label_History.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_History.ClientRectangle.Right - cornerRadius, Label_History.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_History.ClientRectangle.Right - cornerRadius, Label_History.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_History.ClientRectangle.X, Label_History.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_History.Region = new Region(path);
                }
                Label_History.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_History.Text, Label_History.Font, Label_History.ClientRectangle, Label_History.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };


            Label_Homepage.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Homepage.ClientRectangle.X, Label_Homepage.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Homepage.ClientRectangle.Right - cornerRadius, Label_Homepage.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Homepage.ClientRectangle.Right - cornerRadius, Label_Homepage.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Homepage.ClientRectangle.X, Label_Homepage.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Homepage.Region = new Region(path);
                }
                Label_Homepage.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Homepage.Text, Label_Homepage.Font, Label_Homepage.ClientRectangle, Label_Homepage.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };

        }///
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void LoadPendingAppointments(string query, DateTime clickeddate)
        {
            panel1.Controls.Clear();
            try
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@dateandtime", clickeddate);


                    SqlDataReader reader = cmd.ExecuteReader();

                    int i = 0;
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Label lblAppointment = new Label();
                            lblAppointment.Text = $"Pet: {reader["PetName"]}  Owner: {reader["OwnerName"]}\nTime: {reader["AppointmentTime"]}";
                            lblAppointment.AutoSize = false;
                            lblAppointment.Size = new Size(425, 70);
                            lblAppointment.TextAlign = ContentAlignment.MiddleCenter;
                            lblAppointment.Font = poppinsFontlinklabel;
                            lblAppointment.Location = new Point(10, 10 + (i * 80));
                            int appID = Convert.ToInt32(reader["appID"]);
                            lblAppointment.Click += (sender, e) => OpenPatientInfoForm(appID);
                            lblAppointment.Paint += (s, e) =>
                            {
                                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                                {
                                    int cornerRadius = 45;
                                    path.AddArc(lblAppointment.ClientRectangle.X, lblAppointment.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                                    path.AddArc(lblAppointment.ClientRectangle.Right - cornerRadius, lblAppointment.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                                    path.AddArc(lblAppointment.ClientRectangle.Right - cornerRadius, lblAppointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                                    path.AddArc(lblAppointment.ClientRectangle.X, lblAppointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                                    path.CloseFigure();
                                    lblAppointment.Region = new Region(path);
                                }
                                lblAppointment.BackColor = Color.FromArgb(255, 245, 233);

                            };
                            panel1.Controls.Add(lblAppointment);
                            i++;
                        }
                    }
                    else
                    {
                        Label lblAppointment = new Label();
                        lblAppointment.Text = "There Are No Appointments For This Day!";
                        lblAppointment.AutoSize = false;
                        lblAppointment.Size = new Size(425, 200);
                        lblAppointment.TextAlign = ContentAlignment.MiddleCenter;
                        lblAppointment.Font = monthtext;
                        lblAppointment.Paint += (s, e) =>
                        {
                            using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                            {
                                int cornerRadius = 45;
                                path.AddArc(lblAppointment.ClientRectangle.X, lblAppointment.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                                path.AddArc(lblAppointment.ClientRectangle.Right - cornerRadius, lblAppointment.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                                path.AddArc(lblAppointment.ClientRectangle.Right - cornerRadius, lblAppointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                                path.AddArc(lblAppointment.ClientRectangle.X, lblAppointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                                path.CloseFigure();
                                lblAppointment.Region = new Region(path);
                            }
                            lblAppointment.BackColor = Color.FromArgb(255, 245, 233);

                        };
                        panel1.Controls.Add(lblAppointment);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading appointments: " + ex.Message);
            }
            finally { conn.Close(); }
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void OpenPatientInfoForm(int appID)
        {
            PatientInfoForm patientInfoForm = new PatientInfoForm(appID);
            patientInfoForm.Show();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void Label_History_Click(object sender, EventArgs e)
        {
            int userid = this.userid;
            HistoryRecordsPending history = new HistoryRecordsPending(userid);
            history.Show();
            this.Hide();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Rectangle rectangle = new Rectangle(0, 0, 1080, 160); // X, Y, Width, Height

            // Create a semi-transparent brush
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(151, 97, 51))) // 128 = 50% opacity, Green color
            {
                // Draw the rectangle in the specified position
                e.Graphics.FillRectangle(brush, rectangle);
            }
            using (Pen pen = new Pen(Color.Black, 2)) // Black border with 3px thickness
            {
                e.Graphics.DrawRectangle(pen, rectangle);
            }
        }

        private void Homepage_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (month == 1) { year--; month = 12; calendar(); }
            else
            {
                DayContainer.Controls.Clear();
                month--;
                calendar();
            }

        }

        private void Button_Next_Click(object sender, EventArgs e)
        {
            if (month == 12) { year++; month = 1; calendar(); }
            else
            {
                DayContainer.Controls.Clear();
                month++;
                calendar();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(comboBox_Year.Text))
            {
                return;
            }

            if (!int.TryParse(comboBox_Year.Text, out year))
            {
                return;
            }
            string cmonth = comboBox_Month.Text;
            month = getmonth(cmonth);
            calendar();
        }
        private int getmonth(string cmonth)
        {
            if (cmonth == "December")
            { return 12; }
            else if (cmonth == "November")
            { return 11; }
            else if (cmonth == "October")
            { return 10; }
            else if (cmonth == "September")
            { return 9; }
            else if (cmonth == "August")
            { return 8; }
            else if (cmonth == "July")
            { return 7; }
            else if (cmonth == "June")
            { return 6; }
            else if (cmonth == "May")
            { return 5; }
            else if (cmonth == "April")
            { return 4; }
            else if (cmonth == "March")
            { return 3; }
            else if (cmonth == "February")
            { return 2; }
            else { return 1; }

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            year = Convert.ToInt32(comboBox_Year.Text);
            string cmonth = comboBox_Month.Text;
            month = getmonth(cmonth);
            calendar();
        }

        private void Label_Shop_Click(object sender, EventArgs e)
        {
            staff_inventory staffinvent = new staff_inventory(userid);

            staffinvent.Show();
            this.Hide();
        }
    }
}
