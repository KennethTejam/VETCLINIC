﻿namespace Appointment1
{
    partial class AddRecord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddRecord));
            Label_Homepage = new Label();
            Label_ManageAccount = new Label();
            Label_Appointment = new Label();
            Label_History = new Label();
            Label_Welcome = new Label();
            Label_Email = new Label();
            TextBox_Breed = new TextBox();
            TextBox_PetName = new TextBox();
            Button_AddToRecord = new Button();
            Label_Note = new Label();
            Label_Owner = new Label();
            Label_Breed = new Label();
            Label_Contact = new Label();
            label3 = new Label();
            Label_Birthday = new Label();
            Label_PetName = new Label();
            TextBox_Email = new TextBox();
            TextBox_Contact = new TextBox();
            TextBox_Owner = new TextBox();
            RadioButton_Male = new RadioButton();
            RadioButton_Female = new RadioButton();
            TextBox_Birthday = new DateTimePicker();
            medpanel = new Panel();
            btnAdd = new Button();
            btnDelete = new Button();
            Label_Shop = new Label();
            pictureBox5 = new PictureBox();
            Label_Gender = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = SystemColors.Control;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = SystemColors.ControlText;
            Label_Homepage.Location = new Point(34, 121);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Padding = new Padding(10, 3, 10, 3);
            Label_Homepage.Size = new Size(130, 31);
            Label_Homepage.TabIndex = 21;
            Label_Homepage.Text = "Homepage";
            Label_Homepage.Click += Label_Homepage_Click;
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.Location = new Point(650, 121);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Padding = new Padding(10, 3, 10, 3);
            Label_ManageAccount.Size = new Size(183, 31);
            Label_ManageAccount.TabIndex = 17;
            Label_ManageAccount.Text = "Manage Account";
            // 
            // Label_Appointment
            // 
            Label_Appointment.AutoSize = true;
            Label_Appointment.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Appointment.Location = new Point(189, 121);
            Label_Appointment.Name = "Label_Appointment";
            Label_Appointment.Padding = new Padding(10, 3, 10, 3);
            Label_Appointment.Size = new Size(161, 31);
            Label_Appointment.TabIndex = 16;
            Label_Appointment.Text = "Add to Record";
            // 
            // Label_History
            // 
            Label_History.AutoSize = true;
            Label_History.BackColor = SystemColors.Control;
            Label_History.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_History.ForeColor = SystemColors.ControlText;
            Label_History.Location = new Point(351, 121);
            Label_History.Name = "Label_History";
            Label_History.Padding = new Padding(10, 3, 10, 3);
            Label_History.Size = new Size(174, 31);
            Label_History.TabIndex = 15;
            Label_History.Text = "History Records";
            Label_History.Click += Label_History_Click;
            // 
            // Label_Welcome
            // 
            Label_Welcome.AutoSize = true;
            Label_Welcome.BackColor = Color.Transparent;
            Label_Welcome.Font = new Font("Sitka Subheading", 36F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Label_Welcome.Location = new Point(58, -5);
            Label_Welcome.Name = "Label_Welcome";
            Label_Welcome.Size = new Size(286, 69);
            Label_Welcome.TabIndex = 13;
            Label_Welcome.Text = "WELCOME!";
            // 
            // Label_Email
            // 
            Label_Email.AutoSize = true;
            Label_Email.BackColor = Color.Transparent;
            Label_Email.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Email.Location = new Point(59, 500);
            Label_Email.Name = "Label_Email";
            Label_Email.Size = new Size(89, 30);
            Label_Email.TabIndex = 37;
            Label_Email.Text = "EMAIL: ";
            // 
            // TextBox_Breed
            // 
            TextBox_Breed.BackColor = SystemColors.Window;
            TextBox_Breed.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            TextBox_Breed.Location = new Point(254, 242);
            TextBox_Breed.Margin = new Padding(3, 0, 3, 3);
            TextBox_Breed.Multiline = true;
            TextBox_Breed.Name = "TextBox_Breed";
            TextBox_Breed.Size = new Size(271, 28);
            TextBox_Breed.TabIndex = 29;
            TextBox_Breed.TextChanged += TextBox_Breed_TextChanged;
            // 
            // TextBox_PetName
            // 
            TextBox_PetName.BackColor = SystemColors.Window;
            TextBox_PetName.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            TextBox_PetName.Location = new Point(254, 212);
            TextBox_PetName.Margin = new Padding(3, 0, 3, 3);
            TextBox_PetName.Multiline = true;
            TextBox_PetName.Name = "TextBox_PetName";
            TextBox_PetName.Size = new Size(271, 28);
            TextBox_PetName.TabIndex = 28;
            TextBox_PetName.TextChanged += TextBox_PetName_TextChanged;
            // 
            // Button_AddToRecord
            // 
            Button_AddToRecord.Enabled = false;
            Button_AddToRecord.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Button_AddToRecord.Location = new Point(796, 596);
            Button_AddToRecord.Name = "Button_AddToRecord";
            Button_AddToRecord.Size = new Size(189, 75);
            Button_AddToRecord.TabIndex = 39;
            Button_AddToRecord.Text = "ADD TO RECORD";
            Button_AddToRecord.UseVisualStyleBackColor = true;
            Button_AddToRecord.Click += Button_AddToRecord_Click;
            // 
            // Label_Note
            // 
            Label_Note.AutoSize = true;
            Label_Note.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Note.Location = new Point(733, 196);
            Label_Note.Name = "Label_Note";
            Label_Note.Size = new Size(283, 30);
            Label_Note.TabIndex = 40;
            Label_Note.Text = "NOTE: (MEDICAL HISTORY)";
            // 
            // Label_Owner
            // 
            Label_Owner.AutoSize = true;
            Label_Owner.BackColor = Color.Transparent;
            Label_Owner.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Owner.Location = new Point(59, 442);
            Label_Owner.Name = "Label_Owner";
            Label_Owner.Size = new Size(173, 30);
            Label_Owner.TabIndex = 41;
            Label_Owner.Text = "OWNER NAME: ";
            // 
            // Label_Breed
            // 
            Label_Breed.AutoSize = true;
            Label_Breed.BackColor = Color.Transparent;
            Label_Breed.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Breed.Location = new Point(58, 243);
            Label_Breed.Name = "Label_Breed";
            Label_Breed.Size = new Size(77, 30);
            Label_Breed.TabIndex = 42;
            Label_Breed.Text = "BREED";
            // 
            // Label_Contact
            // 
            Label_Contact.AutoSize = true;
            Label_Contact.BackColor = Color.Transparent;
            Label_Contact.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Contact.Location = new Point(58, 470);
            Label_Contact.Name = "Label_Contact";
            Label_Contact.Size = new Size(206, 30);
            Label_Contact.TabIndex = 43;
            Label_Contact.Text = "CONTACT NUMBER";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold);
            label3.Location = new Point(135, 472);
            label3.Name = "label3";
            label3.Size = new Size(0, 40);
            label3.TabIndex = 44;
            // 
            // Label_Birthday
            // 
            Label_Birthday.AutoSize = true;
            Label_Birthday.BackColor = Color.Transparent;
            Label_Birthday.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Birthday.Location = new Point(58, 273);
            Label_Birthday.Name = "Label_Birthday";
            Label_Birthday.Size = new Size(158, 30);
            Label_Birthday.TabIndex = 45;
            Label_Birthday.Text = "PET BIRTHDAY";
            // 
            // Label_PetName
            // 
            Label_PetName.AutoSize = true;
            Label_PetName.BackColor = Color.Transparent;
            Label_PetName.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_PetName.Location = new Point(58, 213);
            Label_PetName.Name = "Label_PetName";
            Label_PetName.Size = new Size(118, 30);
            Label_PetName.TabIndex = 47;
            Label_PetName.Text = "PET NAME";
            // 
            // TextBox_Email
            // 
            TextBox_Email.BackColor = SystemColors.Window;
            TextBox_Email.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            TextBox_Email.Location = new Point(271, 500);
            TextBox_Email.Margin = new Padding(3, 0, 3, 3);
            TextBox_Email.Multiline = true;
            TextBox_Email.Name = "TextBox_Email";
            TextBox_Email.Size = new Size(254, 26);
            TextBox_Email.TabIndex = 50;
            TextBox_Email.TextChanged += TextBox_Email_TextChanged;
            // 
            // TextBox_Contact
            // 
            TextBox_Contact.BackColor = SystemColors.Window;
            TextBox_Contact.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            TextBox_Contact.Location = new Point(271, 470);
            TextBox_Contact.Margin = new Padding(3, 0, 3, 3);
            TextBox_Contact.Multiline = true;
            TextBox_Contact.Name = "TextBox_Contact";
            TextBox_Contact.Size = new Size(254, 26);
            TextBox_Contact.TabIndex = 49;
            TextBox_Contact.TextChanged += TextBox_ContactNumber_TextChanged;
            // 
            // TextBox_Owner
            // 
            TextBox_Owner.BackColor = SystemColors.Window;
            TextBox_Owner.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            TextBox_Owner.Location = new Point(272, 441);
            TextBox_Owner.Margin = new Padding(3, 0, 3, 3);
            TextBox_Owner.Multiline = true;
            TextBox_Owner.Name = "TextBox_Owner";
            TextBox_Owner.Size = new Size(253, 26);
            TextBox_Owner.TabIndex = 48;
            TextBox_Owner.TextChanged += TextBox_Owner_TextChanged;
            // 
            // RadioButton_Male
            // 
            RadioButton_Male.AutoSize = true;
            RadioButton_Male.BackColor = Color.Transparent;
            RadioButton_Male.Font = new Font("Microsoft Sans Serif", 14.25F);
            RadioButton_Male.Location = new Point(254, 303);
            RadioButton_Male.Name = "RadioButton_Male";
            RadioButton_Male.Size = new Size(69, 28);
            RadioButton_Male.TabIndex = 52;
            RadioButton_Male.Text = "Male";
            RadioButton_Male.UseVisualStyleBackColor = false;
            RadioButton_Male.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // RadioButton_Female
            // 
            RadioButton_Female.AutoSize = true;
            RadioButton_Female.BackColor = Color.Transparent;
            RadioButton_Female.Font = new Font("Microsoft Sans Serif", 14.25F);
            RadioButton_Female.Location = new Point(433, 303);
            RadioButton_Female.Name = "RadioButton_Female";
            RadioButton_Female.Size = new Size(92, 28);
            RadioButton_Female.TabIndex = 53;
            RadioButton_Female.TabStop = true;
            RadioButton_Female.Text = "Female";
            RadioButton_Female.UseVisualStyleBackColor = false;
            RadioButton_Female.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // TextBox_Birthday
            // 
            TextBox_Birthday.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            TextBox_Birthday.Location = new Point(254, 273);
            TextBox_Birthday.Name = "TextBox_Birthday";
            TextBox_Birthday.Size = new Size(271, 31);
            TextBox_Birthday.TabIndex = 54;
            TextBox_Birthday.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // medpanel
            // 
            medpanel.AutoScroll = true;
            medpanel.Location = new Point(678, 244);
            medpanel.Margin = new Padding(3, 2, 3, 2);
            medpanel.Name = "medpanel";
            medpanel.Size = new Size(343, 296);
            medpanel.TabIndex = 57;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(859, 545);
            btnAdd.Margin = new Padding(3, 2, 3, 2);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(82, 22);
            btnAdd.TabIndex = 58;
            btnAdd.Text = "add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(733, 545);
            btnDelete.Margin = new Padding(3, 2, 3, 2);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(82, 22);
            btnDelete.TabIndex = 59;
            btnDelete.Text = "delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // Label_Shop
            // 
            Label_Shop.AutoSize = true;
            Label_Shop.BackColor = Color.Transparent;
            Label_Shop.Cursor = Cursors.Hand;
            Label_Shop.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Shop.ForeColor = Color.Black;
            Label_Shop.ImageAlign = ContentAlignment.MiddleRight;
            Label_Shop.Location = new Point(547, 121);
            Label_Shop.Name = "Label_Shop";
            Label_Shop.Padding = new Padding(10, 3, 10, 3);
            Label_Shop.Size = new Size(78, 31);
            Label_Shop.TabIndex = 123;
            Label_Shop.Text = "Shop";
            Label_Shop.Click += Label_Shop_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.Transparent;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(747, 12);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(291, 95);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 125;
            pictureBox5.TabStop = false;
            // 
            // Label_Gender
            // 
            Label_Gender.AutoSize = true;
            Label_Gender.BackColor = Color.Transparent;
            Label_Gender.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Gender.Location = new Point(58, 303);
            Label_Gender.Name = "Label_Gender";
            Label_Gender.Size = new Size(96, 30);
            Label_Gender.TabIndex = 126;
            Label_Gender.Text = "GENDER";
            // 
            // AddRecord
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 681);
            Controls.Add(Label_Gender);
            Controls.Add(pictureBox5);
            Controls.Add(Label_Shop);
            Controls.Add(btnDelete);
            Controls.Add(btnAdd);
            Controls.Add(medpanel);
            Controls.Add(TextBox_Birthday);
            Controls.Add(RadioButton_Female);
            Controls.Add(RadioButton_Male);
            Controls.Add(TextBox_Email);
            Controls.Add(TextBox_Contact);
            Controls.Add(TextBox_Owner);
            Controls.Add(Label_Email);
            Controls.Add(TextBox_Breed);
            Controls.Add(TextBox_PetName);
            Controls.Add(Button_AddToRecord);
            Controls.Add(Label_Note);
            Controls.Add(Label_Owner);
            Controls.Add(Label_Breed);
            Controls.Add(Label_Contact);
            Controls.Add(label3);
            Controls.Add(Label_Birthday);
            Controls.Add(Label_PetName);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_Appointment);
            Controls.Add(Label_History);
            Controls.Add(Label_Welcome);
            Name = "AddRecord";
            Text = "Form1";
            Load += AddRecord_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label Label_Homepage;
        private Label Label_ManageAccount;
        private Label Label_Appointment;
        private Label Label_History;
        private Label Label_Welcome;
        private Label Label_Email;
        private TextBox TextBox_Breed;
        private TextBox TextBox_PetName;
        private Button Button_AddToRecord;
        private Label Label_Note;
        private Label Label_Owner;
        private Label Label_Breed;
        private Label Label_Contact;
        private Label label3;
        private Label Label_Birthday;
        private Label Label_PetName;
        private TextBox TextBox_Email;
        private TextBox TextBox_Contact;
        private TextBox TextBox_Owner;
        private RadioButton RadioButton_Male;
        private RadioButton RadioButton_Female;
        private DateTimePicker TextBox_Birthday;
        private Panel medpanel;
        private Button btnAdd;
        private Button btnDelete;
        private Label Label_Shop;
        private PictureBox pictureBox5;
        private Label Label_Gender;
    }
}