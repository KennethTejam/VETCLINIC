﻿namespace Appointment1
{
    partial class frmAppointments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtServices = new TextBox();
            btnNext = new Button();
            receiptPanel = new Panel();
            lblBreed = new Label();
            lblOwner = new Label();
            lblEmail = new Label();
            lblContact = new Label();
            lblAge = new Label();
            lblGender = new Label();
            lblPet = new Label();
            txtEmail = new TextBox();
            txtContact = new TextBox();
            txtAge = new TextBox();
            txtPetBreed = new TextBox();
            txtGender = new TextBox();
            txtPetName = new TextBox();
            txtOwnerName = new TextBox();
            txtDate = new TextBox();
            txtStatus = new TextBox();
            lblDate = new Label();
            lblStatus = new Label();
            lblPending = new Label();
            SuspendLayout();
            // 
            // txtServices
            // 
            txtServices.Location = new Point(15, 512);
            txtServices.Margin = new Padding(3, 2, 3, 2);
            txtServices.Multiline = true;
            txtServices.Name = "txtServices";
            txtServices.ReadOnly = true;
            txtServices.Size = new Size(188, 132);
            txtServices.TabIndex = 44;
            // 
            // btnNext
            // 
            btnNext.Location = new Point(549, 451);
            btnNext.Margin = new Padding(3, 2, 3, 2);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(115, 89);
            btnNext.TabIndex = 56;
            btnNext.Text = "Next";
            btnNext.UseVisualStyleBackColor = true;
            btnNext.Visible = false;
            btnNext.Click += btnNext_Click;
            // 
            // receiptPanel
            // 
            receiptPanel.AutoScroll = true;
            receiptPanel.Location = new Point(412, 37);
            receiptPanel.Margin = new Padding(3, 2, 3, 2);
            receiptPanel.Name = "receiptPanel";
            receiptPanel.Size = new Size(428, 316);
            receiptPanel.TabIndex = 57;
            // 
            // lblBreed
            // 
            lblBreed.AutoSize = true;
            lblBreed.BackColor = Color.Transparent;
            lblBreed.Font = new Font("Segoe UI", 14.25F);
            lblBreed.Location = new Point(19, 150);
            lblBreed.Name = "lblBreed";
            lblBreed.Size = new Size(71, 25);
            lblBreed.TabIndex = 104;
            lblBreed.Text = "BREED:";
            // 
            // lblOwner
            // 
            lblOwner.AutoSize = true;
            lblOwner.BackColor = Color.Transparent;
            lblOwner.Font = new Font("Segoe UI", 14.25F);
            lblOwner.Location = new Point(19, 57);
            lblOwner.Name = "lblOwner";
            lblOwner.Size = new Size(83, 25);
            lblOwner.TabIndex = 103;
            lblOwner.Text = "OWNER:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.BackColor = Color.Transparent;
            lblEmail.Font = new Font("Segoe UI", 14.25F);
            lblEmail.Location = new Point(19, 328);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(69, 25);
            lblEmail.TabIndex = 102;
            lblEmail.Text = "EMAIL:";
            // 
            // lblContact
            // 
            lblContact.AutoSize = true;
            lblContact.BackColor = Color.Transparent;
            lblContact.Font = new Font("Segoe UI", 14.25F);
            lblContact.Location = new Point(19, 289);
            lblContact.Name = "lblContact";
            lblContact.Size = new Size(179, 25);
            lblContact.TabIndex = 101;
            lblContact.Text = "CONTACT NUMBER:";
            // 
            // lblAge
            // 
            lblAge.AutoSize = true;
            lblAge.BackColor = Color.Transparent;
            lblAge.Font = new Font("Segoe UI", 14.25F);
            lblAge.Location = new Point(19, 241);
            lblAge.Name = "lblAge";
            lblAge.Size = new Size(51, 25);
            lblAge.TabIndex = 100;
            lblAge.Text = "AGE:";
            // 
            // lblGender
            // 
            lblGender.AutoSize = true;
            lblGender.BackColor = Color.Transparent;
            lblGender.Font = new Font("Segoe UI", 14.25F);
            lblGender.Location = new Point(19, 190);
            lblGender.Name = "lblGender";
            lblGender.Size = new Size(87, 25);
            lblGender.TabIndex = 99;
            lblGender.Text = "GENDER:";
            // 
            // lblPet
            // 
            lblPet.AutoSize = true;
            lblPet.BackColor = Color.Transparent;
            lblPet.Font = new Font("Segoe UI", 14.25F);
            lblPet.Location = new Point(19, 103);
            lblPet.Name = "lblPet";
            lblPet.Size = new Size(47, 25);
            lblPet.TabIndex = 98;
            lblPet.Text = "PET:";
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Segoe UI", 14.25F);
            txtEmail.Location = new Point(204, 327);
            txtEmail.Margin = new Padding(3, 2, 3, 2);
            txtEmail.Name = "txtEmail";
            txtEmail.ReadOnly = true;
            txtEmail.Size = new Size(142, 33);
            txtEmail.TabIndex = 97;
            // 
            // txtContact
            // 
            txtContact.Font = new Font("Segoe UI", 14.25F);
            txtContact.Location = new Point(204, 288);
            txtContact.Margin = new Padding(3, 2, 3, 2);
            txtContact.Name = "txtContact";
            txtContact.ReadOnly = true;
            txtContact.Size = new Size(142, 33);
            txtContact.TabIndex = 96;
            // 
            // txtAge
            // 
            txtAge.Font = new Font("Segoe UI", 14.25F);
            txtAge.Location = new Point(204, 240);
            txtAge.Margin = new Padding(3, 2, 3, 2);
            txtAge.Name = "txtAge";
            txtAge.ReadOnly = true;
            txtAge.Size = new Size(142, 33);
            txtAge.TabIndex = 95;
            // 
            // txtPetBreed
            // 
            txtPetBreed.Font = new Font("Segoe UI", 14.25F);
            txtPetBreed.Location = new Point(204, 147);
            txtPetBreed.Margin = new Padding(3, 2, 3, 2);
            txtPetBreed.Name = "txtPetBreed";
            txtPetBreed.ReadOnly = true;
            txtPetBreed.Size = new Size(142, 33);
            txtPetBreed.TabIndex = 94;
            // 
            // txtGender
            // 
            txtGender.Font = new Font("Segoe UI", 14.25F);
            txtGender.Location = new Point(204, 192);
            txtGender.Margin = new Padding(3, 2, 3, 2);
            txtGender.Name = "txtGender";
            txtGender.ReadOnly = true;
            txtGender.Size = new Size(142, 33);
            txtGender.TabIndex = 93;
            // 
            // txtPetName
            // 
            txtPetName.Font = new Font("Segoe UI", 14.25F);
            txtPetName.Location = new Point(204, 99);
            txtPetName.Margin = new Padding(3, 2, 3, 2);
            txtPetName.Name = "txtPetName";
            txtPetName.ReadOnly = true;
            txtPetName.Size = new Size(142, 33);
            txtPetName.TabIndex = 92;
            // 
            // txtOwnerName
            // 
            txtOwnerName.Font = new Font("Segoe UI", 14.25F);
            txtOwnerName.Location = new Point(204, 51);
            txtOwnerName.Margin = new Padding(3, 2, 3, 2);
            txtOwnerName.Name = "txtOwnerName";
            txtOwnerName.ReadOnly = true;
            txtOwnerName.Size = new Size(142, 33);
            txtOwnerName.TabIndex = 91;
            // 
            // txtDate
            // 
            txtDate.Font = new Font("Segoe UI", 14.25F);
            txtDate.Location = new Point(204, 364);
            txtDate.Margin = new Padding(3, 2, 3, 2);
            txtDate.Name = "txtDate";
            txtDate.ReadOnly = true;
            txtDate.Size = new Size(162, 33);
            txtDate.TabIndex = 105;
            // 
            // txtStatus
            // 
            txtStatus.Font = new Font("Segoe UI", 14.25F);
            txtStatus.Location = new Point(204, 401);
            txtStatus.Margin = new Padding(3, 2, 3, 2);
            txtStatus.Name = "txtStatus";
            txtStatus.ReadOnly = true;
            txtStatus.Size = new Size(142, 33);
            txtStatus.TabIndex = 106;
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.BackColor = Color.Transparent;
            lblDate.Font = new Font("Segoe UI", 14.25F);
            lblDate.Location = new Point(21, 372);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(60, 25);
            lblDate.TabIndex = 107;
            lblDate.Text = "DATE:";
            lblDate.Click += label1_Click;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.BackColor = Color.Transparent;
            lblStatus.Font = new Font("Segoe UI", 14.25F);
            lblStatus.Location = new Point(21, 409);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(79, 25);
            lblStatus.TabIndex = 108;
            lblStatus.Text = "STATUS:";
            // 
            // lblPending
            // 
            lblPending.AutoSize = true;
            lblPending.BackColor = Color.Transparent;
            lblPending.Font = new Font("Segoe UI", 14.25F);
            lblPending.ForeColor = SystemColors.ButtonHighlight;
            lblPending.Location = new Point(21, 469);
            lblPending.Name = "lblPending";
            lblPending.Size = new Size(171, 25);
            lblPending.TabIndex = 109;
            lblPending.Text = "PENDING SERVICE:";
            // 
            // frmAppointments
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(852, 697);
            Controls.Add(lblPending);
            Controls.Add(lblStatus);
            Controls.Add(lblDate);
            Controls.Add(txtStatus);
            Controls.Add(txtDate);
            Controls.Add(lblBreed);
            Controls.Add(lblOwner);
            Controls.Add(lblEmail);
            Controls.Add(lblContact);
            Controls.Add(lblAge);
            Controls.Add(lblGender);
            Controls.Add(lblPet);
            Controls.Add(txtEmail);
            Controls.Add(txtContact);
            Controls.Add(txtAge);
            Controls.Add(txtPetBreed);
            Controls.Add(txtGender);
            Controls.Add(txtPetName);
            Controls.Add(txtOwnerName);
            Controls.Add(receiptPanel);
            Controls.Add(btnNext);
            Controls.Add(txtServices);
            Margin = new Padding(3, 2, 3, 2);
            Name = "frmAppointments";
            Text = "Form4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label10;
        private TextBox txtServices;
        private Button btnNext;
        private Panel receiptPanel;
        private Label lblBreed;
        private Label lblOwner;
        private Label lblEmail;
        private Label lblContact;
        private Label lblAge;
        private Label lblGender;
        private Label lblPet;
        private TextBox txtEmail;
        private TextBox txtContact;
        private TextBox txtAge;
        private TextBox txtPetBreed;
        private TextBox txtGender;
        private TextBox txtPetName;
        private TextBox txtOwnerName;
        private TextBox txtDate;
        private TextBox txtStatus;
        private Label lblDate;
        private Label lblStatus;
        private Label lblPending;
    }
}