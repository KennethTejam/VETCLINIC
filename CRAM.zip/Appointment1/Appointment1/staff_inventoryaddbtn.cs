﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Appointment1
{
    public partial class staff_inventoryaddbtn : Form
    {
        PROCESSES process = new PROCESSES();
        PrivateFontCollection privateFonts;
        PrivateFontCollection privateFontsbold;
        ContextMenuStrip contextMenu = new ContextMenuStrip();
        ContextMenuStrip recordMenu = new ContextMenuStrip();
        Font poppinsFont;
        Font poppinsFontlinklabel;
        Font poppinsFontcal;
        Font monthtext;
        Font sidebtns;
        public staff_inventoryaddbtn()
        {
            InitializeComponent();
            this.BackColor = Color.FromArgb(255, 243, 233);
            setFont();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        public void setFont()
        {
            privateFonts = new PrivateFontCollection();
            privateFontsbold = new PrivateFontCollection();
            privateFonts.AddFontFile("Poppins-Regular.ttf");
            privateFontsbold.AddFontFile("Poppins-ExtraBold.ttf");
            poppinsFont = new Font(privateFontsbold.Families[0], 55f);
            poppinsFontlinklabel = new Font(privateFonts.Families[0], 12f);
            poppinsFontcal = new Font(privateFonts.Families[0], 9f);
            monthtext = new Font(privateFonts.Families[0], 11f);
            sidebtns = new Font(privateFonts.Families[0], 13f);
            TextBox_Pname.Font = monthtext;
            TextBox_Price.Font = monthtext;
            ComboBox_Ptype.Font = monthtext;
            Numeric_Qty.Font = monthtext;

            label1.Font = monthtext;
            Label_Qty.Font = monthtext;
            Label_ProductName.Font = monthtext;
            Label_Price.Font = monthtext;
            Label_AddToInventory.Font = sidebtns;

            Button_Add.Font = sidebtns;
            Button_Cancel.Font = sidebtns;
            Button_Add.BackColor = Color.FromArgb(255, 243, 233); ;
            Button_Cancel.BackColor = Color.FromArgb(255, 243, 233); ;
            TextBox_Pname.BackColor = Color.FromArgb(255, 243, 233);
            ComboBox_Ptype.BackColor = Color.FromArgb(255, 243, 233);
            TextBox_Price.BackColor = Color.FromArgb(255, 243, 233);
            Numeric_Qty.BackColor = Color.FromArgb(255, 243, 233);
        }



        private void Button_ADD_Click(object sender, EventArgs e)
        {
            string txt = TextBox_Pname.Text.Trim();

            int price;
            bool isPriceValid = int.TryParse(TextBox_Price.Text, out price);

            string cmb = ComboBox_Ptype.Text.Trim();

            int cntr = (int)Numeric_Qty.Value;
            bool isQtyValid = int.TryParse(Numeric_Qty.Text, out price);

            if (string.IsNullOrWhiteSpace(txt) || !isPriceValid  || string.IsNullOrWhiteSpace(cmb) || !isQtyValid)
                MessageBox.Show("Fill up the required product details!");
            else
            {
                txt = char.ToUpper(txt[0]) + txt.Substring(1).ToLower();
                process.addToInventory(txt, price, cmb, cntr);
                this.Close();
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            int length = TextBox_Price.Text.Length;
            string text = TextBox_Price.Text;

            if (int.TryParse(TextBox_Price.Text, out int pin) && pin >= 0)
            {
            }
            else if (TextBox_Price.Text == "")
            {
            }
            else
            {
                TextBox_Price.Text = TextBox_Price.Text.Substring(0, length - 1);
            }
        }

        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Rectangle rectangle = new Rectangle(40, 30, 350, 350); // X, Y, Width, Height

            // Create a semi-transparent brush
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(233, 200, 168))) // 128 = 50% opacity, Green color
            {
                // Draw the rectangle in the specified position
                e.Graphics.FillRectangle(brush, rectangle);
            }

        }
    }
}
