﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Appointment1
{
    public partial class UserControldays : UserControl
    {

        Font poppinsFont;
        SqlConnection conn;
        PROCESSES process = new PROCESSES();
        int year, month;
        public UserControldays()
        {

            InitializeComponent();
            setfont();
            conn = process.getConnection();

        }

        private void UserControldays_Load(object sender, EventArgs e)
        {

        }
        public void setfont()
        {
            PrivateFontCollection privateFontsbold = new PrivateFontCollection();
            privateFontsbold.AddFontFile("Poppins-ExtraBold.ttf");
            poppinsFont = new Font(privateFontsbold.Families[0], 12f);
            Label_Day.Font = poppinsFont;
        }
        public void days(int numday, int month, int year)
        {
            DateTime date = new DateTime(year, month, numday);
            this.year = year;
            this.month = month;

            string query = @"
                SELECT appID, pname AS PetName, oname AS OwnerName, 
                       CONVERT(VARCHAR, appTime, 100) AS AppointmentTime
                FROM Appointments  
                WHERE appDate = @dateandtime";
            int cntr = LoadPendingAppointments(query, date);
            if (cntr >=5)
            {
                Label_Day.ForeColor = Color.Red;
                Label_Day.Text = numday + "";
            }
            else if (cntr >=2 && cntr <= 4)
            {
                Label_Day.ForeColor = Color.OrangeRed;
                Label_Day.Text = numday + "";
            }
            else if (cntr == 1)
            {
                Label_Day.ForeColor = Color.Orange;
                Label_Day.Text = numday + "";
            }
            else {
                Label_Day.ForeColor = Color.Black;
                Label_Day.Text = numday + "";
            }
        }

        /*panel1.Controls.Clear();
            string query = @"
                SELECT appID, pname AS PetName, oname AS OwnerName, 
                       CONVERT(VARCHAR, appTime, 100) AS AppointmentTime
                FROM Appointments  
                WHERE appDate = @dateandtime AND status = 'Pending'";
            LoadPendingAppointments(query);*/


        public int LoadPendingAppointments(string query, DateTime date)
        {
            try
            {
                SqlCommand cmd;
                using (cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@dateandtime", date);
                }
                SqlDataAdapter sda = new SqlDataAdapter(cmd);

                DataTable dtable = new DataTable();
                sda.Fill(dtable);
                return dtable.Rows.Count;
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
                return -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
                return -1;
            }
            finally { conn.Close(); }
        }

    }

}