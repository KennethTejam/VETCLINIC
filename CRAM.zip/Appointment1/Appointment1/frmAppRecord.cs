﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Drawing.Text;

namespace Appointment1
{
    public partial class frmAppRecord : Form
    {
        private int appID;
        int userid;
        PROCESSES process = new PROCESSES();
        SqlConnection conn;
        string ownerName;
        string petName;
        string breed;
        DateTime birthday;
        string gender;
        string contactNo;
        string email;


        PrivateFontCollection privateFonts;
        PrivateFontCollection privateFontsbold;

        Font poppinsFont;
        Font poppinsFontlinklabel;
        Font poppinsFontlinklabeltxtbx;

        public frmAppRecord(int appID)
        {
            this.appID = appID;
            this.BackColor = Color.FromArgb(218, 177, 126);
            InitializeComponent();
            conn = process.getConnection();
            FetchAndAssignAppointmentDetails();
            setFont();
        }

        public void setFont()
        {
            privateFonts = new PrivateFontCollection();
            privateFontsbold = new PrivateFontCollection();
            privateFonts.AddFontFile("Poppins-Regular.ttf");
            privateFontsbold.AddFontFile("Poppins-ExtraBold.ttf");
            poppinsFont = new Font(privateFontsbold.Families[0], 55f);
            poppinsFontlinklabel = new Font(privateFonts.Families[0], 12f);
            poppinsFontlinklabeltxtbx = new Font(privateFonts.Families[0], 20f);
          


            lblOwner.Font = poppinsFontlinklabel;
            lblPet.Font = poppinsFontlinklabel;
            lblAge.Font = poppinsFontlinklabel;
            lblGender.Font = poppinsFontlinklabel;
            lblContact.Font = poppinsFontlinklabel;
            lblEmail.Font = poppinsFontlinklabel;
            lblBreed.Font = poppinsFontlinklabel;
            lblPast.Font = poppinsFontlinklabeltxtbx;
            lblUpcoming.Font = poppinsFontlinklabeltxtbx;
          
            txtAge.Font = poppinsFontlinklabel;
            txtOwnerName.Font = poppinsFontlinklabel;
            txtPetName.Font = poppinsFontlinklabel;
            txtPetBreed.Font = poppinsFontlinklabel;
            txtContact.Font = poppinsFontlinklabel;
            txtEmail.Font = poppinsFontlinklabel;
            txtAge.Font = poppinsFontlinklabel;

        }

            public void FetchAndAssignAppointmentDetails()
        {
            string query = @"
    -- Fetch appointment details
    SELECT 
        a.oname, 
        a.pname, 
        a.breed, 
        a.birthday, 
        a.gender, 
        a.contactNo, 
        a.email, 
        a.status
    FROM 
        appointments a
    WHERE 
        a.appID = @appID;

    -- Pending services
    SELECT 
        s.service, FORMAT(s.date, 'MMMM dd, yyyy') AS pendingdate
    FROM 
        schedule s
    WHERE 
        s.appid = @appID AND s.service IS NOT NULL AND s.status = 'Pending'
    ORDER BY 
        s.date ASC;

    -- Done services
    SELECT 
        s.service AS doneservice, FORMAT(s.date, 'MMMM dd, yyyy') AS donedate
    FROM 
        schedule s
    WHERE 
        s.appid = @appID AND s.service IS NOT NULL AND s.status = 'Done'
    ORDER BY 
        s.date ASC;

    -- Past services
    SELECT 
        e.service AS pastservice, FORMAT(e.date, 'MMMM dd, yyyy') AS pastdate
    FROM 
        services e
    WHERE 
        e.appid = @appID
    ORDER BY 
        e.date ASC;
    ";

            try
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@appID", appID);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Fetch and assign appointment details
                        if (reader.Read())
                        {
                            ownerName = reader["oname"] as string ?? "N/A";
                            petName = reader["pname"] as string ?? "N/A";
                            breed = reader["breed"] as string ?? "N/A";
                            birthday = reader["birthday"] != DBNull.Value ? Convert.ToDateTime(reader["birthday"]) : DateTime.MinValue;
                            gender = reader["gender"] as string ?? "N/A";
                            contactNo = reader["contactNo"] as string ?? "N/A";
                            email = reader["email"] as string ?? "N/A";
                          

                            // Update UI
                            UpdateBasicDetails();
                        }

                        // Pending services
                        if (reader.NextResult())
                        {
                            List<string> pendingServices = ReadServices(reader, "service", "pendingdate");
                            UpdatePanel(pendingPanel, pendingServices);
                        }

                        // Done services
                        List<string> doneServices = new List<string>();
                        if (reader.NextResult())
                        {
                            doneServices = ReadServices(reader, "doneservice", "donedate");
                        }

                        // Past services
                        List<string> pastServices = new List<string>();
                        if (reader.NextResult())
                        {
                            pastServices = ReadServices(reader, "pastservice", "pastdate");
                        }

                        // Combine and display done and past services
                        List<string> allServices = new List<string>();
                        allServices.AddRange(pastServices);
                        allServices.AddRange(doneServices);

                        UpdatePanel(receiptPanel, allServices);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error in FetchAndAssignAppointmentDetails: {ex.Message}\n\nStack Trace: {ex.StackTrace}");
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        private List<string> ReadServices(SqlDataReader reader, string serviceField, string dateField)
        {
            List<string> services = new List<string>();

            while (reader.Read())
            {
                string service = reader[serviceField] as string ?? "N/A";
                string date = reader[dateField] as string ?? "N/A";

                if (!string.IsNullOrEmpty(service) && !string.IsNullOrEmpty(date))
                {
                    services.Add($"{service} - {date}");
                }
            }

            return services;
        }

        private void UpdateBasicDetails()
        {
            try
            {
                int age = birthday != DateTime.MinValue ? CalculateAge(birthday) : 0;

                txtOwnerName.Text = ownerName;
                txtPetName.Text = petName;
                txtPetBreed.Text = breed;
                txtAge.Text = age.ToString();
                txtGender.Text = gender;
                txtContact.Text = contactNo;
                txtEmail.Text = email;
            
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating UI elements: {ex.Message}");
            }
        }

        private void UpdatePanel(Panel panel, List<string> services)
        {
            panel.Controls.Clear(); // Clear previous controls

            if (services.Count > 0)
            {
                int yPosition = 10;
                foreach (string service in services)
                {
                    Label lblService = new Label
                    {
                        Text = service,
                        AutoSize = false,
                        Size = new Size(380, 50),
                        TextAlign = ContentAlignment.MiddleCenter,
                        Margin = new Padding(15, 5, 15, 5),
                        Location = new Point(10, 10 + (yPosition * 3)), // Adjusted y-position
                        BackColor = Color.FromArgb(255, 245, 233)
                    };
                    panel.Controls.Add(lblService);
                    yPosition += 20;

                    lblService.Paint += (s, e) =>
                    {
                        using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                        {
                            int cornerRadius = 45;
                            path.AddArc(lblService.ClientRectangle.X, lblService.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                            path.AddArc(lblService.ClientRectangle.Right - cornerRadius, lblService.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                            path.AddArc(lblService.ClientRectangle.Right - cornerRadius, lblService.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                            path.AddArc(lblService.ClientRectangle.X, lblService.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                            path.CloseFigure();
                            lblService.Region = new Region(path);
                        }
                    };
                }

                panel.Visible = true; // Show the panel
            }
            else
            {
                panel.Visible = false; // Hide the panel if no services
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
           
            // Define the dimensions of the rectangle
            Rectangle rectangle = new Rectangle(50, 100, 380, 350); // X, Y, Width, Height
            int cornerRadius = 30; // Radius of the curved corners

            // Create a GraphicsPath for the rounded rectangle
            using (System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath())
            {
                // Top-left corner
                path.AddArc(rectangle.Left, rectangle.Top, cornerRadius * 2, cornerRadius * 2, 180, 90);
                // Top-right corner
                path.AddArc(rectangle.Right - cornerRadius * 2, rectangle.Top, cornerRadius * 2, cornerRadius * 2, 270, 90);
                // Bottom-right corner
                path.AddArc(rectangle.Right - cornerRadius * 2, rectangle.Bottom - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 0, 90);
                // Bottom-left corner
                path.AddArc(rectangle.Left, rectangle.Bottom - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 90, 90);
                path.CloseFigure(); // Close the path to form a complete rounded rectangle



                // Create a semi-transparent brush
                using (SolidBrush brush = new SolidBrush(Color.FromArgb(255, 245, 233))) // 200 = 80% opacity
                {
                    // Fill the rounded rectangle
                    e.Graphics.FillPath(brush, path);
                }


                // Create a pen for the border


            }
        }

        private int CalculateAge(DateTime birthday)
        {
            int age = DateTime.Now.Year - birthday.Year;
            if (DateTime.Now.DayOfYear < birthday.DayOfYear)
            {
                age--;
            }
            return age;
        }
    }
}
