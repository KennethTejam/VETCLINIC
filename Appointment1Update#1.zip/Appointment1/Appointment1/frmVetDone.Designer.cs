﻿namespace Appointment1
{
    partial class frmVetDone
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Label_ManageAccount = new Label();
            Label_History = new Label();
            txtSearch = new TextBox();
            cbSort = new ComboBox();
            lblDone = new Label();
            lblPending = new Label();
            pAppointment = new Panel();
            Label_Homepage = new Label();
            SuspendLayout();
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.BorderStyle = BorderStyle.Fixed3D;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.Location = new Point(795, 139);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Size = new Size(165, 27);
            Label_ManageAccount.TabIndex = 27;
            Label_ManageAccount.Text = "Manage Account";
            Label_ManageAccount.Click += Label_ManageAccount_Click;
            // 
            // Label_History
            // 
            Label_History.AutoSize = true;
            Label_History.BorderStyle = BorderStyle.Fixed3D;
            Label_History.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_History.Location = new Point(630, 139);
            Label_History.Name = "Label_History";
            Label_History.Size = new Size(141, 27);
            Label_History.TabIndex = 26;
            Label_History.Text = "Appointments";
            Label_History.Click += Label_History_Click;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(830, 171);
            txtSearch.Margin = new Padding(3, 2, 3, 2);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(124, 23);
            txtSearch.TabIndex = 25;
            // 
            // cbSort
            // 
            cbSort.FormattingEnabled = true;
            cbSort.Location = new Point(844, 207);
            cbSort.Margin = new Padding(3, 2, 3, 2);
            cbSort.Name = "cbSort";
            cbSort.Size = new Size(133, 23);
            cbSort.TabIndex = 24;
            // 
            // lblDone
            // 
            lblDone.AutoSize = true;
            lblDone.Location = new Point(689, 193);
            lblDone.Name = "lblDone";
            lblDone.Size = new Size(35, 15);
            lblDone.TabIndex = 23;
            lblDone.Text = "Done";
            // 
            // lblPending
            // 
            lblPending.AutoSize = true;
            lblPending.Location = new Point(520, 193);
            lblPending.Name = "lblPending";
            lblPending.Size = new Size(51, 15);
            lblPending.TabIndex = 22;
            lblPending.Text = "Pending";
            lblPending.Click += lblPending_Click;
            // 
            // pAppointment
            // 
            pAppointment.AutoScroll = true;
            pAppointment.Location = new Point(474, 239);
            pAppointment.Margin = new Padding(3, 2, 3, 2);
            pAppointment.Name = "pAppointment";
            pAppointment.Size = new Size(338, 182);
            pAppointment.TabIndex = 21;
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = SystemColors.Control;
            Label_Homepage.BorderStyle = BorderStyle.Fixed3D;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = SystemColors.ControlText;
            Label_Homepage.Location = new Point(493, 139);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Size = new Size(112, 27);
            Label_Homepage.TabIndex = 29;
            Label_Homepage.Text = "Homepage";
            Label_Homepage.Click += Label_Homepage_Click;
            // 
            // frmVetDone
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 681);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_History);
            Controls.Add(txtSearch);
            Controls.Add(cbSort);
            Controls.Add(lblDone);
            Controls.Add(lblPending);
            Controls.Add(pAppointment);
            Margin = new Padding(3, 2, 3, 2);
            Name = "frmVetDone";
            Text = "Form4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label Label_ManageAccount;
        private Label Label_History;
        private TextBox txtSearch;
        private ComboBox cbSort;
        private Label lblDone;
        private Label lblPending;
        private Panel pAppointment;
        private Label Label_Homepage;
    }
}