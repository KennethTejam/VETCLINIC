﻿namespace Appointment1
{
    partial class staff_inventoryaddbtn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Label_AddToInventory = new Label();
            TextBox_Pname = new TextBox();
            Label_ProductName = new Label();
            Label_Qty = new Label();
            Numeric_Qty = new NumericUpDown();
            Label_Price = new Label();
            ComboBox_Ptype = new ComboBox();
            label1 = new Label();
            Button_Add = new Button();
            TextBox_Price = new TextBox();
            Button_Cancel = new Button();
            ((System.ComponentModel.ISupportInitialize)Numeric_Qty).BeginInit();
            SuspendLayout();
            // 
            // Label_AddToInventory
            // 
            Label_AddToInventory.AutoSize = true;
            Label_AddToInventory.BackColor = Color.Transparent;
            Label_AddToInventory.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label_AddToInventory.ForeColor = Color.Black;
            Label_AddToInventory.Location = new Point(110, 70);
            Label_AddToInventory.Name = "Label_AddToInventory";
            Label_AddToInventory.Size = new Size(185, 30);
            Label_AddToInventory.TabIndex = 0;
            Label_AddToInventory.Text = "Add To Inventory";
            // 
            // TextBox_Pname
            // 
            TextBox_Pname.ForeColor = Color.Black;
            TextBox_Pname.Location = new Point(200, 130);
            TextBox_Pname.Name = "TextBox_Pname";
            TextBox_Pname.Size = new Size(173, 23);
            TextBox_Pname.TabIndex = 1;
            // 
            // Label_ProductName
            // 
            Label_ProductName.AutoSize = true;
            Label_ProductName.BackColor = Color.Transparent;
            Label_ProductName.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            Label_ProductName.ForeColor = Color.Black;
            Label_ProductName.Location = new Point(60, 130);
            Label_ProductName.Name = "Label_ProductName";
            Label_ProductName.Size = new Size(124, 21);
            Label_ProductName.TabIndex = 2;
            Label_ProductName.Text = "Product Name:";
            // 
            // Label_Qty
            // 
            Label_Qty.AutoSize = true;
            Label_Qty.BackColor = Color.Transparent;
            Label_Qty.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            Label_Qty.ForeColor = Color.Black;
            Label_Qty.Location = new Point(60, 220);
            Label_Qty.Name = "Label_Qty";
            Label_Qty.Size = new Size(81, 21);
            Label_Qty.TabIndex = 3;
            Label_Qty.Text = "Quantity:";
            // 
            // Numeric_Qty
            // 
            Numeric_Qty.ForeColor = Color.Black;
            Numeric_Qty.Location = new Point(200, 220);
            Numeric_Qty.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            Numeric_Qty.Name = "Numeric_Qty";
            Numeric_Qty.Size = new Size(120, 23);
            Numeric_Qty.TabIndex = 4;
            // 
            // Label_Price
            // 
            Label_Price.AutoSize = true;
            Label_Price.BackColor = Color.Transparent;
            Label_Price.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            Label_Price.ForeColor = Color.Black;
            Label_Price.Location = new Point(60, 265);
            Label_Price.Name = "Label_Price";
            Label_Price.Size = new Size(52, 21);
            Label_Price.TabIndex = 5;
            Label_Price.Text = "Price:";
            // 
            // ComboBox_Ptype
            // 
            ComboBox_Ptype.DropDownStyle = ComboBoxStyle.DropDownList;
            ComboBox_Ptype.ForeColor = Color.Black;
            ComboBox_Ptype.FormattingEnabled = true;
            ComboBox_Ptype.Items.AddRange(new object[] { "Food", "Accessory", "Medicine" });
            ComboBox_Ptype.Location = new Point(200, 175);
            ComboBox_Ptype.Name = "ComboBox_Ptype";
            ComboBox_Ptype.Size = new Size(173, 23);
            ComboBox_Ptype.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(60, 175);
            label1.Name = "label1";
            label1.Size = new Size(114, 21);
            label1.TabIndex = 8;
            label1.Text = "Product Type:";
            // 
            // Button_Add
            // 
            Button_Add.AutoSize = true;
            Button_Add.ForeColor = Color.Black;
            Button_Add.Location = new Point(300, 320);
            Button_Add.Name = "Button_Add";
            Button_Add.Size = new Size(75, 25);
            Button_Add.TabIndex = 9;
            Button_Add.Text = "ADD";
            Button_Add.UseVisualStyleBackColor = true;
            Button_Add.Click += Button_ADD_Click;
            // 
            // TextBox_Price
            // 
            TextBox_Price.ForeColor = Color.Black;
            TextBox_Price.Location = new Point(200, 265);
            TextBox_Price.Name = "TextBox_Price";
            TextBox_Price.Size = new Size(120, 23);
            TextBox_Price.TabIndex = 10;
            TextBox_Price.TextChanged += textBox2_TextChanged;
            // 
            // Button_Cancel
            // 
            Button_Cancel.AutoSize = true;
            Button_Cancel.ForeColor = Color.Black;
            Button_Cancel.Location = new Point(60, 320);
            Button_Cancel.Name = "Button_Cancel";
            Button_Cancel.Size = new Size(75, 25);
            Button_Cancel.TabIndex = 11;
            Button_Cancel.Text = "CANCEL";
            Button_Cancel.UseVisualStyleBackColor = true;
            Button_Cancel.Click += Button_Cancel_Click;
            // 
            // staff_inventoryaddbtn
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(434, 411);
            Controls.Add(Button_Cancel);
            Controls.Add(TextBox_Price);
            Controls.Add(Button_Add);
            Controls.Add(label1);
            Controls.Add(ComboBox_Ptype);
            Controls.Add(Label_Price);
            Controls.Add(Numeric_Qty);
            Controls.Add(Label_Qty);
            Controls.Add(Label_ProductName);
            Controls.Add(TextBox_Pname);
            Controls.Add(Label_AddToInventory);
            Name = "staff_inventoryaddbtn";
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)Numeric_Qty).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Label_AddToInventory;
        private TextBox TextBox_Pname;
        private Label Label_ProductName;
        private Label Label_Qty;
        private NumericUpDown Numeric_Qty;
        private Label Label_Price;
        private ComboBox ComboBox_Ptype;
        private Label label1;
        private Button Button_Add;
        private TextBox TextBox_Price;
        private Button Button_Cancel;
    }
}