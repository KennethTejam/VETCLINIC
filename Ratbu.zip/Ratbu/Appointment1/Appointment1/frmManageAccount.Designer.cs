﻿namespace Appointment1
{
    partial class frmManageAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmManageAccount));
            Button_PassConfirm = new Button();
            Button_PinConfirm = new Button();
            Button_EmailConfirm = new Button();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            pictureBox3 = new PictureBox();
            label4 = new Label();
            label1 = new Label();
            Label_MemberSince = new Label();
            Label_Homepage = new Label();
            Label_ManageAccount = new Label();
            Label_History = new Label();
            TextBox_ChangeEmail = new TextBox();
            TextBox_ChangePassword = new TextBox();
            label2 = new Label();
            TextBox_ChangePin = new TextBox();
            Picture_Icon = new PictureBox();
            pictureBox5 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Picture_Icon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // Button_PassConfirm
            // 
            Button_PassConfirm.Enabled = false;
            Button_PassConfirm.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Button_PassConfirm.Location = new Point(694, 537);
            Button_PassConfirm.Name = "Button_PassConfirm";
            Button_PassConfirm.Size = new Size(133, 38);
            Button_PassConfirm.TabIndex = 89;
            Button_PassConfirm.Text = "Confirm";
            Button_PassConfirm.UseVisualStyleBackColor = true;
            Button_PassConfirm.Visible = false;
            Button_PassConfirm.Click += Button_PassConfirm_Click;
            // 
            // Button_PinConfirm
            // 
            Button_PinConfirm.Enabled = false;
            Button_PinConfirm.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Button_PinConfirm.Location = new Point(694, 424);
            Button_PinConfirm.Name = "Button_PinConfirm";
            Button_PinConfirm.Size = new Size(133, 38);
            Button_PinConfirm.TabIndex = 88;
            Button_PinConfirm.Text = "Confirm";
            Button_PinConfirm.UseVisualStyleBackColor = true;
            Button_PinConfirm.Visible = false;
            Button_PinConfirm.Click += Button_PinConfirm_Click;
            // 
            // Button_EmailConfirm
            // 
            Button_EmailConfirm.Enabled = false;
            Button_EmailConfirm.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Button_EmailConfirm.Location = new Point(694, 303);
            Button_EmailConfirm.Name = "Button_EmailConfirm";
            Button_EmailConfirm.Size = new Size(133, 38);
            Button_EmailConfirm.TabIndex = 87;
            Button_EmailConfirm.Text = "Confirm";
            Button_EmailConfirm.UseVisualStyleBackColor = true;
            Button_EmailConfirm.Visible = false;
            Button_EmailConfirm.Click += Button_EmailConfirm_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.Transparent;
            pictureBox2.Cursor = Cursors.Hand;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(797, 255);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(30, 30);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 83;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(797, 374);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 30);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 82;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.Transparent;
            pictureBox3.Cursor = Cursors.Hand;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(797, 491);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(30, 30);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 81;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Sitka Small", 12F, FontStyle.Bold);
            label4.Location = new Point(402, 457);
            label4.Name = "label4";
            label4.Size = new Size(123, 23);
            label4.TabIndex = 80;
            label4.Text = "PASSWORD : ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Sitka Small", 12F, FontStyle.Bold);
            label1.Location = new Point(402, 220);
            label1.Name = "label1";
            label1.Size = new Size(85, 23);
            label1.TabIndex = 79;
            label1.Text = "EMAIL : ";
            // 
            // Label_MemberSince
            // 
            Label_MemberSince.Font = new Font("Sitka Small", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label_MemberSince.Location = new Point(49, 492);
            Label_MemberSince.Name = "Label_MemberSince";
            Label_MemberSince.Size = new Size(268, 109);
            Label_MemberSince.TabIndex = 72;
            Label_MemberSince.Text = "Member Since: ";
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = Color.Transparent;
            Label_Homepage.Cursor = Cursors.Hand;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = SystemColors.ControlText;
            Label_Homepage.Location = new Point(12, 61);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Padding = new Padding(10, 3, 10, 3);
            Label_Homepage.Size = new Size(130, 31);
            Label_Homepage.TabIndex = 78;
            Label_Homepage.Text = "Homepage";
            Label_Homepage.Click += Label_Homepage_Click;
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.BackColor = Color.Transparent;
            Label_ManageAccount.Cursor = Cursors.Hand;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.Location = new Point(488, 61);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Padding = new Padding(10, 3, 10, 3);
            Label_ManageAccount.Size = new Size(183, 31);
            Label_ManageAccount.TabIndex = 77;
            Label_ManageAccount.Text = "Manage Account";
            // 
            // Label_History
            // 
            Label_History.AutoSize = true;
            Label_History.BackColor = Color.Transparent;
            Label_History.Cursor = Cursors.Hand;
            Label_History.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_History.ForeColor = SystemColors.ControlText;
            Label_History.Location = new Point(225, 61);
            Label_History.Name = "Label_History";
            Label_History.Padding = new Padding(10, 3, 10, 3);
            Label_History.Size = new Size(171, 31);
            Label_History.TabIndex = 75;
            Label_History.Text = "Patient Records";
            Label_History.Click += Label_Appointment_Click;
            // 
            // TextBox_ChangeEmail
            // 
            TextBox_ChangeEmail.BackColor = SystemColors.Window;
            TextBox_ChangeEmail.Enabled = false;
            TextBox_ChangeEmail.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            TextBox_ChangeEmail.ForeColor = SystemColors.WindowText;
            TextBox_ChangeEmail.Location = new Point(402, 246);
            TextBox_ChangeEmail.Name = "TextBox_ChangeEmail";
            TextBox_ChangeEmail.Size = new Size(361, 39);
            TextBox_ChangeEmail.TabIndex = 71;
            TextBox_ChangeEmail.TextChanged += TextBox_ChangeEmail_TextChanged;
            // 
            // TextBox_ChangePassword
            // 
            TextBox_ChangePassword.BackColor = SystemColors.Window;
            TextBox_ChangePassword.Enabled = false;
            TextBox_ChangePassword.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            TextBox_ChangePassword.ForeColor = SystemColors.WindowText;
            TextBox_ChangePassword.Location = new Point(402, 482);
            TextBox_ChangePassword.Name = "TextBox_ChangePassword";
            TextBox_ChangePassword.Size = new Size(361, 39);
            TextBox_ChangePassword.TabIndex = 69;
            TextBox_ChangePassword.UseSystemPasswordChar = true;
            TextBox_ChangePassword.TextChanged += TextBox_ChangePassword_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Sitka Small", 12F, FontStyle.Bold);
            label2.Location = new Point(402, 336);
            label2.Name = "label2";
            label2.Size = new Size(58, 23);
            label2.TabIndex = 70;
            label2.Text = "PIN : ";
            // 
            // TextBox_ChangePin
            // 
            TextBox_ChangePin.BackColor = SystemColors.Window;
            TextBox_ChangePin.Enabled = false;
            TextBox_ChangePin.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            TextBox_ChangePin.ForeColor = SystemColors.WindowText;
            TextBox_ChangePin.Location = new Point(402, 365);
            TextBox_ChangePin.Name = "TextBox_ChangePin";
            TextBox_ChangePin.Size = new Size(361, 39);
            TextBox_ChangePin.TabIndex = 68;
            TextBox_ChangePin.TextChanged += TextBox_ChangePin_TextChanged;
            // 
            // Picture_Icon
            // 
            Picture_Icon.ErrorImage = null;
            Picture_Icon.ImageLocation = "Pig.png";
            Picture_Icon.InitialImage = null;
            Picture_Icon.Location = new Point(82, 230);
            Picture_Icon.Margin = new Padding(0);
            Picture_Icon.Name = "Picture_Icon";
            Picture_Icon.Padding = new Padding(25);
            Picture_Icon.Size = new Size(196, 186);
            Picture_Icon.SizeMode = PictureBoxSizeMode.StretchImage;
            Picture_Icon.TabIndex = 125;
            Picture_Icon.TabStop = false;
            Picture_Icon.Click += Picture_Icon_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.Transparent;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(830, 12);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(222, 80);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 129;
            pictureBox5.TabStop = false;
            // 
            // frmManageAccount
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 681);
            Controls.Add(pictureBox5);
            Controls.Add(Picture_Icon);
            Controls.Add(Button_PassConfirm);
            Controls.Add(Button_PinConfirm);
            Controls.Add(Button_EmailConfirm);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox3);
            Controls.Add(label4);
            Controls.Add(label1);
            Controls.Add(Label_MemberSince);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_History);
            Controls.Add(TextBox_ChangeEmail);
            Controls.Add(TextBox_ChangePassword);
            Controls.Add(label2);
            Controls.Add(TextBox_ChangePin);
            Name = "frmManageAccount";
            Text = "ManageAccount";
            Load += frmManageAccount_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)Picture_Icon).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button Button_PassConfirm;
        private Button Button_PinConfirm;
        private Button Button_EmailConfirm;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
        private Label label4;
        private Label label1;
        private Label Label_MemberSince;
        private Label Label_Homepage;
        private Label Label_ManageAccount;
        private Label Label_History;
        private TextBox TextBox_ChangeEmail;
        private TextBox TextBox_ChangePassword;
        private Label label2;
        private TextBox TextBox_ChangePin;
        private PictureBox Picture_Icon;
        private PictureBox pictureBox5;
    }
}