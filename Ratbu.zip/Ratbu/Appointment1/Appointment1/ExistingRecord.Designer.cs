﻿namespace Appointment1
{
    partial class ExistingRecord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExistingRecord));
            txtBreed = new TextBox();
            btnBook = new Button();
            lblBreed = new Label();
            label3 = new Label();
            lblAge = new Label();
            lblpet = new Label();
            Label_Homepage = new Label();
            Label_ManageAccount = new Label();
            Label_Appointment = new Label();
            Label_History = new Label();
            txtSearch = new TextBox();
            cboPet = new ComboBox();
            txtAge = new TextBox();
            txtGender = new TextBox();
            txtContactNo = new TextBox();
            txtEmail = new TextBox();
            Label_Shop = new Label();
            pictureBox5 = new PictureBox();
            lblGender = new Label();
            lblContactNo = new Label();
            lblEmail = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // txtBreed
            // 
            txtBreed.BackColor = SystemColors.Window;
            txtBreed.Font = new Font("Microsoft Sans Serif", 14.25F);
            txtBreed.Location = new Point(269, 282);
            txtBreed.Margin = new Padding(3, 0, 3, 3);
            txtBreed.Multiline = true;
            txtBreed.Name = "txtBreed";
            txtBreed.ReadOnly = true;
            txtBreed.Size = new Size(259, 31);
            txtBreed.TabIndex = 68;
            // 
            // btnBook
            // 
            btnBook.Enabled = false;
            btnBook.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBook.Location = new Point(765, 524);
            btnBook.Name = "btnBook";
            btnBook.Size = new Size(189, 75);
            btnBook.TabIndex = 70;
            btnBook.Text = "Book Appointment";
            btnBook.UseVisualStyleBackColor = true;
            btnBook.Click += btnBook_Click;
            // 
            // lblBreed
            // 
            lblBreed.AutoSize = true;
            lblBreed.BackColor = Color.Transparent;
            lblBreed.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            lblBreed.Location = new Point(42, 280);
            lblBreed.Name = "lblBreed";
            lblBreed.Size = new Size(83, 30);
            lblBreed.TabIndex = 73;
            lblBreed.Text = "BREED:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold);
            label3.Location = new Point(167, 325);
            label3.Name = "label3";
            label3.Size = new Size(0, 40);
            label3.TabIndex = 75;
            // 
            // lblAge
            // 
            lblAge.AutoSize = true;
            lblAge.BackColor = Color.Transparent;
            lblAge.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            lblAge.Location = new Point(42, 318);
            lblAge.Name = "lblAge";
            lblAge.Size = new Size(60, 30);
            lblAge.TabIndex = 76;
            lblAge.Text = "AGE:";
            // 
            // lblpet
            // 
            lblpet.AutoSize = true;
            lblpet.BackColor = Color.Transparent;
            lblpet.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            lblpet.Location = new Point(42, 234);
            lblpet.Name = "lblpet";
            lblpet.Size = new Size(124, 30);
            lblpet.TabIndex = 77;
            lblpet.Text = "PET NAME:";
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = Color.Transparent;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = SystemColors.ControlText;
            Label_Homepage.Location = new Point(10, 61);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Padding = new Padding(10, 3, 10, 3);
            Label_Homepage.Size = new Size(130, 31);
            Label_Homepage.TabIndex = 66;
            Label_Homepage.Text = "Homepage";
            Label_Homepage.Click += Label_Homepage_Click;
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.BackColor = Color.Transparent;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.Location = new Point(626, 61);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Padding = new Padding(10, 3, 10, 3);
            Label_ManageAccount.Size = new Size(183, 31);
            Label_ManageAccount.TabIndex = 65;
            Label_ManageAccount.Text = "Manage Account";
            // 
            // Label_Appointment
            // 
            Label_Appointment.AutoSize = true;
            Label_Appointment.BackColor = Color.Transparent;
            Label_Appointment.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Appointment.Location = new Point(165, 61);
            Label_Appointment.Name = "Label_Appointment";
            Label_Appointment.Padding = new Padding(10, 3, 10, 3);
            Label_Appointment.Size = new Size(137, 31);
            Label_Appointment.TabIndex = 64;
            Label_Appointment.Text = "Add Record";
            // 
            // Label_History
            // 
            Label_History.AutoSize = true;
            Label_History.BackColor = Color.Transparent;
            Label_History.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_History.ForeColor = SystemColors.ControlText;
            Label_History.Location = new Point(327, 61);
            Label_History.Name = "Label_History";
            Label_History.Padding = new Padding(10, 3, 10, 3);
            Label_History.Size = new Size(174, 31);
            Label_History.TabIndex = 63;
            Label_History.Text = "History Records";
            Label_History.Click += Label_History_Click;
            // 
            // txtSearch
            // 
            txtSearch.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtSearch.Location = new Point(778, 167);
            txtSearch.Margin = new Padding(3, 2, 3, 2);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(167, 33);
            txtSearch.TabIndex = 84;
            // 
            // cboPet
            // 
            cboPet.DropDownStyle = ComboBoxStyle.DropDownList;
            cboPet.Font = new Font("Microsoft Sans Serif", 14.25F);
            cboPet.FormattingEnabled = true;
            cboPet.Location = new Point(269, 238);
            cboPet.Margin = new Padding(3, 2, 3, 2);
            cboPet.Name = "cboPet";
            cboPet.Size = new Size(255, 32);
            cboPet.TabIndex = 85;
            // 
            // txtAge
            // 
            txtAge.BackColor = SystemColors.Window;
            txtAge.Font = new Font("Microsoft Sans Serif", 14.25F);
            txtAge.Location = new Point(269, 318);
            txtAge.Margin = new Padding(3, 0, 3, 3);
            txtAge.Multiline = true;
            txtAge.Name = "txtAge";
            txtAge.ReadOnly = true;
            txtAge.Size = new Size(259, 31);
            txtAge.TabIndex = 86;
            // 
            // txtGender
            // 
            txtGender.BackColor = SystemColors.Window;
            txtGender.Font = new Font("Microsoft Sans Serif", 14.25F);
            txtGender.Location = new Point(269, 355);
            txtGender.Margin = new Padding(3, 0, 3, 3);
            txtGender.Multiline = true;
            txtGender.Name = "txtGender";
            txtGender.ReadOnly = true;
            txtGender.Size = new Size(259, 31);
            txtGender.TabIndex = 87;
            // 
            // txtContactNo
            // 
            txtContactNo.BackColor = SystemColors.Window;
            txtContactNo.Font = new Font("Microsoft Sans Serif", 14.25F);
            txtContactNo.Location = new Point(269, 396);
            txtContactNo.Margin = new Padding(3, 0, 3, 3);
            txtContactNo.Multiline = true;
            txtContactNo.Name = "txtContactNo";
            txtContactNo.ReadOnly = true;
            txtContactNo.Size = new Size(259, 31);
            txtContactNo.TabIndex = 88;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = SystemColors.Window;
            txtEmail.Font = new Font("Microsoft Sans Serif", 14.25F);
            txtEmail.Location = new Point(269, 436);
            txtEmail.Margin = new Padding(3, 0, 3, 3);
            txtEmail.Multiline = true;
            txtEmail.Name = "txtEmail";
            txtEmail.ReadOnly = true;
            txtEmail.Size = new Size(259, 31);
            txtEmail.TabIndex = 89;
            // 
            // Label_Shop
            // 
            Label_Shop.AutoSize = true;
            Label_Shop.BackColor = Color.Transparent;
            Label_Shop.Cursor = Cursors.Hand;
            Label_Shop.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Shop.ForeColor = Color.Black;
            Label_Shop.ImageAlign = ContentAlignment.MiddleRight;
            Label_Shop.Location = new Point(523, 61);
            Label_Shop.Name = "Label_Shop";
            Label_Shop.Padding = new Padding(10, 3, 10, 3);
            Label_Shop.Size = new Size(78, 31);
            Label_Shop.TabIndex = 123;
            Label_Shop.Text = "Shop";
            Label_Shop.Click += Label_Shop_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.Transparent;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(830, 12);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(222, 80);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 125;
            pictureBox5.TabStop = false;
            // 
            // lblGender
            // 
            lblGender.AutoSize = true;
            lblGender.BackColor = Color.Transparent;
            lblGender.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            lblGender.Location = new Point(42, 355);
            lblGender.Name = "lblGender";
            lblGender.Size = new Size(102, 30);
            lblGender.TabIndex = 126;
            lblGender.Text = "GENDER:";
            // 
            // lblContactNo
            // 
            lblContactNo.AutoSize = true;
            lblContactNo.BackColor = Color.Transparent;
            lblContactNo.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            lblContactNo.Location = new Point(42, 396);
            lblContactNo.Name = "lblContactNo";
            lblContactNo.Size = new Size(212, 30);
            lblContactNo.TabIndex = 127;
            lblContactNo.Text = "CONTACT NUMBER:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.BackColor = Color.Transparent;
            lblEmail.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            lblEmail.Location = new Point(42, 436);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(83, 30);
            lblEmail.TabIndex = 128;
            lblEmail.Text = "EMAIL:";
            // 
            // ExistingRecord
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 681);
            Controls.Add(lblEmail);
            Controls.Add(lblContactNo);
            Controls.Add(lblGender);
            Controls.Add(pictureBox5);
            Controls.Add(Label_Shop);
            Controls.Add(txtEmail);
            Controls.Add(txtContactNo);
            Controls.Add(txtGender);
            Controls.Add(txtAge);
            Controls.Add(cboPet);
            Controls.Add(txtSearch);
            Controls.Add(txtBreed);
            Controls.Add(btnBook);
            Controls.Add(lblBreed);
            Controls.Add(label3);
            Controls.Add(lblAge);
            Controls.Add(lblpet);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_Appointment);
            Controls.Add(Label_History);
            Margin = new Padding(3, 2, 3, 2);
            Name = "ExistingRecord";
            Text = "Form3";
            Load += ExistingRecord_Load_1;
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnDelete;
        private Button btnAdd;
        private Panel medpanel;
        private DateTimePicker dateTimePicker1;
        private RadioButton RadioButton_Female;
        private RadioButton RadioButton_Male;
        private TextBox txtBreed;
        private Button btnBook;
        private Label lblBreed;
        private Label label3;
        private Label lblAge;
        private Label lblpet;
        private Label Label_Homepage;
        private Label Label_ManageAccount;
        private Label Label_Appointment;
        private Label Label_History;
        private TextBox txtSearch;
        private ComboBox cboPet;
        private TextBox txtAge;
        private TextBox txtGender;
        private TextBox txtContactNo;
        private TextBox txtEmail;
        private Label Label_Shop;
        private PictureBox pictureBox5;
        private Label lblGender;
        private Label lblContactNo;
        private Label lblEmail;
    }
}