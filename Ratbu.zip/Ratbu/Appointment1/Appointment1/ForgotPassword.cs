﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;
using System.CodeDom;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using Microsoft.VisualBasic.ApplicationServices;
using System.Drawing.Text;

namespace Appointment1
{
    public partial class ForgotPassword : Form
    {

        public int userid;
        SqlConnection conn;
        PROCESSES process = new PROCESSES();
        public ForgotPassword()
        {
            InitializeComponent();
            this.userid = userid;
            if (userid > 0)
            {
                Homepage homepage = new Homepage(userid);
                homepage.Show();
                this.Hide();
            }
            PROCESSES processes = new PROCESSES();
            conn = processes.getConnection();
            this.BackColor = Color.FromArgb(240, 226, 212);
            Button_ProceedWithAccount.BackColor = Color.FromArgb(200, 233, 200, 168);
            Button_ConfirmWithAccount.BackColor = Color.FromArgb(200, 233, 200, 168);

        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////

        private void LinkLabel_Signup_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Signup signup = new Signup();
            signup.Show();
            this.Hide();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void LinkLabel_GotoLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            Login login = new Login(userid);
            login.Show();
            this.Hide();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void ForgotPassword_Load(object sender, EventArgs e)
        {

        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void Button_ProceedWithAccount_Click(object sender, EventArgs e)
        {
            string newpass, confirmpass, email, pin;
            email = TextBox_Email.Text;
            pin = TextBox_PinNoAccount.Text;
            newpass = TextBox_Password.Text;
            confirmpass = TextBox_ConfirmPass.Text;
            if (email == "" || pin == "")
            {
                MessageBox.Show("Input Required Credentials first!!");
                return;
            }
            bool checkaccount = process.ForgotPassword_CheckAccount(email, pin);
            if (checkaccount == true)
            {
                TextBox_Email.Enabled = false;
                TextBox_PinNoAccount.Enabled = false;
                TextBox_Password.Enabled = true;
                TextBox_ConfirmPass.Enabled = true;
                pictureBox1.Visible = true;
                pictureBox2.Visible = true;
                Button_ConfirmWithAccount.Visible = true;
                Button_ProceedWithAccount.Visible = false;
                MessageBox.Show("Enter New Password!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void Button_ConfirmWithAccount_Click(object sender, EventArgs e)
        {
            string pass, conpass, email;
            int pin;
            email = TextBox_Email.Text;
            pin = Convert.ToInt32(TextBox_PinNoAccount.Text);
            pass = TextBox_Password.Text;
            conpass = TextBox_ConfirmPass.Text;
            if (pass != conpass)
            {
                MessageBox.Show("Passwords are not same!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (pass == "" || conpass == "")
            {
                MessageBox.Show("Please Input new Password!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                bool setpasschecker = process.ForgotPassword_SetPassword(email, pin, pass);
                if (setpasschecker == true)
                {
                    int userid = -1;
                    Login login = new Login(userid);
                    login.Show();
                    this.Hide();
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (pictureBox2.ImageLocation == @"hide.png")
            {
                pictureBox2.ImageLocation = @"view.png";
                TextBox_Password.UseSystemPasswordChar = true;
            }
            else
            {
                pictureBox2.ImageLocation = @"hide.png";
                TextBox_Password.UseSystemPasswordChar = false;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (pictureBox1.ImageLocation == @"hide.png")
            {
                pictureBox1.ImageLocation = @"view.png";
                TextBox_ConfirmPass.UseSystemPasswordChar = true;
            }
            else
            {
                pictureBox1.ImageLocation = @"hide.png";
                TextBox_ConfirmPass.UseSystemPasswordChar = false;
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (pictureBox3.ImageLocation == @"hide.png")
            {
                pictureBox3.ImageLocation = @"view.png";
                TextBox_PinNoAccount.UseSystemPasswordChar = true;
            }
            else
            {
                pictureBox3.ImageLocation = @"hide.png";
                TextBox_PinNoAccount.UseSystemPasswordChar = false;
            }
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Rectangle rectangle = new Rectangle(120, 50, 630, 550); // X, Y, Width, Height

            // Create a semi-transparent brush
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(200, 233, 200, 168))) // 128 = 50% opacity, Green color
            {
                // Draw the rectangle in the specified position
                e.Graphics.FillRectangle(brush, rectangle);
            }
            using (Pen pen = new Pen(Color.Black, 2)) // Black border with 3px thickness
            {
                e.Graphics.DrawRectangle(pen, rectangle);
            }
        }
    }
}
