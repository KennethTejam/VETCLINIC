﻿namespace Appointment1
{
    partial class Signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Signup));
            TextBox_ConfirmPass = new TextBox();
            TextBox_Password = new TextBox();
            TextBox_Email = new TextBox();
            TextBox_Lname = new TextBox();
            TextBox_Mname = new TextBox();
            TextBox_Fname = new TextBox();
            Button_Signin = new Button();
            Label_Password = new Label();
            Label_Mname = new Label();
            Label_ConfirmPass = new Label();
            Label_Email = new Label();
            Label_Lname = new Label();
            Label_Fname = new Label();
            linkLabel_Signup = new LinkLabel();
            TextBox_Pin = new TextBox();
            Label_ForgotPass = new Label();
            Label_Gender = new Label();
            RadioButton_Male = new RadioButton();
            RadioButton_Female = new RadioButton();
            PictureBox_PasswordViewer = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            Label_SignUP = new Label();
            ((System.ComponentModel.ISupportInitialize)PictureBox_PasswordViewer).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // TextBox_ConfirmPass
            // 
            TextBox_ConfirmPass.BackColor = SystemColors.Window;
            TextBox_ConfirmPass.Font = new Font("Poppins", 15.75F);
            TextBox_ConfirmPass.Location = new Point(504, 403);
            TextBox_ConfirmPass.Name = "TextBox_ConfirmPass";
            TextBox_ConfirmPass.Size = new Size(280, 39);
            TextBox_ConfirmPass.TabIndex = 11;
            TextBox_ConfirmPass.UseSystemPasswordChar = true;
            TextBox_ConfirmPass.WordWrap = false;
            TextBox_ConfirmPass.TextChanged += TextBox_ConfirmPass_TextChanged;
            // 
            // TextBox_Password
            // 
            TextBox_Password.BackColor = SystemColors.Window;
            TextBox_Password.Font = new Font("Poppins", 15.75F);
            TextBox_Password.Location = new Point(504, 358);
            TextBox_Password.Name = "TextBox_Password";
            TextBox_Password.Size = new Size(280, 39);
            TextBox_Password.TabIndex = 10;
            TextBox_Password.UseSystemPasswordChar = true;
            TextBox_Password.WordWrap = false;
            TextBox_Password.TextChanged += TextBox_Password_TextChanged;
            // 
            // TextBox_Email
            // 
            TextBox_Email.BackColor = SystemColors.Window;
            TextBox_Email.Font = new Font("Poppins", 15.75F);
            TextBox_Email.Location = new Point(504, 277);
            TextBox_Email.Name = "TextBox_Email";
            TextBox_Email.Size = new Size(280, 39);
            TextBox_Email.TabIndex = 4;
            TextBox_Email.TextChanged += TextBox_Email_TextChanged;
            // 
            // TextBox_Lname
            // 
            TextBox_Lname.BackColor = SystemColors.Window;
            TextBox_Lname.Font = new Font("Poppins", 15.75F);
            TextBox_Lname.Location = new Point(504, 232);
            TextBox_Lname.Name = "TextBox_Lname";
            TextBox_Lname.Size = new Size(280, 39);
            TextBox_Lname.TabIndex = 3;
            TextBox_Lname.TextChanged += TextBox_Lname_TextChanged;
            // 
            // TextBox_Mname
            // 
            TextBox_Mname.BackColor = SystemColors.Window;
            TextBox_Mname.Font = new Font("Poppins", 15.75F);
            TextBox_Mname.Location = new Point(504, 187);
            TextBox_Mname.Name = "TextBox_Mname";
            TextBox_Mname.Size = new Size(280, 39);
            TextBox_Mname.TabIndex = 2;
            TextBox_Mname.TextChanged += TextBox_Mname_TextChanged;
            // 
            // TextBox_Fname
            // 
            TextBox_Fname.BackColor = SystemColors.Window;
            TextBox_Fname.Font = new Font("Poppins", 15.75F);
            TextBox_Fname.Location = new Point(504, 142);
            TextBox_Fname.Name = "TextBox_Fname";
            TextBox_Fname.Size = new Size(280, 39);
            TextBox_Fname.TabIndex = 1;
            TextBox_Fname.TextChanged += TextBox_Fname_TextChanged;
            // 
            // Button_Signin
            // 
            Button_Signin.BackColor = Color.Transparent;
            Button_Signin.Enabled = false;
            Button_Signin.FlatAppearance.BorderColor = Color.Black;
            Button_Signin.FlatStyle = FlatStyle.Flat;
            Button_Signin.Font = new Font("Poppins ExtraBold", 18F, FontStyle.Bold);
            Button_Signin.Location = new Point(632, 518);
            Button_Signin.Name = "Button_Signin";
            Button_Signin.Size = new Size(152, 47);
            Button_Signin.TabIndex = 14;
            Button_Signin.Text = "SIGN ME UP!";
            Button_Signin.UseVisualStyleBackColor = false;
            Button_Signin.Click += Button_Signin_Click;
            // 
            // Label_Password
            // 
            Label_Password.AutoSize = true;
            Label_Password.BackColor = Color.Transparent;
            Label_Password.Font = new Font("Poppins", 14.25F);
            Label_Password.Location = new Point(291, 357);
            Label_Password.Name = "Label_Password";
            Label_Password.Size = new Size(116, 34);
            Label_Password.TabIndex = 16;
            Label_Password.Text = "Password :";
            // 
            // Label_Mname
            // 
            Label_Mname.AutoSize = true;
            Label_Mname.BackColor = Color.Transparent;
            Label_Mname.Font = new Font("Poppins", 14.25F);
            Label_Mname.Location = new Point(291, 192);
            Label_Mname.Name = "Label_Mname";
            Label_Mname.Size = new Size(150, 34);
            Label_Mname.TabIndex = 19;
            Label_Mname.Text = "Middle name :";
            // 
            // Label_ConfirmPass
            // 
            Label_ConfirmPass.AutoSize = true;
            Label_ConfirmPass.BackColor = Color.Transparent;
            Label_ConfirmPass.Font = new Font("Poppins", 14.25F);
            Label_ConfirmPass.Location = new Point(292, 400);
            Label_ConfirmPass.Name = "Label_ConfirmPass";
            Label_ConfirmPass.Size = new Size(200, 34);
            Label_ConfirmPass.TabIndex = 20;
            Label_ConfirmPass.Text = "Confirm password :";
            // 
            // Label_Email
            // 
            Label_Email.AutoSize = true;
            Label_Email.BackColor = Color.Transparent;
            Label_Email.Font = new Font("Poppins", 14.25F);
            Label_Email.Location = new Point(293, 282);
            Label_Email.Name = "Label_Email";
            Label_Email.Size = new Size(77, 34);
            Label_Email.TabIndex = 22;
            Label_Email.Text = "Email :";
            // 
            // Label_Lname
            // 
            Label_Lname.AutoSize = true;
            Label_Lname.BackColor = Color.Transparent;
            Label_Lname.Font = new Font("Poppins", 14.25F);
            Label_Lname.Location = new Point(291, 237);
            Label_Lname.Name = "Label_Lname";
            Label_Lname.Size = new Size(124, 34);
            Label_Lname.TabIndex = 23;
            Label_Lname.Text = "Last name :";
            // 
            // Label_Fname
            // 
            Label_Fname.AutoSize = true;
            Label_Fname.BackColor = Color.Transparent;
            Label_Fname.Font = new Font("Poppins", 14.25F);
            Label_Fname.Location = new Point(293, 147);
            Label_Fname.Name = "Label_Fname";
            Label_Fname.Size = new Size(125, 34);
            Label_Fname.TabIndex = 24;
            Label_Fname.Text = "First name :";
            // 
            // linkLabel_Signup
            // 
            linkLabel_Signup.AutoSize = true;
            linkLabel_Signup.BackColor = Color.Transparent;
            linkLabel_Signup.Font = new Font("Poppins SemiBold", 9.75F, FontStyle.Bold);
            linkLabel_Signup.Location = new Point(293, 518);
            linkLabel_Signup.Name = "linkLabel_Signup";
            linkLabel_Signup.Size = new Size(270, 23);
            linkLabel_Signup.TabIndex = 13;
            linkLabel_Signup.TabStop = true;
            linkLabel_Signup.Text = "Already have an account? Log In here...";
            linkLabel_Signup.LinkClicked += linkLabel_Signup_LinkClicked;
            // 
            // TextBox_Pin
            // 
            TextBox_Pin.BackColor = SystemColors.Window;
            TextBox_Pin.Font = new Font("Poppins", 15.75F);
            TextBox_Pin.Location = new Point(504, 448);
            TextBox_Pin.Name = "TextBox_Pin";
            TextBox_Pin.Size = new Size(280, 39);
            TextBox_Pin.TabIndex = 12;
            TextBox_Pin.UseSystemPasswordChar = true;
            TextBox_Pin.WordWrap = false;
            TextBox_Pin.TextChanged += TextBox_Pin_TextChanged;
            // 
            // Label_ForgotPass
            // 
            Label_ForgotPass.AutoSize = true;
            Label_ForgotPass.BackColor = Color.Transparent;
            Label_ForgotPass.Font = new Font("Poppins", 14.25F);
            Label_ForgotPass.Location = new Point(293, 444);
            Label_ForgotPass.Name = "Label_ForgotPass";
            Label_ForgotPass.Size = new Size(52, 34);
            Label_ForgotPass.TabIndex = 13;
            Label_ForgotPass.Text = "Pin :";
            // 
            // Label_Gender
            // 
            Label_Gender.AutoSize = true;
            Label_Gender.BackColor = Color.Transparent;
            Label_Gender.Font = new Font("Poppins", 14.25F);
            Label_Gender.Location = new Point(292, 324);
            Label_Gender.Name = "Label_Gender";
            Label_Gender.Size = new Size(65, 34);
            Label_Gender.TabIndex = 17;
            Label_Gender.Text = "Role :";
            // 
            // RadioButton_Male
            // 
            RadioButton_Male.AutoSize = true;
            RadioButton_Male.BackColor = Color.Transparent;
            RadioButton_Male.Font = new Font("Poppins", 14.25F);
            RadioButton_Male.Location = new Point(521, 322);
            RadioButton_Male.Name = "RadioButton_Male";
            RadioButton_Male.Size = new Size(151, 38);
            RadioButton_Male.TabIndex = 6;
            RadioButton_Male.TabStop = true;
            RadioButton_Male.Text = "Veterinarian";
            RadioButton_Male.UseVisualStyleBackColor = false;
            RadioButton_Male.CheckedChanged += RadioButton_Male_CheckedChanged;
            // 
            // RadioButton_Female
            // 
            RadioButton_Female.AutoSize = true;
            RadioButton_Female.BackColor = Color.Transparent;
            RadioButton_Female.Font = new Font("Poppins", 14.25F);
            RadioButton_Female.Location = new Point(678, 322);
            RadioButton_Female.Name = "RadioButton_Female";
            RadioButton_Female.Size = new Size(76, 38);
            RadioButton_Female.TabIndex = 7;
            RadioButton_Female.TabStop = true;
            RadioButton_Female.Text = "Staff";
            RadioButton_Female.UseVisualStyleBackColor = false;
            RadioButton_Female.CheckedChanged += RadioButton_Female_CheckedChanged;
            // 
            // PictureBox_PasswordViewer
            // 
            PictureBox_PasswordViewer.BackColor = SystemColors.ButtonHighlight;
            PictureBox_PasswordViewer.Image = (Image)resources.GetObject("PictureBox_PasswordViewer.Image");
            PictureBox_PasswordViewer.Location = new Point(744, 454);
            PictureBox_PasswordViewer.Name = "PictureBox_PasswordViewer";
            PictureBox_PasswordViewer.Size = new Size(38, 22);
            PictureBox_PasswordViewer.SizeMode = PictureBoxSizeMode.Zoom;
            PictureBox_PasswordViewer.TabIndex = 25;
            PictureBox_PasswordViewer.TabStop = false;
            PictureBox_PasswordViewer.Click += PictureBox_PasswordViewer_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = SystemColors.ButtonHighlight;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(742, 366);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(38, 22);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 27;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ButtonHighlight;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(743, 411);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(38, 22);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 26;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // Label_SignUP
            // 
            Label_SignUP.AutoSize = true;
            Label_SignUP.BackColor = Color.Transparent;
            Label_SignUP.Font = new Font("Poppins Black", 24F, FontStyle.Bold);
            Label_SignUP.Location = new Point(450, 83);
            Label_SignUP.Name = "Label_SignUP";
            Label_SignUP.Size = new Size(152, 56);
            Label_SignUP.TabIndex = 29;
            Label_SignUP.Text = "SIGN UP";
            Label_SignUP.Click += Label_SignUP_Click;
            // 
            // Signup
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1064, 681);
            Controls.Add(Label_SignUP);
            Controls.Add(PictureBox_PasswordViewer);
            Controls.Add(TextBox_Pin);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(Label_ForgotPass);
            Controls.Add(linkLabel_Signup);
            Controls.Add(TextBox_ConfirmPass);
            Controls.Add(TextBox_Password);
            Controls.Add(TextBox_Email);
            Controls.Add(TextBox_Lname);
            Controls.Add(TextBox_Mname);
            Controls.Add(TextBox_Fname);
            Controls.Add(Button_Signin);
            Controls.Add(Label_Password);
            Controls.Add(Label_Gender);
            Controls.Add(Label_Mname);
            Controls.Add(Label_ConfirmPass);
            Controls.Add(Label_Email);
            Controls.Add(Label_Lname);
            Controls.Add(Label_Fname);
            Controls.Add(RadioButton_Female);
            Controls.Add(RadioButton_Male);
            DoubleBuffered = true;
            Name = "Signup";
            Text = "Form1";
            WindowState = FormWindowState.Minimized;
            Load += Signup_Load;
            ((System.ComponentModel.ISupportInitialize)PictureBox_PasswordViewer).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox TextBox_ConfirmPass;
        private TextBox TextBox_Password;
        private TextBox TextBox_Email;
        private TextBox TextBox_Lname;
        private TextBox TextBox_Mname;
        private TextBox TextBox_Fname;
        private Button Button_Signin;
        private Label Label_Password;
        private Label Label_Mname;
        private Label Label_ConfirmPass;
        private Label Label_Email;
        private Label Label_Lname;
        private Label Label_Fname;
        private LinkLabel linkLabel_Signup;
        private TextBox TextBox_Pin;
        private Label Label_ForgotPass;
        private Label Label_Gender;
        private RadioButton RadioButton_Male;
        private RadioButton RadioButton_Female;
        private PictureBox PictureBox_PasswordViewer;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
        private Label Label_SignUP;
    }
}