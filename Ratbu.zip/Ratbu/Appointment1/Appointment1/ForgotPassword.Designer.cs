﻿namespace Appointment1
{
    partial class ForgotPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ForgotPassword));
            LinkLabel_GotoLogin = new LinkLabel();
            LinkLabel_Signup = new LinkLabel();
            TextBox_PinNoAccount = new TextBox();
            TextBox_Email = new TextBox();
            Label_Email = new Label();
            Label_Pin = new Label();
            Label_Welcome = new Label();
            TextBox_Password = new TextBox();
            Label_Password = new Label();
            TextBox_ConfirmPass = new TextBox();
            Label_ConfirmPass = new Label();
            Button_ConfirmWithAccount = new Button();
            Button_ProceedWithAccount = new Button();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            pictureBox3 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // LinkLabel_GotoLogin
            // 
            LinkLabel_GotoLogin.BackColor = Color.Transparent;
            LinkLabel_GotoLogin.Font = new Font("Poppins SemiBold", 9.75F, FontStyle.Bold);
            LinkLabel_GotoLogin.Location = new Point(162, 491);
            LinkLabel_GotoLogin.Name = "LinkLabel_GotoLogin";
            LinkLabel_GotoLogin.Size = new Size(250, 30);
            LinkLabel_GotoLogin.TabIndex = 7;
            LinkLabel_GotoLogin.TabStop = true;
            LinkLabel_GotoLogin.Text = "Already Have an account? Login Here!";
            LinkLabel_GotoLogin.LinkClicked += LinkLabel_GotoLogin_LinkClicked;
            // 
            // LinkLabel_Signup
            // 
            LinkLabel_Signup.AutoSize = true;
            LinkLabel_Signup.BackColor = Color.Transparent;
            LinkLabel_Signup.Font = new Font("Poppins SemiBold", 9.75F, FontStyle.Bold);
            LinkLabel_Signup.Location = new Point(446, 492);
            LinkLabel_Signup.Name = "LinkLabel_Signup";
            LinkLabel_Signup.Size = new Size(227, 23);
            LinkLabel_Signup.TabIndex = 8;
            LinkLabel_Signup.TabStop = true;
            LinkLabel_Signup.Text = "Don't have an account? Sign Up!";
            LinkLabel_Signup.LinkClicked += LinkLabel_Signup_LinkClicked;
            // 
            // TextBox_PinNoAccount
            // 
            TextBox_PinNoAccount.BackColor = SystemColors.Window;
            TextBox_PinNoAccount.Font = new Font("Poppins", 15.75F);
            TextBox_PinNoAccount.ForeColor = SystemColors.WindowText;
            TextBox_PinNoAccount.Location = new Point(423, 211);
            TextBox_PinNoAccount.Name = "TextBox_PinNoAccount";
            TextBox_PinNoAccount.Size = new Size(288, 39);
            TextBox_PinNoAccount.TabIndex = 2;
            TextBox_PinNoAccount.UseSystemPasswordChar = true;
            // 
            // TextBox_Email
            // 
            TextBox_Email.BackColor = SystemColors.Window;
            TextBox_Email.Font = new Font("Poppins", 15.75F);
            TextBox_Email.Location = new Point(423, 166);
            TextBox_Email.Name = "TextBox_Email";
            TextBox_Email.Size = new Size(288, 39);
            TextBox_Email.TabIndex = 1;
            // 
            // Label_Email
            // 
            Label_Email.AutoSize = true;
            Label_Email.BackColor = Color.Transparent;
            Label_Email.Font = new Font("Poppins", 14.25F);
            Label_Email.Location = new Point(163, 165);
            Label_Email.Name = "Label_Email";
            Label_Email.Size = new Size(77, 34);
            Label_Email.TabIndex = 9;
            Label_Email.Text = "Email :";
            // 
            // Label_Pin
            // 
            Label_Pin.AutoSize = true;
            Label_Pin.BackColor = Color.Transparent;
            Label_Pin.Font = new Font("Poppins", 14.25F);
            Label_Pin.Location = new Point(163, 210);
            Label_Pin.Name = "Label_Pin";
            Label_Pin.Size = new Size(52, 34);
            Label_Pin.TabIndex = 10;
            Label_Pin.Text = "Pin :";
            // 
            // Label_Welcome
            // 
            Label_Welcome.AutoSize = true;
            Label_Welcome.BackColor = Color.Transparent;
            Label_Welcome.Font = new Font("Poppins Black", 24F, FontStyle.Bold);
            Label_Welcome.Location = new Point(257, 85);
            Label_Welcome.Name = "Label_Welcome";
            Label_Welcome.Size = new Size(360, 56);
            Label_Welcome.TabIndex = 11;
            Label_Welcome.Text = "CHANGE PASSWORD";
            // 
            // TextBox_Password
            // 
            TextBox_Password.BackColor = SystemColors.Window;
            TextBox_Password.Enabled = false;
            TextBox_Password.Font = new Font("Poppins", 15.75F);
            TextBox_Password.ForeColor = SystemColors.WindowText;
            TextBox_Password.Location = new Point(423, 333);
            TextBox_Password.Name = "TextBox_Password";
            TextBox_Password.Size = new Size(288, 39);
            TextBox_Password.TabIndex = 3;
            TextBox_Password.UseSystemPasswordChar = true;
            // 
            // Label_Password
            // 
            Label_Password.AutoSize = true;
            Label_Password.BackColor = Color.Transparent;
            Label_Password.Font = new Font("Poppins", 14.25F);
            Label_Password.Location = new Point(163, 335);
            Label_Password.Name = "Label_Password";
            Label_Password.Size = new Size(116, 34);
            Label_Password.TabIndex = 8;
            Label_Password.Text = "Password :";
            // 
            // TextBox_ConfirmPass
            // 
            TextBox_ConfirmPass.BackColor = SystemColors.Window;
            TextBox_ConfirmPass.Enabled = false;
            TextBox_ConfirmPass.Font = new Font("Poppins", 15.75F);
            TextBox_ConfirmPass.ForeColor = SystemColors.WindowText;
            TextBox_ConfirmPass.Location = new Point(423, 378);
            TextBox_ConfirmPass.Name = "TextBox_ConfirmPass";
            TextBox_ConfirmPass.Size = new Size(288, 39);
            TextBox_ConfirmPass.TabIndex = 4;
            TextBox_ConfirmPass.UseSystemPasswordChar = true;
            // 
            // Label_ConfirmPass
            // 
            Label_ConfirmPass.AutoSize = true;
            Label_ConfirmPass.BackColor = Color.Transparent;
            Label_ConfirmPass.Font = new Font("Poppins", 14.25F);
            Label_ConfirmPass.Location = new Point(163, 379);
            Label_ConfirmPass.Name = "Label_ConfirmPass";
            Label_ConfirmPass.Size = new Size(150, 34);
            Label_ConfirmPass.TabIndex = 7;
            Label_ConfirmPass.Text = "Confirm Pass :";
            // 
            // Button_ConfirmWithAccount
            // 
            Button_ConfirmWithAccount.BackColor = Color.Transparent;
            Button_ConfirmWithAccount.FlatAppearance.BorderColor = Color.Black;
            Button_ConfirmWithAccount.FlatStyle = FlatStyle.Flat;
            Button_ConfirmWithAccount.Font = new Font("Poppins ExtraBold", 18F, FontStyle.Bold);
            Button_ConfirmWithAccount.ForeColor = Color.Black;
            Button_ConfirmWithAccount.Location = new Point(423, 422);
            Button_ConfirmWithAccount.Margin = new Padding(0);
            Button_ConfirmWithAccount.Name = "Button_ConfirmWithAccount";
            Button_ConfirmWithAccount.Size = new Size(141, 49);
            Button_ConfirmWithAccount.TabIndex = 21;
            Button_ConfirmWithAccount.Text = "Confirm";
            Button_ConfirmWithAccount.UseVisualStyleBackColor = false;
            Button_ConfirmWithAccount.Visible = false;
            Button_ConfirmWithAccount.Click += Button_ConfirmWithAccount_Click;
            // 
            // Button_ProceedWithAccount
            // 
            Button_ProceedWithAccount.BackColor = Color.Transparent;
            Button_ProceedWithAccount.BackgroundImageLayout = ImageLayout.None;
            Button_ProceedWithAccount.FlatAppearance.BorderColor = Color.Black;
            Button_ProceedWithAccount.FlatStyle = FlatStyle.Flat;
            Button_ProceedWithAccount.Font = new Font("Poppins ExtraBold", 18F, FontStyle.Bold);
            Button_ProceedWithAccount.ForeColor = Color.Black;
            Button_ProceedWithAccount.Location = new Point(423, 255);
            Button_ProceedWithAccount.Margin = new Padding(0);
            Button_ProceedWithAccount.Name = "Button_ProceedWithAccount";
            Button_ProceedWithAccount.Size = new Size(141, 49);
            Button_ProceedWithAccount.TabIndex = 20;
            Button_ProceedWithAccount.Text = "Proceed";
            Button_ProceedWithAccount.UseVisualStyleBackColor = false;
            Button_ProceedWithAccount.Click += Button_ProceedWithAccount_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = SystemColors.ButtonHighlight;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(677, 340);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(29, 24);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 29;
            pictureBox2.TabStop = false;
            pictureBox2.Visible = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ButtonHighlight;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(677, 385);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(29, 24);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 28;
            pictureBox1.TabStop = false;
            pictureBox1.Visible = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = SystemColors.ButtonHighlight;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(677, 218);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(29, 24);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 30;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // ForgotPassword
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(854, 681);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(Button_ConfirmWithAccount);
            Controls.Add(Button_ProceedWithAccount);
            Controls.Add(TextBox_ConfirmPass);
            Controls.Add(Label_ConfirmPass);
            Controls.Add(TextBox_Password);
            Controls.Add(Label_Password);
            Controls.Add(LinkLabel_GotoLogin);
            Controls.Add(LinkLabel_Signup);
            Controls.Add(TextBox_PinNoAccount);
            Controls.Add(TextBox_Email);
            Controls.Add(Label_Email);
            Controls.Add(Label_Pin);
            Controls.Add(Label_Welcome);
            DoubleBuffered = true;
            Name = "ForgotPassword";
            Text = "Form1";
            Load += ForgotPassword_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private LinkLabel LinkLabel_GotoLogin;
        private LinkLabel LinkLabel_Signup;
        private TextBox TextBox_PinNoAccount;
        private TextBox TextBox_Email;
        private Label Label_Email;
        private Label Label_Pin;
        private Label Label_Welcome;
        private TextBox TextBox_Password;
        private Label Label_Password;
        private TextBox TextBox_ConfirmPass;
        private Label Label_ConfirmPass;
        private Button Button_ConfirmWithAccount;
        private Button Button_ProceedWithAccount;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
    }
}