﻿using System.Data.SqlClient;
using System.Drawing.Text;

namespace Appointment1
{
    public partial class AddRecord : Form
    {
        public string username;
        public int userid;
        ContextMenuStrip contextMenu = new ContextMenuStrip();
        ContextMenuStrip recordMenu = new ContextMenuStrip();
        SqlConnection conn;
        PROCESSES process = new PROCESSES();
        private int textBoxCount = 0;
        List<(string Note, DateTime Date)> medicalNotes = new List<(string, DateTime)>();
        public AddRecord(int userid)
        {
            InitializeComponent();
            this.userid = userid;
            this.BackColor = Color.FromArgb(218, 177, 126);
            Label_Appointment.BackColor = Color.LightSkyBlue;
            if (userid < 0)
            {
                this.Hide();
                Login login = new Login(userid);
                login.Show();
            }
            else
            {
                string useremail = process.getUserEmail(userid);

            }
            conn = process.getConnection();
            setFont();
            showContextMenu();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        public void setFont()
        {
           
 
           


            Label_ManageAccount.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_ManageAccount.ClientRectangle.X, Label_ManageAccount.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.Right - cornerRadius, Label_ManageAccount.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.Right - cornerRadius, Label_ManageAccount.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.X, Label_ManageAccount.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_ManageAccount.Region = new Region(path);
                }
                Label_ManageAccount.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_ManageAccount.Text, Label_ManageAccount.Font, Label_ManageAccount.ClientRectangle, Label_ManageAccount.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };



            Label_Appointment.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Appointment.ClientRectangle.X, Label_Appointment.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Appointment.ClientRectangle.Right - cornerRadius, Label_Appointment.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Appointment.ClientRectangle.Right - cornerRadius, Label_Appointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Appointment.ClientRectangle.X, Label_Appointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Appointment.Region = new Region(path);
                }
                Label_Appointment.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Appointment.Text, Label_Appointment.Font, Label_Appointment.ClientRectangle, Label_Appointment.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };


            Label_History.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_History.ClientRectangle.X, Label_History.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_History.ClientRectangle.Right - cornerRadius, Label_History.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_History.ClientRectangle.Right - cornerRadius, Label_History.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_History.ClientRectangle.X, Label_History.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_History.Region = new Region(path);
                }
                Label_History.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_History.Text, Label_History.Font, Label_History.ClientRectangle, Label_History.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };


            Label_Homepage.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Homepage.ClientRectangle.X, Label_Homepage.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Homepage.ClientRectangle.Right - cornerRadius, Label_Homepage.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Homepage.ClientRectangle.Right - cornerRadius, Label_Homepage.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Homepage.ClientRectangle.X, Label_Homepage.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Homepage.Region = new Region(path);
                }
                Label_Homepage.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Homepage.Text, Label_Homepage.Font, Label_Homepage.ClientRectangle, Label_Homepage.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };

            Label_Shop.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Shop.ClientRectangle.X, Label_Shop.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Shop.ClientRectangle.Right - cornerRadius, Label_Shop.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Shop.ClientRectangle.Right - cornerRadius, Label_Shop.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Shop.ClientRectangle.X, Label_Shop.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Shop.Region = new Region(path);
                }
                Label_Shop.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Shop.Text, Label_Shop.Font, Label_Shop.ClientRectangle, Label_Shop.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };

        }








        public void showContextMenu()
        {
            ToolStripMenuItem changepass = new ToolStripMenuItem("Manage Account");
            ToolStripMenuItem logoutItem = new ToolStripMenuItem("Logout");
            ToolStripMenuItem newrecord = new ToolStripMenuItem("New Patient");
            ToolStripMenuItem existingrecord = new ToolStripMenuItem("Existing Patient");
            contextMenu.Font = new Font("Arial", 15, FontStyle.Bold);
            recordMenu.Font = new Font("Arial", 15, FontStyle.Bold);
            contextMenu.Items.Add(changepass);
            contextMenu.Items.Add(logoutItem);
            recordMenu.Items.Add(newrecord);
            recordMenu.Items.Add(existingrecord);
            changepass.Click += (sender, e) =>
            {
                ManageAccount changepass = new ManageAccount(userid);
                changepass.Show();
                this.Hide();
            };
            logoutItem.Click += (sender, e) =>
            {
                userid = -1;
                Login login = new Login(userid);
                login.Show();
                this.Hide();
            };

            newrecord.Click += (sender, e) =>
            {
                AddRecord changepass = new AddRecord(userid);
                changepass.Show();
                this.Hide();
            };
            existingrecord.Click += (sender, e) =>
            {
                ExistingRecord changepass = new ExistingRecord(userid);
                changepass.Show();
                this.Hide();
            };

            Label_ManageAccount.ContextMenuStrip = contextMenu;
            Label_ManageAccount.MouseEnter += (sender, e) =>
            {
                contextMenu.Show(Label_ManageAccount, Label_ManageAccount.PointToClient(Cursor.Position));
            };

            Label_Appointment.ContextMenuStrip = recordMenu;
            Label_Appointment.MouseEnter += (sender, e) =>
            {
                recordMenu.Show(Label_Appointment, Label_Appointment.PointToClient(Cursor.Position));
            };
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////

        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        ///


        public void GetUserInfo()
        {
            string petname, breed, petgender, owner, contactnum, email, status;
            if (RadioButton_Male.Checked) { petgender = "Male"; }
            else if (RadioButton_Female.Checked) { petgender = "Female"; }
            else { petgender = ""; }

            DateTime petbday = TextBox_Birthday.Value;
            petname = TextBox_PetName.Text;
            breed = TextBox_Breed.Text;
            owner = TextBox_Owner.Text;
            contactnum = TextBox_Contact.Text;
            email = TextBox_Email.Text;
            status = "Pending";

            // Check if static fields are valid (not empty)
            bool isValid = !string.IsNullOrEmpty(petname) &&
                           !string.IsNullOrEmpty(breed) &&
                           !string.IsNullOrEmpty(petgender) &&
                           petbday != DateTime.MinValue &&
                           !string.IsNullOrEmpty(owner) &&
                           !string.IsNullOrEmpty(contactnum) &&
                           !string.IsNullOrEmpty(email) &&
                           !string.IsNullOrEmpty(status);


            Button_AddToRecord.Enabled = isValid;
        }

        private void AddRecord_Load(object sender, EventArgs e)
        {

        }


        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void Button_AddToRecord_Click(object sender, EventArgs e)
        {

            string petname, breed, petgender, owner, contactnum, email, status;
            medicalNotes.Clear();

            if (RadioButton_Male.Checked) { petgender = "Male"; }
            else if (RadioButton_Female.Checked) { petgender = "Female"; }
            else { petgender = ""; }
            DateTime petbday = TextBox_Birthday.Value.Date;
            DateTime now = DateTime.Now.Date;
            if (petbday == now)
            {
                MessageBox.Show("Please Choose A Valid Birthdate!!");
                return;
            }
            petname = TextBox_PetName.Text;
            breed = TextBox_Breed.Text;
            owner = TextBox_Owner.Text;
            contactnum = TextBox_Contact.Text;
            email = TextBox_Email.Text;
            status = "Pending";
            int counter = process.AddRecord_CheckDatabase(petname, owner, email);
            if (counter != 0) { MessageBox.Show("Record has already been added!!!"); }
            else
            {

                foreach (Control control in medpanel.Controls)
                {
                    if (control is TextBox textBox)
                    {
                        // Find the corresponding DateTimePicker for the TextBox (based on position)
                        DateTimePicker datePicker = medpanel.Controls
                            .OfType<DateTimePicker>()
                            .FirstOrDefault(dp => dp.Top == textBox.Top && dp.Left > textBox.Left);

                        if (datePicker != null)
                        {
                            string medicalNote = textBox.Text;
                            DateTime medicalDate = datePicker.Value;

                            // Check if either the medical note or the date is invalid
                            if (string.IsNullOrEmpty(medicalNote) || medicalDate == DateTime.MinValue)
                            {
                                MessageBox.Show("Please input a service");  // If any note or date is invalid, invalidate the form
                                return;  // Exit the loop early as we already found an invalid field
                            }

                            // Add valid notes and dates to the list
                            medicalNotes.Add((medicalNote, medicalDate));
                        }
                    }
                }

                // Call the updated AddRecord_AddToDatabase with medical notes
                process.AddRecord_AddToDatabase(
                    petname, petbday, breed, petgender, owner, contactnum, email, status, medicalNotes);
            }


        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////

        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            GetUserInfo();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            GetUserInfo();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime selecteddate = TextBox_Birthday.Value.Date;
            DateTime now = DateTime.Now.Date;

            if (selecteddate == now)
            {
                MessageBox.Show("Please Choose A Valid Birthdate!!");
                return;
            }
            GetUserInfo();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void Label_Homepage_Click(object sender, EventArgs e)
        {
            string Username = username;
            Homepage homepage = new Homepage(userid);
            homepage.Show();
            this.Hide();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////

        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void TextBox_PetName_TextChanged(object sender, EventArgs e)
        {
            GetUserInfo();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void TextBox_Breed_TextChanged(object sender, EventArgs e)
        {
            GetUserInfo();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void TextBox_Owner_TextChanged(object sender, EventArgs e)
        {
            GetUserInfo();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void TextBox_ContactNumber_TextChanged(object sender, EventArgs e)
        {
            GetUserInfo();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void TextBox_Email_TextChanged(object sender, EventArgs e)
        {
            GetUserInfo();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void TextBox_Note_TextChanged(object sender, EventArgs e)
        {
            GetUserInfo();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            TextBox textBox1 = new TextBox
            {
                Width = 150,
                Top = textBoxCount * 30, // Arrange below the previous set
                Left = 10
            };

            // Create second TextBox
            DateTimePicker textBox2 = new DateTimePicker
            {
                Width = 200,
                Top = textBoxCount * 30,
                Left = 170 // Place it beside the first
            };

            // Add text boxes to medpanel
            medpanel.Controls.Add(textBox1);
            medpanel.Controls.Add(textBox2);



            // Increment the text box count
            textBoxCount++;

        }



        private void btnDelete_Click(object sender, EventArgs e)
        {
            foreach (Control control in medpanel.Controls.OfType<Control>().ToList())
            {
                medpanel.Controls.Remove(control);
            }

            // Optionally reset the textBoxCount if you want it to start from zero when adding new controls
            textBoxCount = 0;
        }

        private void Label_History_Click(object sender, EventArgs e)
        {

            int userid = this.userid;
            HistoryRecordsPending history = new HistoryRecordsPending(userid);
            history.Show();
            this.Hide();

        }



        // Inside your AddRecord class
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Rectangle rectangle = new Rectangle(0, 0, 1080, 115); // X, Y, Width, Height


            using (SolidBrush brush = new SolidBrush(Color.FromArgb(151, 97, 51))) // 128 = 50% opacity, Green color
            {

                e.Graphics.FillRectangle(brush, rectangle);
            }



            Rectangle rectanglebg = new Rectangle(34, 200, 520, 150); // X, Y, Width, Height
            using (System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath())
            {
                int cornerRadius = 30;
                // Top-left corner
                path.AddArc(rectanglebg.Left, rectanglebg.Top, cornerRadius * 2, cornerRadius * 2, 180, 90);
                // Top-right corner
                path.AddArc(rectanglebg.Right - cornerRadius * 2, rectanglebg.Top, cornerRadius * 2, cornerRadius * 2, 270, 90);
                // Bottom-right corner
                path.AddArc(rectanglebg.Right - cornerRadius * 2, rectanglebg.Bottom - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 0, 90);
                // Bottom-left corner
                path.AddArc(rectanglebg.Left, rectanglebg.Bottom - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 90, 90);
                path.CloseFigure(); // Close the path to form a complete rounded rectangle

                using (SolidBrush brush = new SolidBrush(Color.FromArgb(255, 245, 233))) // 128 = 50% opacity, Green color
                {

                    e.Graphics.FillPath(brush, path);
                }
            }

            Rectangle rectanglebg2 = new Rectangle(34, 425, 520, 125); // X, Y, Width, Height

            // Radius of the curved corners

            // Create a GraphicsPath for the rounded rectangle
            using (System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath())
            {
                int cornerRadius = 30;
                // Top-left corner
                path.AddArc(rectanglebg2.Left, rectanglebg2.Top, cornerRadius * 2, cornerRadius * 2, 180, 90);
                // Top-right corner
                path.AddArc(rectanglebg2.Right - cornerRadius * 2, rectanglebg2.Top, cornerRadius * 2, cornerRadius * 2, 270, 90);
                // Bottom-right corner
                path.AddArc(rectanglebg2.Right - cornerRadius * 2, rectanglebg2.Bottom - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 0, 90);
                // Bottom-left corner
                path.AddArc(rectanglebg2.Left, rectanglebg2.Bottom - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 90, 90);
                path.CloseFigure(); // Close the path to form a complete rounded rectangle

                // Create a semi-transparent brush
                using (SolidBrush brush = new SolidBrush(Color.FromArgb(255, 245, 233))) // 200 = 80% opacity
                {
                    // Fill the rounded rectangle
                    e.Graphics.FillPath(brush, path);
                }
            }









        }

        private void Label_Shop_Click(object sender, EventArgs e)
        {

            staff_inventory staffinvent = new staff_inventory(userid);
            staffinvent.Show();
            this.Hide();
        }








        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        ///









    }
}
