﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing.Text;
using System.Windows.Forms;

namespace Appointment1
{
    public partial class frmFollowUp : Form
    {
        PROCESSES process = new PROCESSES();
        SqlConnection conn;
        private int appID;
        private string ownerName, petName, breed, gender, contactNo, email, status, date;
        private DateTime birthday;
        Form frmAppointments;


        public frmFollowUp(Form frmAppointments, string date, int appID, string ownerName, string petName, string breed, DateTime birthday, string gender, string contactNo, string email, string status)
        {
            InitializeComponent();
            this.frmAppointments = frmAppointments;
            this.appID = appID;
            this.BackColor = Color.FromArgb(218, 177, 126);
            this.date = date;
            this.ownerName = ownerName;
            this.petName = petName;
            this.breed = breed;
            this.birthday = birthday;
            this.gender = gender;
            this.contactNo = contactNo;
            this.email = email;
            this.status = status;
            conn = process.getConnection();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            // Dictionary to map checkbox selections to follow-up durations in days
            Dictionary<string, int> followUpDurations = new Dictionary<string, int>
    {
        { "cb1", 365 }, // Distemper Vaccine - 1 year
        { "cb2", 365 }, // Parvovirus Vaccine - 1 year
        { "cb3", 182 }, // Bordetella Vaccine - 6 months
        { "cb4", 365 }, // Dental Cleaning - 1 year
        { "cb5", 365 }, // Heartworm Test - 1 year
        { "cb6", 365 }, // Annual Wellness Exam - 1 year
        { "cb7", 30 },  // Flea and Tick Prevention - Monthly
        { "cb8", 365 }, // Leptospirosis Vaccine - 1 year
        { "cb9", 90 },  // Deworming - 3 months
        { "cb10", 365 } // Rabies Vaccine - 1 year
    };

            // Map checkboxes to their respective keys
            Dictionary<string, CheckBox> checkBoxMapping = new Dictionary<string, CheckBox>
    {
        { "cb1", cb1 },
        { "cb2", cb2 },
        { "cb3", cb3 },
        { "cb4", cb4 },
        { "cb5", cb5 },
        { "cb6", cb6 },
        { "cb7", cb7 },
        { "cb8", cb8 },
        { "cb9", cb9 },
        { "cb10", cb10 }
    };

            // Parse the received date
            if (!DateTime.TryParse(date, out DateTime baseDate))
            {
                MessageBox.Show("Invalid date format. Please check the date value.");
                return;
            }

            using (SqlConnection conn = process.getConnection())
            {
                conn.Open();
                using (SqlTransaction transaction = conn.BeginTransaction())
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.Transaction = transaction;

                    try
                    {
                  

                    

                        // Update the status of the current appointment to 'Done'
        
                 

                        // Insert follow-up records based on selected checkboxes
                        foreach (var entry in checkBoxMapping)
                        {
                            string key = entry.Key;
                            CheckBox checkBox = entry.Value;

                            if (checkBox.Checked)
                            {
                                // Calculate follow-up date based on the received date
                                DateTime followUpDate = baseDate.AddDays(followUpDurations[key]);

                                // Adjust for weekends
                                if (followUpDate.DayOfWeek == DayOfWeek.Saturday)
                                    followUpDate = followUpDate.AddDays(2);
                                else if (followUpDate.DayOfWeek == DayOfWeek.Sunday)
                                    followUpDate = followUpDate.AddDays(1);

                                // Insert a new follow-up record
                                command.CommandText = @"
                                    -- Insert a new record into the schedule table
                                      IF EXISTS (
                                                    SELECT 1 
                                                    FROM schedule 
                                                    WHERE appid = @appid 
                                                      AND service = @service 
                                                      AND date = @date
                                                )
                                                BEGIN
                                                    UPDATE schedule
                                                    SET status = 'Pending'
                                                    WHERE appid = @appid 
                                                      AND service = @service 
                                                      AND date = @date;
                                                END
                                                ELSE
                                                BEGIN
                                                    INSERT INTO schedule (appid, service, date, status)
                                                    VALUES (@appid, @service, @date, @status);
                                                END


                                     UPDATE schedule
                                        SET status = 'Done'
                                        WHERE appid = @appid 
                                          AND service IS NULL
                                          AND date = @basedate;


                                    -- Check if a record with the same appid, service, and date already exists
                                    IF EXISTS (
                                        SELECT 1 
                                        FROM schedule 
                                        WHERE appid = @appid 
                                          AND 
                                              service = @service 
                                             
                                          AND date = @basedate
                                    )
                                    BEGIN
                                        -- Update the existing record to 'Done'
                                        UPDATE schedule
                                        SET status = 'Done'
                                        WHERE appid = @appid 
                                          AND 
                                              service = @service 
                                           
                                          AND date = @basedate
                                    END
                                    ELSE
                                    BEGIN
                                        -- Insert a new record with the Done status
                                        INSERT INTO schedule (appid, service, date, status)
                                        VALUES (@appid, @service, @basedate, @donestatus)
                                    END

                                     ";

                                command.Parameters.Clear();
                                command.Parameters.AddWithValue("@appid", appID);
                                command.Parameters.AddWithValue("@service", checkBox.Text);
                                command.Parameters.AddWithValue("@date", followUpDate.Date);
                                command.Parameters.AddWithValue("@basedate", baseDate.Date);// Only the date part
                                command.Parameters.AddWithValue("@status", "Pending");
                                command.Parameters.AddWithValue("@donestatus", "Done");
                                command.ExecuteNonQuery();
                            }
                        }

                        transaction.Commit();
                        MessageBox.Show("Follow-up appointments successfully scheduled and updated.");
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show($"An error occurred: {ex.Message}");
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }

            
            frmAppointments.Hide();
            this.Hide();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // Define the dimensions of the rectangle
            Rectangle rectangle = new Rectangle(15, 20, 350, 350); // X, Y, Width, Height
            int cornerRadius = 30; // Radius of the curved corners

            // Create a GraphicsPath for the rounded rectangle
            using (System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath())
            {
                // Top-left corner
                path.AddArc(rectangle.Left, rectangle.Top, cornerRadius * 2, cornerRadius * 2, 180, 90);
                // Top-right corner
                path.AddArc(rectangle.Right - cornerRadius * 2, rectangle.Top, cornerRadius * 2, cornerRadius * 2, 270, 90);
                // Bottom-right corner
                path.AddArc(rectangle.Right - cornerRadius * 2, rectangle.Bottom - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 0, 90);
                // Bottom-left corner
                path.AddArc(rectangle.Left, rectangle.Bottom - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 90, 90);
                path.CloseFigure(); // Close the path to form a complete rounded rectangle



                // Create a semi-transparent brush
                using (SolidBrush brush = new SolidBrush(Color.FromArgb(255, 245, 233))) // 200 = 80% opacity
                {
                    // Fill the rounded rectangle
                    e.Graphics.FillPath(brush, path);
                }


                // Create a pen for the border


            }
        }




    }
}
