﻿namespace Appointment1
{
    partial class UserControldays
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Label_Day = new Label();
            SuspendLayout();
            // 
            // Label_Day
            // 
            Label_Day.AutoSize = true;
            Label_Day.Font = new Font("Poppins SemiBold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label_Day.Location = new Point(18, 14);
            Label_Day.Margin = new Padding(0);
            Label_Day.Name = "Label_Day";
            Label_Day.Size = new Size(32, 28);
            Label_Day.TabIndex = 0;
            Label_Day.Text = "00";
            // 
            // UserControldays
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(Label_Day);
            Name = "UserControldays";
            Size = new Size(66, 55);
            Load += UserControldays_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        public Label Label_Day;
    }
}
