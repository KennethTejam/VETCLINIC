﻿namespace Appointment1
{
    partial class IconContainer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(IconContainer));
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton4 = new RadioButton();
            radioButton5 = new RadioButton();
            radioButton6 = new RadioButton();
            radioButton7 = new RadioButton();
            radioButton9 = new RadioButton();
            Button_Confirm = new Label();
            Button_Back = new Label();
            SuspendLayout();
            // 
            // radioButton1
            // 
            radioButton1.Appearance = Appearance.Button;
            radioButton1.FlatStyle = FlatStyle.Flat;
            radioButton1.ForeColor = Color.Black;
            radioButton1.Image = (Image)resources.GetObject("radioButton1.Image");
            radioButton1.Location = new Point(12, 12);
            radioButton1.Margin = new Padding(10);
            radioButton1.Name = "radioButton1";
            radioButton1.Padding = new Padding(5);
            radioButton1.Size = new Size(102, 97);
            radioButton1.TabIndex = 10;
            radioButton1.TabStop = true;
            radioButton1.TextAlign = ContentAlignment.MiddleCenter;
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // radioButton2
            // 
            radioButton2.Appearance = Appearance.Button;
            radioButton2.FlatStyle = FlatStyle.Flat;
            radioButton2.ForeColor = Color.Black;
            radioButton2.Image = (Image)resources.GetObject("radioButton2.Image");
            radioButton2.Location = new Point(120, 11);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(102, 97);
            radioButton2.TabIndex = 11;
            radioButton2.TabStop = true;
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // radioButton3
            // 
            radioButton3.Appearance = Appearance.Button;
            radioButton3.FlatStyle = FlatStyle.Flat;
            radioButton3.ForeColor = Color.Black;
            radioButton3.Image = (Image)resources.GetObject("radioButton3.Image");
            radioButton3.Location = new Point(228, 11);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(102, 97);
            radioButton3.TabIndex = 12;
            radioButton3.TabStop = true;
            radioButton3.UseVisualStyleBackColor = true;
            radioButton3.CheckedChanged += radioButton3_CheckedChanged;
            // 
            // radioButton4
            // 
            radioButton4.Appearance = Appearance.Button;
            radioButton4.FlatStyle = FlatStyle.Flat;
            radioButton4.ForeColor = Color.Black;
            radioButton4.Image = (Image)resources.GetObject("radioButton4.Image");
            radioButton4.Location = new Point(336, 11);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(102, 97);
            radioButton4.TabIndex = 13;
            radioButton4.TabStop = true;
            radioButton4.UseVisualStyleBackColor = true;
            radioButton4.CheckedChanged += radioButton4_CheckedChanged;
            // 
            // radioButton5
            // 
            radioButton5.Appearance = Appearance.Button;
            radioButton5.CheckAlign = ContentAlignment.TopCenter;
            radioButton5.FlatStyle = FlatStyle.Flat;
            radioButton5.ForeColor = Color.Black;
            radioButton5.Image = (Image)resources.GetObject("radioButton5.Image");
            radioButton5.Location = new Point(12, 114);
            radioButton5.Margin = new Padding(10);
            radioButton5.Name = "radioButton5";
            radioButton5.Padding = new Padding(5);
            radioButton5.Size = new Size(102, 97);
            radioButton5.TabIndex = 14;
            radioButton5.TabStop = true;
            radioButton5.TextAlign = ContentAlignment.TopCenter;
            radioButton5.UseVisualStyleBackColor = true;
            radioButton5.CheckedChanged += radioButton5_CheckedChanged;
            // 
            // radioButton6
            // 
            radioButton6.Appearance = Appearance.Button;
            radioButton6.FlatStyle = FlatStyle.Flat;
            radioButton6.ForeColor = Color.Black;
            radioButton6.Image = (Image)resources.GetObject("radioButton6.Image");
            radioButton6.Location = new Point(120, 114);
            radioButton6.Name = "radioButton6";
            radioButton6.Size = new Size(102, 97);
            radioButton6.TabIndex = 15;
            radioButton6.TabStop = true;
            radioButton6.UseVisualStyleBackColor = true;
            radioButton6.CheckedChanged += radioButton6_CheckedChanged;
            // 
            // radioButton7
            // 
            radioButton7.Appearance = Appearance.Button;
            radioButton7.FlatStyle = FlatStyle.Flat;
            radioButton7.ForeColor = Color.Black;
            radioButton7.Image = (Image)resources.GetObject("radioButton7.Image");
            radioButton7.Location = new Point(228, 114);
            radioButton7.Name = "radioButton7";
            radioButton7.Size = new Size(102, 97);
            radioButton7.TabIndex = 16;
            radioButton7.TabStop = true;
            radioButton7.UseVisualStyleBackColor = true;
            radioButton7.CheckedChanged += radioButton7_CheckedChanged;
            // 
            // radioButton9
            // 
            radioButton9.Appearance = Appearance.Button;
            radioButton9.FlatStyle = FlatStyle.Flat;
            radioButton9.ForeColor = Color.Black;
            radioButton9.Image = (Image)resources.GetObject("radioButton9.Image");
            radioButton9.Location = new Point(336, 113);
            radioButton9.Name = "radioButton9";
            radioButton9.Size = new Size(102, 97);
            radioButton9.TabIndex = 18;
            radioButton9.TabStop = true;
            radioButton9.UseVisualStyleBackColor = true;
            radioButton9.CheckedChanged += radioButton9_CheckedChanged;
            // 
            // Button_Confirm
            // 
            Button_Confirm.BackColor = Color.Transparent;
            Button_Confirm.BorderStyle = BorderStyle.FixedSingle;
            Button_Confirm.Location = new Point(336, 222);
            Button_Confirm.Name = "Button_Confirm";
            Button_Confirm.Padding = new Padding(10, 5, 15, 5);
            Button_Confirm.Size = new Size(102, 36);
            Button_Confirm.TabIndex = 19;
            Button_Confirm.Text = "Confirm";
            Button_Confirm.Click += Button_Confirm_Click_1;
            // 
            // Button_Back
            // 
            Button_Back.BackColor = Color.Transparent;
            Button_Back.BorderStyle = BorderStyle.FixedSingle;
            Button_Back.Location = new Point(12, 221);
            Button_Back.Name = "Button_Back";
            Button_Back.Padding = new Padding(20, 5, 15, 5);
            Button_Back.Size = new Size(102, 37);
            Button_Back.TabIndex = 20;
            Button_Back.Text = "Back";
            Button_Back.Click += Button_Back_Click;
            // 
            // IconContainer
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(467, 282);
            Controls.Add(Button_Back);
            Controls.Add(Button_Confirm);
            Controls.Add(radioButton9);
            Controls.Add(radioButton7);
            Controls.Add(radioButton6);
            Controls.Add(radioButton5);
            Controls.Add(radioButton4);
            Controls.Add(radioButton3);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Name = "IconContainer";
            Text = "IconContainer";
            ResumeLayout(false);
        }

        #endregion
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
        private RadioButton radioButton4;
        private RadioButton radioButton5;
        private RadioButton radioButton6;
        private RadioButton radioButton7;
        private RadioButton radioButton9;
        private Label Button_Confirm;
        private Label Button_Back;
    }
}