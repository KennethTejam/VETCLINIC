﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appointment1
{
    public partial class staff_inventory : Form
    {
        SqlConnection conn;
        private string connectionString = @"Data Source=DESKTOP-MSA24LI\SQLEXPRESS;Initial Catalog=CLINIC_DB;Integrated Security=True;";
        PROCESSES process = new PROCESSES();
        ContextMenuStrip contextMenu = new ContextMenuStrip();
        ContextMenuStrip recordMenu = new ContextMenuStrip();
        int userid;
        public staff_inventory(int userid)
        {
            InitializeComponent();
            this.userid = userid;
            conn = process.getConnection();
            setFont();
            showTable();
            this.BackColor = Color.FromArgb(255, 243, 233);
            showContextMenurecord();

        }


        public void showContextMenurecord()
        {
            ToolStripMenuItem changepass = new ToolStripMenuItem("Manage Account");
            ToolStripMenuItem logoutItem = new ToolStripMenuItem("Logout");
            ToolStripMenuItem newrecord = new ToolStripMenuItem("New Patient");
            ToolStripMenuItem existingrecord = new ToolStripMenuItem("Existing Patient");
            contextMenu.Font = new Font("Arial", 15, FontStyle.Bold);
            recordMenu.Font = new Font("Arial", 15, FontStyle.Bold);
            contextMenu.Items.Add(changepass);
            contextMenu.Items.Add(logoutItem);
            recordMenu.Items.Add(newrecord);
            recordMenu.Items.Add(existingrecord);
            changepass.Click += (sender, e) =>
            {
                ManageAccount changepass = new ManageAccount(userid);
                changepass.Show();
                this.Hide();
            };
            logoutItem.Click += (sender, e) =>
            {
                userid = -1;
                Login login = new Login(userid);
                login.Show();
                this.Hide();
            };

            newrecord.Click += (sender, e) =>
            {
                AddRecord changepass = new AddRecord(userid);
                changepass.Show();
                this.Hide();
            };
            existingrecord.Click += (sender, e) =>
            {
                ExistingRecord changepass = new ExistingRecord(userid);
                changepass.Show();
                this.Hide();
            };

            Label_ManageAccount.ContextMenuStrip = contextMenu;
            Label_ManageAccount.MouseEnter += (sender, e) =>
            {
                contextMenu.Show(Label_ManageAccount, Label_ManageAccount.PointToClient(Cursor.Position));
            };

            Label_Appointment.ContextMenuStrip = recordMenu;
            Label_Appointment.MouseEnter += (sender, e) =>
            {
                recordMenu.Show(Label_Appointment, Label_Appointment.PointToClient(Cursor.Position));
            };

        }


        /// <summary>
        /// 
        /// ////
        /// </summary>






        /// <summary>
        /// //
        /// ////
        /// </summary>
        public void showTable()
        {
            panel1.Controls.Clear();
            try
            {
                string query = "Select * from inventory;";
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);

                SqlDataReader reader = cmd.ExecuteReader();

                int i = 0;
                int j = 0;
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Panel lblAppointment = new Panel();
                        Label lblAppointmentid = new Label();
                        Label lblAppointmentname = new Label();
                        Label lblAppointmentqty = new Label();
                        Label lblAppointmenttype = new Label();
                        Label lblAppointmentprice = new Label();
                        ///
                        ///
                        ///
                        ///
                        
                        lblAppointmentid.Text = $"{reader["productid"].ToString()}";
                        lblAppointmentid.Location = new Point(30, 0);
                        lblAppointmentid.AutoSize = true;
                        lblAppointmentid.ForeColor = Color.Black;

                        lblAppointmentname.Text = $"{reader["product_name"].ToString()}";
                        lblAppointmentname.Location = new Point(130, 0);
                        lblAppointmentname.AutoSize = true;
                        lblAppointmentname.ForeColor = Color.Black;

                        lblAppointmentqty.Text = $"{reader["quantity"].ToString()}";
                        lblAppointmentqty.Location = new Point(380, 0);
                        lblAppointmentqty.AutoSize = true;
                        lblAppointmentqty.ForeColor = Color.Black;

                        lblAppointmentprice.Text = $"{reader["price"].ToString()}";
                        lblAppointmentprice.Location = new Point(480, 0);
                        lblAppointmentprice.AutoSize = true;
                        lblAppointmentprice.ForeColor = Color.Black;

                        lblAppointmenttype.Text = $"{reader["type"].ToString()}";
                        lblAppointmenttype.Location = new Point(680, 0);
                        lblAppointmenttype.AutoSize = true;
                        lblAppointmenttype.ForeColor = Color.Black;

                        lblAppointment.Controls.Add(lblAppointmenttype);
                        lblAppointment.Controls.Add(lblAppointmentprice);
                        lblAppointment.Controls.Add(lblAppointmentqty);
                        lblAppointment.Controls.Add(lblAppointmentid);
                        lblAppointment.Controls.Add(lblAppointmentname);
                        ///
                        ///
                        ///
                        ///
                        lblAppointment.AutoSize = false;
                        lblAppointment.Size = new Size(840, 45);
                        lblAppointment.Location = new Point(2, 10 + (i * 50));
                        int appID = Convert.ToInt32(reader["productid"]);
                        lblAppointment.Click += (sender, e) => MessageBox.Show(appID.ToString());
                        lblAppointment.Paint += (s, e) =>
                        {
                            using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                            {
                                int cornerRadius = 45;
                                path.AddArc(lblAppointment.ClientRectangle.X, lblAppointment.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                                path.AddArc(lblAppointment.ClientRectangle.Right - cornerRadius, lblAppointment.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                                path.AddArc(lblAppointment.ClientRectangle.Right - cornerRadius, lblAppointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                                path.AddArc(lblAppointment.ClientRectangle.X, lblAppointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                                path.CloseFigure();
                                lblAppointment.Region = new Region(path);
                            }
                            lblAppointment.BackColor = Color.FromArgb(233, 200, 168);

                        };
                        panel1.Controls.Add(lblAppointment);
                        i++;
                        lblAppointment.Visible = true;
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading appointments: " + ex.Message);
            }
            finally { conn.Close(); }
        }

        public void setFont()
        {
      
            Label lblLabelprdnme = new Label();
                Label lblLabelqty = new Label();
                Label lblLabelid = new Label();
                Label lblLabelprice = new Label();
                Label lblLabeltype = new Label();
                lblLabelprdnme.Text = "Product Name";
                lblLabelprdnme.Location = new Point(130, 0);
                lblLabelprdnme.ForeColor = Color.Black;


                lblLabelqty.Text = "Qty";
                lblLabelqty.Location = new Point(380, 0);

                lblLabelqty.ForeColor = Color.Black;


                lblLabelid.Text = "ID";
                lblLabelid.Location = new Point(30, 0);
                lblLabelid.ForeColor = Color.Black;


                lblLabelprice.Text = "Price";
                lblLabelprice.Location = new Point(480, 0);
                lblLabelprice.ForeColor = Color.Black;


                lblLabeltype.Text = "Type";
                lblLabeltype.Location = new Point(680, 0);
                lblLabeltype.ForeColor = Color.Black;

                panel2.Controls.Add(lblLabelprdnme);
                panel2.Controls.Add(lblLabelqty);
                panel2.Controls.Add(lblLabelid);
                panel2.Controls.Add(lblLabelprice);
                panel2.Controls.Add(lblLabeltype);
 



         

            Label_ManageAccount.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_ManageAccount.ClientRectangle.X, Label_ManageAccount.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.Right - cornerRadius, Label_ManageAccount.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.Right - cornerRadius, Label_ManageAccount.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.X, Label_ManageAccount.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_ManageAccount.Region = new Region(path);
                }
                Label_ManageAccount.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_ManageAccount.Text, Label_ManageAccount.Font, Label_ManageAccount.ClientRectangle, Label_ManageAccount.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };



            Label_Appointment.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Appointment.ClientRectangle.X, Label_Appointment.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Appointment.ClientRectangle.Right - cornerRadius, Label_Appointment.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Appointment.ClientRectangle.Right - cornerRadius, Label_Appointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Appointment.ClientRectangle.X, Label_Appointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Appointment.Region = new Region(path);
                }
                Label_Appointment.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Appointment.Text, Label_Appointment.Font, Label_Appointment.ClientRectangle, Label_Appointment.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };


            Label_History.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_History.ClientRectangle.X, Label_History.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_History.ClientRectangle.Right - cornerRadius, Label_History.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_History.ClientRectangle.Right - cornerRadius, Label_History.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_History.ClientRectangle.X, Label_History.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_History.Region = new Region(path);
                }
                Label_History.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_History.Text, Label_History.Font, Label_History.ClientRectangle, Label_History.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };


            Label_Homepage.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Homepage.ClientRectangle.X, Label_Homepage.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Homepage.ClientRectangle.Right - cornerRadius, Label_Homepage.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Homepage.ClientRectangle.Right - cornerRadius, Label_Homepage.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Homepage.ClientRectangle.X, Label_Homepage.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Homepage.Region = new Region(path);
                }
                Label_Homepage.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Homepage.Text, Label_Homepage.Font, Label_Homepage.ClientRectangle, Label_Homepage.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };

            Label_Shop.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Shop.ClientRectangle.X, Label_Shop.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Shop.ClientRectangle.Right - cornerRadius, Label_Shop.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Shop.ClientRectangle.Right - cornerRadius, Label_Shop.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Shop.ClientRectangle.X, Label_Shop.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Shop.Region = new Region(path);
                }
                Label_Shop.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Shop.Text, Label_Shop.Font, Label_Shop.ClientRectangle, Label_Shop.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Rectangle rectangle = new Rectangle(0, 0, 1080, 115); // X, Y, Width, Height

            // Create a semi-transparent brush
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(151, 97, 51))) // 128 = 50% opacity, Green color
            {
                // Draw the rectangle in the specified position
                e.Graphics.FillRectangle(brush, rectangle);
            }

            Rectangle rectangle2 = new Rectangle(900, 160, 170, 720); // X, Y, Width, Height

            // Create a semi-transparent brush
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(218, 177, 126))) // 128 = 50% opacity, Green color
            {

                e.Graphics.FillRectangle(brush, rectangle2);
            }
        }

        private void staff_inventory_Load(object sender, EventArgs e)
        {
        }

        private void Label_History_Click(object sender, EventArgs e)
        {

        }

        private void Label_Homepage_Click(object sender, EventArgs e)
        {
            Homepage homepage = new Homepage(userid);
            homepage.Show();
            this.Hide();
        }

        private void Label_ManageAccount_Click(object sender, EventArgs e)
        {
            ManageAccount manageAccount = new ManageAccount(userid);
            manageAccount.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            staff_inventoryaddbtn stfadd = new staff_inventoryaddbtn();
            stfadd.ShowDialog();
            showTable();
        }

        private void Label_Add_Click(object sender, EventArgs e)
        {
            staff_inventoryaddbtn stfadd = new staff_inventoryaddbtn();
            stfadd.ShowDialog();
            showTable();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            staff_delbtn stfdel = new staff_delbtn();
            stfdel.ShowDialog();
            showTable();
        }

        private void Label_Delete_Click(object sender, EventArgs e)
        {
            staff_delbtn stfdel = new staff_delbtn();
            stfdel.ShowDialog();
            showTable();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            staff_inventoryeditbtn stfedit = new staff_inventoryeditbtn();
            stfedit.ShowDialog();
            showTable();
        }

        private void Label_Edit_Click(object sender, EventArgs e)
        {
            staff_inventoryeditbtn stfedit = new staff_inventoryeditbtn();
            stfedit.ShowDialog();
            showTable();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            Staff_Checkout stfchkout = new Staff_Checkout();
            stfchkout.ShowDialog();
            showTable();
        }

        private void Label_Checkout_Click(object sender, EventArgs e)
        {
            Staff_Checkout stfchkout = new Staff_Checkout();
            stfchkout.ShowDialog();
            showTable();
        }


    }
}
