﻿namespace Appointment1
{
    partial class Login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            LinkLabel_Signup = new LinkLabel();
            TextBox_Password = new TextBox();
            TextBox_Email = new TextBox();
            Button_Login = new Button();
            Label_Email = new Label();
            Label_Password = new Label();
            LinkLabel_ChangePassword = new LinkLabel();
            PictureBox_PasswordViewer = new PictureBox();
            Label_Welcome = new Label();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)PictureBox_PasswordViewer).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // LinkLabel_Signup
            // 
            LinkLabel_Signup.AutoSize = true;
            LinkLabel_Signup.BackColor = Color.Transparent;
            LinkLabel_Signup.Font = new Font("Poppins SemiBold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LinkLabel_Signup.Location = new Point(408, 527);
            LinkLabel_Signup.Name = "LinkLabel_Signup";
            LinkLabel_Signup.Size = new Size(258, 23);
            LinkLabel_Signup.TabIndex = 4;
            LinkLabel_Signup.TabStop = true;
            LinkLabel_Signup.Text = "Don't have an account? Sign up now!";
            LinkLabel_Signup.LinkClicked += LinkLabel_Signup_LinkClicked;
            // 
            // TextBox_Password
            // 
            TextBox_Password.BackColor = SystemColors.Window;
            TextBox_Password.Font = new Font("Poppins SemiBold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TextBox_Password.ForeColor = SystemColors.WindowText;
            TextBox_Password.Location = new Point(420, 331);
            TextBox_Password.Name = "TextBox_Password";
            TextBox_Password.Size = new Size(320, 39);
            TextBox_Password.TabIndex = 2;
            TextBox_Password.UseSystemPasswordChar = true;
            TextBox_Password.WordWrap = false;
            TextBox_Password.TextChanged += TextBox_Password_TextChanged;
            // 
            // TextBox_Email
            // 
            TextBox_Email.BackColor = SystemColors.Window;
            TextBox_Email.Font = new Font("Poppins", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            TextBox_Email.Location = new Point(420, 286);
            TextBox_Email.Name = "TextBox_Email";
            TextBox_Email.Size = new Size(320, 39);
            TextBox_Email.TabIndex = 1;
            TextBox_Email.TextChanged += TextBox_Email_TextChanged;
            // 
            // Button_Login
            // 
            Button_Login.BackColor = Color.Transparent;
            Button_Login.Enabled = false;
            Button_Login.FlatAppearance.BorderColor = Color.Black;
            Button_Login.FlatStyle = FlatStyle.Flat;
            Button_Login.Font = new Font("Poppins ExtraBold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Button_Login.Location = new Point(442, 446);
            Button_Login.Name = "Button_Login";
            Button_Login.Size = new Size(185, 50);
            Button_Login.TabIndex = 5;
            Button_Login.Text = "LOG IN!";
            Button_Login.UseVisualStyleBackColor = false;
            Button_Login.Click += Button_Login_Click;
            // 
            // Label_Email
            // 
            Label_Email.AutoSize = true;
            Label_Email.BackColor = Color.Transparent;
            Label_Email.Font = new Font("Poppins", 14.25F);
            Label_Email.Location = new Point(296, 286);
            Label_Email.Name = "Label_Email";
            Label_Email.Size = new Size(123, 34);
            Label_Email.TabIndex = 6;
            Label_Email.Text = "Username :";
            // 
            // Label_Password
            // 
            Label_Password.AutoSize = true;
            Label_Password.BackColor = Color.Transparent;
            Label_Password.Font = new Font("Poppins", 14.25F);
            Label_Password.Location = new Point(296, 333);
            Label_Password.Name = "Label_Password";
            Label_Password.Size = new Size(116, 34);
            Label_Password.TabIndex = 7;
            Label_Password.Text = "Password :";
            // 
            // LinkLabel_ChangePassword
            // 
            LinkLabel_ChangePassword.AutoSize = true;
            LinkLabel_ChangePassword.BackColor = Color.Transparent;
            LinkLabel_ChangePassword.Font = new Font("Poppins SemiBold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LinkLabel_ChangePassword.Location = new Point(420, 373);
            LinkLabel_ChangePassword.Name = "LinkLabel_ChangePassword";
            LinkLabel_ChangePassword.Size = new Size(233, 23);
            LinkLabel_ChangePassword.TabIndex = 3;
            LinkLabel_ChangePassword.TabStop = true;
            LinkLabel_ChangePassword.Text = "Forgot Password? Change it here!";
            LinkLabel_ChangePassword.LinkClicked += LinkLabel_ChangePassword_LinkClicked;
            // 
            // PictureBox_PasswordViewer
            // 
            PictureBox_PasswordViewer.BackColor = SystemColors.ButtonHighlight;
            PictureBox_PasswordViewer.Image = (Image)resources.GetObject("PictureBox_PasswordViewer.Image");
            PictureBox_PasswordViewer.Location = new Point(705, 338);
            PictureBox_PasswordViewer.Name = "PictureBox_PasswordViewer";
            PictureBox_PasswordViewer.Size = new Size(29, 24);
            PictureBox_PasswordViewer.SizeMode = PictureBoxSizeMode.Zoom;
            PictureBox_PasswordViewer.TabIndex = 9;
            PictureBox_PasswordViewer.TabStop = false;
            PictureBox_PasswordViewer.Click += pictureBox1_Click;
            // 
            // Label_Welcome
            // 
            Label_Welcome.AutoSize = true;
            Label_Welcome.BackColor = Color.Transparent;
            Label_Welcome.CausesValidation = false;
            Label_Welcome.FlatStyle = FlatStyle.Flat;
            Label_Welcome.Font = new Font("Poppins Black", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label_Welcome.ForeColor = SystemColors.ActiveCaptionText;
            Label_Welcome.Location = new Point(347, 207);
            Label_Welcome.Margin = new Padding(0);
            Label_Welcome.Name = "Label_Welcome";
            Label_Welcome.Padding = new Padding(3);
            Label_Welcome.Size = new Size(371, 62);
            Label_Welcome.TabIndex = 8;
            Label_Welcome.Text = "BORCELLE VET CLINIC";
            Label_Welcome.Click += Label_Welcome_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.Transparent;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(281, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(538, 281);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 11;
            pictureBox2.TabStop = false;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1064, 681);
            Controls.Add(PictureBox_PasswordViewer);
            Controls.Add(TextBox_Password);
            Controls.Add(Button_Login);
            Controls.Add(LinkLabel_ChangePassword);
            Controls.Add(LinkLabel_Signup);
            Controls.Add(Label_Password);
            Controls.Add(TextBox_Email);
            Controls.Add(Label_Email);
            Controls.Add(Label_Welcome);
            Controls.Add(pictureBox2);
            DoubleBuffered = true;
            Name = "Login";
            Text = " ";
            Load += Login_Load;
            ((System.ComponentModel.ISupportInitialize)PictureBox_PasswordViewer).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private LinkLabel LinkLabel_Signup;
        private TextBox TextBox_Password;
        private TextBox TextBox_Email;
        private Button Button_Login;
        private Label Label_Email;
        private Label Label_Password;
        private LinkLabel LinkLabel_ChangePassword;
        private PictureBox PictureBox_PasswordViewer;
        private Label Label_Welcome;
        private PictureBox pictureBox2;
    }
}
