﻿namespace Appointment1
{
    partial class staff_inventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(staff_inventory));
            Label_Shop = new Label();
            Label_Homepage = new Label();
            Label_ManageAccount = new Label();
            Label_History = new Label();
            Label_Appointment = new Label();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            Label_Add = new Label();
            Label_Delete = new Label();
            Label_Edit = new Label();
            Label_Checkout = new Label();
            panel2 = new Panel();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // Label_Shop
            // 
            Label_Shop.AutoSize = true;
            Label_Shop.BackColor = Color.Transparent;
            Label_Shop.Cursor = Cursors.Hand;
            Label_Shop.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Shop.ForeColor = Color.Black;
            Label_Shop.ImageAlign = ContentAlignment.MiddleRight;
            Label_Shop.Location = new Point(524, 61);
            Label_Shop.Name = "Label_Shop";
            Label_Shop.Padding = new Padding(10, 3, 10, 3);
            Label_Shop.Size = new Size(78, 31);
            Label_Shop.TabIndex = 122;
            Label_Shop.Text = "Shop";
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = Color.Transparent;
            Label_Homepage.Cursor = Cursors.Hand;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = Color.Black;
            Label_Homepage.Location = new Point(11, 61);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Padding = new Padding(10, 3, 10, 3);
            Label_Homepage.Size = new Size(130, 31);
            Label_Homepage.TabIndex = 121;
            Label_Homepage.Text = "Homepage";
            Label_Homepage.Click += Label_Homepage_Click;
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.BackColor = Color.Transparent;
            Label_ManageAccount.Cursor = Cursors.No;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.ForeColor = Color.Black;
            Label_ManageAccount.ImageAlign = ContentAlignment.MiddleRight;
            Label_ManageAccount.Location = new Point(627, 61);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Padding = new Padding(10, 3, 10, 3);
            Label_ManageAccount.Size = new Size(183, 31);
            Label_ManageAccount.TabIndex = 120;
            Label_ManageAccount.Text = "Manage Account";
            Label_ManageAccount.Click += Label_ManageAccount_Click;
            // 
            // Label_History
            // 
            Label_History.AutoSize = true;
            Label_History.BackColor = Color.Transparent;
            Label_History.Cursor = Cursors.Hand;
            Label_History.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_History.ForeColor = Color.Black;
            Label_History.ImageAlign = ContentAlignment.MiddleRight;
            Label_History.Location = new Point(328, 61);
            Label_History.Name = "Label_History";
            Label_History.Padding = new Padding(10, 3, 10, 3);
            Label_History.Size = new Size(171, 31);
            Label_History.TabIndex = 119;
            Label_History.Text = "Patient Records";
            Label_History.Click += Label_History_Click;
            // 
            // Label_Appointment
            // 
            Label_Appointment.AutoSize = true;
            Label_Appointment.BackColor = Color.Transparent;
            Label_Appointment.Cursor = Cursors.Hand;
            Label_Appointment.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Appointment.ForeColor = Color.Black;
            Label_Appointment.ImageAlign = ContentAlignment.MiddleRight;
            Label_Appointment.Location = new Point(166, 61);
            Label_Appointment.Name = "Label_Appointment";
            Label_Appointment.Padding = new Padding(10, 3, 10, 3);
            Label_Appointment.Size = new Size(137, 31);
            Label_Appointment.TabIndex = 118;
            Label_Appointment.Text = "Add Record";
            // 
            // panel1
            // 
            panel1.AutoScroll = true;
            panel1.BackColor = Color.Transparent;
            panel1.Location = new Point(12, 205);
            panel1.Name = "panel1";
            panel1.Size = new Size(873, 464);
            panel1.TabIndex = 123;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(906, 216);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(43, 40);
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox1.TabIndex = 124;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.Transparent;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(906, 286);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(43, 40);
            pictureBox5.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox5.TabIndex = 128;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.Transparent;
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(906, 353);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(43, 40);
            pictureBox6.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox6.TabIndex = 129;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.Transparent;
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(906, 424);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(43, 40);
            pictureBox7.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox7.TabIndex = 130;
            pictureBox7.TabStop = false;
            pictureBox7.Visible = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // Label_Add
            // 
            Label_Add.BackColor = Color.Transparent;
            Label_Add.Location = new Point(955, 222);
            Label_Add.Name = "Label_Add";
            Label_Add.Size = new Size(84, 28);
            Label_Add.TabIndex = 131;
            Label_Add.Text = "ADD";
            Label_Add.Click += Label_Add_Click;
            // 
            // Label_Delete
            // 
            Label_Delete.BackColor = Color.Transparent;
            Label_Delete.Location = new Point(956, 291);
            Label_Delete.Name = "Label_Delete";
            Label_Delete.Size = new Size(83, 29);
            Label_Delete.TabIndex = 132;
            Label_Delete.Text = "DELETE";
            Label_Delete.Click += Label_Delete_Click;
            // 
            // Label_Edit
            // 
            Label_Edit.BackColor = Color.Transparent;
            Label_Edit.Location = new Point(956, 357);
            Label_Edit.Name = "Label_Edit";
            Label_Edit.Size = new Size(83, 30);
            Label_Edit.TabIndex = 133;
            Label_Edit.Text = "EDIT";
            Label_Edit.Click += Label_Edit_Click;
            // 
            // Label_Checkout
            // 
            Label_Checkout.BackColor = Color.Transparent;
            Label_Checkout.Location = new Point(955, 419);
            Label_Checkout.Name = "Label_Checkout";
            Label_Checkout.Size = new Size(84, 79);
            Label_Checkout.TabIndex = 134;
            Label_Checkout.Text = "CHECK OUT";
            Label_Checkout.Visible = false;
            Label_Checkout.Click += Label_Checkout_Click;
            // 
            // panel2
            // 
            panel2.AutoScroll = true;
            panel2.BackColor = Color.Transparent;
            panel2.Location = new Point(12, 174);
            panel2.Name = "panel2";
            panel2.Size = new Size(873, 32);
            panel2.TabIndex = 135;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.Transparent;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(830, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(222, 80);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 136;
            pictureBox2.TabStop = false;
            // 
            // staff_inventory
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 681);
            Controls.Add(pictureBox2);
            Controls.Add(panel2);
            Controls.Add(pictureBox7);
            Controls.Add(Label_Checkout);
            Controls.Add(pictureBox6);
            Controls.Add(Label_Edit);
            Controls.Add(pictureBox5);
            Controls.Add(Label_Delete);
            Controls.Add(Label_Add);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_Shop);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_History);
            Controls.Add(Label_Appointment);
            Name = "staff_inventory";
            Text = "Form1";
            Load += staff_inventory_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label Label_Shop;
        private Label Label_Homepage;
        private Label Label_ManageAccount;
        private Label Label_History;
        private Label Label_Appointment;
        private Panel panel1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private Label Label_Add;
        private Label Label_Delete;
        private Label Label_Edit;
        private Label Label_Checkout;
        private Panel panel2;
        private PictureBox pictureBox2;
    }
}