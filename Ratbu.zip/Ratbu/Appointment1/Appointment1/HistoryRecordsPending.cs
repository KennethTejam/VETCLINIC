﻿using System.Data.SqlClient;
using System.Drawing.Text;

namespace Appointment1
{
    public partial class HistoryRecordsPending : Form
    {
        PROCESSES process = new PROCESSES();
        SqlConnection conn;
        int userid;
        string query;
        ContextMenuStrip contextMenu = new ContextMenuStrip();
        ContextMenuStrip recordMenu = new ContextMenuStrip();
        public HistoryRecordsPending(int userid)
        {
            string name = process.getUserEmail(userid);
            this.userid = userid;
            this.BackColor = Color.FromArgb(215, 175, 125);
            InitializeComponent();


            conn = process.getConnection();
            showContextMenu();


            cbSort.DropDownStyle = ComboBoxStyle.DropDownList;
            cbSort.Items.Add("Pet Name ↑");
            cbSort.Items.Add("Pet Name ↓");
            cbSort.SelectedIndex = 0;
            txtSearch.PlaceholderText = "Enter name";



            query = @"
                SELECT a.appid, a.pname AS PetName, a.oname AS OwnerName
                FROM Appointments a 
                WHERE 1=1

                ";
            LoadPendingAppointments(query); //default loading ishow lahat
            cbSort.SelectedIndexChanged += (sender, e) => LoadPendingAppointments(query); //isort default
            txtSearch.TextChanged += (sender, e) => LoadPendingAppointments(query);
            setFont();
        }
        public void setFont()
        {
           

            Label_ManageAccount.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_ManageAccount.ClientRectangle.X, Label_ManageAccount.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.Right - cornerRadius, Label_ManageAccount.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.Right - cornerRadius, Label_ManageAccount.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.X, Label_ManageAccount.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_ManageAccount.Region = new Region(path);
                }
                Label_ManageAccount.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_ManageAccount.Text, Label_ManageAccount.Font, Label_ManageAccount.ClientRectangle, Label_ManageAccount.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };



            Label_Appointment.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Appointment.ClientRectangle.X, Label_Appointment.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Appointment.ClientRectangle.Right - cornerRadius, Label_Appointment.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Appointment.ClientRectangle.Right - cornerRadius, Label_Appointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Appointment.ClientRectangle.X, Label_Appointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Appointment.Region = new Region(path);
                }
                Label_Appointment.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Appointment.Text, Label_Appointment.Font, Label_Appointment.ClientRectangle, Label_Appointment.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };


            Label_History.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_History.ClientRectangle.X, Label_History.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_History.ClientRectangle.Right - cornerRadius, Label_History.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_History.ClientRectangle.Right - cornerRadius, Label_History.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_History.ClientRectangle.X, Label_History.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_History.Region = new Region(path);
                }
                Label_History.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_History.Text, Label_History.Font, Label_History.ClientRectangle, Label_History.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };


            Label_Homepage.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Homepage.ClientRectangle.X, Label_Homepage.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Homepage.ClientRectangle.Right - cornerRadius, Label_Homepage.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Homepage.ClientRectangle.Right - cornerRadius, Label_Homepage.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Homepage.ClientRectangle.X, Label_Homepage.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Homepage.Region = new Region(path);
                }
                Label_Homepage.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Homepage.Text, Label_Homepage.Font, Label_Homepage.ClientRectangle, Label_Homepage.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };

            Label_Shop.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Shop.ClientRectangle.X, Label_Shop.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Shop.ClientRectangle.Right - cornerRadius, Label_Shop.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Shop.ClientRectangle.Right - cornerRadius, Label_Shop.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Shop.ClientRectangle.X, Label_Shop.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Shop.Region = new Region(path);
                }
                Label_Shop.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Shop.Text, Label_Shop.Font, Label_Shop.ClientRectangle, Label_Shop.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };

        }


        public void showContextMenu()
        {
            ToolStripMenuItem changepass = new ToolStripMenuItem("Manage Account");
            ToolStripMenuItem logoutItem = new ToolStripMenuItem("Logout");
            ToolStripMenuItem newrecord = new ToolStripMenuItem("New Patient");
            ToolStripMenuItem existingrecord = new ToolStripMenuItem("Existing Patient");
            contextMenu.Font = new Font("Arial", 15, FontStyle.Bold);
            recordMenu.Font = new Font("Arial", 15, FontStyle.Bold);
            contextMenu.Items.Add(changepass);
            contextMenu.Items.Add(logoutItem);
            recordMenu.Items.Add(newrecord);
            recordMenu.Items.Add(existingrecord);
            changepass.Click += (sender, e) =>
            {
                ManageAccount changepass = new ManageAccount(userid);
                changepass.Show();
                this.Hide();
            };
            logoutItem.Click += (sender, e) =>
            {
                userid = -1;
                Login login = new Login(userid);
                login.Show();
                this.Hide();
            };

            newrecord.Click += (sender, e) =>
            {
                AddRecord changepass = new AddRecord(userid);
                changepass.Show();
                this.Hide();
            };
            existingrecord.Click += (sender, e) =>
            {
                ExistingRecord changepass = new ExistingRecord(userid);
                changepass.Show();
                this.Hide();
            };

            Label_ManageAccount.ContextMenuStrip = contextMenu;
            Label_ManageAccount.MouseEnter += (sender, e) =>
            {
                contextMenu.Show(Label_ManageAccount, Label_ManageAccount.PointToClient(Cursor.Position));
            };

            Label_Appointment.ContextMenuStrip = recordMenu;
            Label_Appointment.MouseEnter += (sender, e) =>
            {
                recordMenu.Show(Label_Appointment, Label_Appointment.PointToClient(Cursor.Position));
            };
        }

        private void LoadPendingAppointments(string query)
        {
            string searchText = txtSearch.Text.Trim();

            // Add the WHERE clause condition first to ensure no OR logic break
            if (!string.IsNullOrEmpty(searchText))
            {
                query += " AND (a.pname LIKE @searchText OR a.oname LIKE @searchText)";
            }


            // Sorting logic for alphabetical order
            if (cbSort.SelectedItem != null)
            {
                if (cbSort.SelectedItem.ToString() == "Pet Name ↑")
                {
                    query += " ORDER BY a.pname ASC"; // Sort by PetName in ascending order
                }
                else if (cbSort.SelectedItem.ToString() == "Pet Name ↓")
                {
                    query += " ORDER BY a.pname DESC"; // Sort by PetName in descending order
                }
            }

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);

                // Add the parameter if there's a search query
                if (!string.IsNullOrEmpty(searchText))
                {
                    cmd.Parameters.AddWithValue("@searchText", "%" + searchText + "%");
                }

                SqlDataReader reader = cmd.ExecuteReader();
                pAppointment.Controls.Clear();

                int i = 0;
                while (reader.Read())
                {
                    Label lblAppointment = new Label
                    {
                        Text = $"Pet: {reader["PetName"]}\nOwner: {reader["OwnerName"]}",
                        AutoSize = false,
                        Size = new Size(425, 70),
                        TextAlign = ContentAlignment.MiddleCenter,
                        Margin = new Padding(15, 5, 15, 5),
                        Location = new Point(10, 10 + (i * 90))
                    };

                    int appID = Convert.ToInt32(reader["appid"]);
                    lblAppointment.Click += (sender, e) => OpenPatientInfoForm(appID);
                    lblAppointment.Paint += (s, e) =>
                    {
                        using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                        {
                            int cornerRadius = 45;
                            path.AddArc(lblAppointment.ClientRectangle.X, lblAppointment.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                            path.AddArc(lblAppointment.ClientRectangle.Right - cornerRadius, lblAppointment.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                            path.AddArc(lblAppointment.ClientRectangle.Right - cornerRadius, lblAppointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                            path.AddArc(lblAppointment.ClientRectangle.X, lblAppointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                            path.CloseFigure();
                            lblAppointment.Region = new Region(path);
                        }
                        lblAppointment.BackColor = Color.FromArgb(255, 245, 233);

                    };
                    pAppointment.Controls.Add(lblAppointment);
                    i++;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading appointments: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }



        private void OpenPatientInfoForm(int appID)
        {
            frmAppRecord patientInfoForm = new frmAppRecord(appID);
            patientInfoForm.Show();
        }






        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Rectangle rectangle2 = new Rectangle(0, 0, 1080, 115); // X, Y, Width, Height


            using (SolidBrush brush = new SolidBrush(Color.FromArgb(151, 97, 51))) // 128 = 50% opacity, Green color
            {

                e.Graphics.FillRectangle(brush, rectangle2);
            }
            using (Pen pen = new Pen(Color.Black, 2))
            {
                e.Graphics.DrawRectangle(pen, rectangle2);
            }

            // Define the dimensions of the rectangle




        }
        private void HistoryRecordsPending_Load(object sender, EventArgs e)
        {

        }

        private void Label_Appointment_Click(object sender, EventArgs e)
        {
            AddRecord addrecord = new AddRecord(userid);
            addrecord.Show();
            this.Hide();
        }

        private void Label_Homepage_Click(object sender, EventArgs e)
        {
            Homepage homepage = new Homepage(userid);
            homepage.Show();
            this.Hide();
        }

        private void Label_Shop_Click(object sender, EventArgs e)
        {
            staff_inventory staffinvent = new staff_inventory(userid);

            staffinvent.Show();
            this.Hide();
        }
    }
}