﻿namespace Appointment1
{
    partial class frmVetHP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVetHP));
            Label_History = new Label();
            Label_ManageAccount = new Label();
            Label_Homepage = new Label();
            Label_DailyDashboard = new Label();
            panel1 = new Panel();
            DayContainer = new FlowLayoutPanel();
            panel2 = new Panel();
            panel3 = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            panel4 = new Panel();
            panel7 = new Panel();
            panel8 = new Panel();
            panel9 = new Panel();
            panel11 = new Panel();
            panel10 = new Panel();
            panel12 = new Panel();
            panel40 = new Panel();
            panel41 = new Panel();
            panel38 = new Panel();
            panel39 = new Panel();
            panel22 = new Panel();
            panel23 = new Panel();
            panel37 = new Panel();
            panel24 = new Panel();
            panel25 = new Panel();
            panel36 = new Panel();
            panel26 = new Panel();
            panel34 = new Panel();
            panel35 = new Panel();
            panel33 = new Panel();
            panel28 = new Panel();
            panel29 = new Panel();
            panel32 = new Panel();
            panel30 = new Panel();
            panel31 = new Panel();
            panel13 = new Panel();
            panel21 = new Panel();
            panel20 = new Panel();
            panel18 = new Panel();
            panel19 = new Panel();
            panel17 = new Panel();
            panel16 = new Panel();
            panel14 = new Panel();
            panel15 = new Panel();
            panel42 = new Panel();
            panel43 = new Panel();
            panel51 = new Panel();
            panel50 = new Panel();
            panel48 = new Panel();
            panel49 = new Panel();
            panel47 = new Panel();
            panel46 = new Panel();
            panel44 = new Panel();
            panel45 = new Panel();
            panel52 = new Panel();
            panel53 = new Panel();
            panel60 = new Panel();
            panel61 = new Panel();
            panel59 = new Panel();
            panel58 = new Panel();
            panel56 = new Panel();
            panel57 = new Panel();
            panel55 = new Panel();
            panel54 = new Panel();
            panel62 = new Panel();
            panel63 = new Panel();
            panel71 = new Panel();
            panel70 = new Panel();
            panel68 = new Panel();
            panel69 = new Panel();
            panel67 = new Panel();
            panel66 = new Panel();
            panel64 = new Panel();
            panel65 = new Panel();
            panel72 = new Panel();
            panel73 = new Panel();
            panel80 = new Panel();
            panel81 = new Panel();
            panel79 = new Panel();
            panel78 = new Panel();
            panel76 = new Panel();
            panel77 = new Panel();
            panel75 = new Panel();
            panel74 = new Panel();
            Button_Previous = new Button();
            Button_Next = new Button();
            Label_Monday = new Label();
            Label_Tuesday = new Label();
            Label_Wednesday = new Label();
            Label_Thursday = new Label();
            Label_Friday = new Label();
            Label_Saturday = new Label();
            Label_Sunday = new Label();
            Label_MANDY = new Label();
            comboBox_Year = new ComboBox();
            comboBox_Month = new ComboBox();
            Label_Date = new Label();
            pictureBox5 = new PictureBox();
            DayContainer.SuspendLayout();
            panel2.SuspendLayout();
            panel5.SuspendLayout();
            panel8.SuspendLayout();
            panel12.SuspendLayout();
            panel40.SuspendLayout();
            panel38.SuspendLayout();
            panel22.SuspendLayout();
            panel24.SuspendLayout();
            panel34.SuspendLayout();
            panel28.SuspendLayout();
            panel18.SuspendLayout();
            panel14.SuspendLayout();
            panel42.SuspendLayout();
            panel48.SuspendLayout();
            panel44.SuspendLayout();
            panel52.SuspendLayout();
            panel60.SuspendLayout();
            panel56.SuspendLayout();
            panel62.SuspendLayout();
            panel68.SuspendLayout();
            panel64.SuspendLayout();
            panel72.SuspendLayout();
            panel80.SuspendLayout();
            panel76.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // Label_History
            // 
            Label_History.AutoSize = true;
            Label_History.BackColor = Color.Transparent;
            Label_History.Cursor = Cursors.Hand;
            Label_History.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_History.ForeColor = Color.Black;
            Label_History.ImageAlign = ContentAlignment.MiddleRight;
            Label_History.Location = new Point(248, 61);
            Label_History.Name = "Label_History";
            Label_History.Padding = new Padding(10, 3, 10, 3);
            Label_History.Size = new Size(171, 31);
            Label_History.TabIndex = 5;
            Label_History.Text = "Patient Records";
            Label_History.Click += Label_History_Click;
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.BackColor = Color.Transparent;
            Label_ManageAccount.Cursor = Cursors.No;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.ForeColor = Color.Black;
            Label_ManageAccount.ImageAlign = ContentAlignment.MiddleRight;
            Label_ManageAccount.Location = new Point(490, 61);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Padding = new Padding(10, 3, 10, 3);
            Label_ManageAccount.Size = new Size(183, 31);
            Label_ManageAccount.TabIndex = 6;
            Label_ManageAccount.Text = "Manage Account";
            Label_ManageAccount.Click += Label_ManageAccount_Click;
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = Color.Transparent;
            Label_Homepage.Cursor = Cursors.Hand;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = Color.Black;
            Label_Homepage.Location = new Point(48, 61);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Padding = new Padding(10, 3, 10, 3);
            Label_Homepage.Size = new Size(130, 31);
            Label_Homepage.TabIndex = 10;
            Label_Homepage.Text = "Homepage";
            Label_Homepage.Click += Label_Homepage_Click;
            // 
            // Label_DailyDashboard
            // 
            Label_DailyDashboard.AutoSize = true;
            Label_DailyDashboard.BackColor = Color.Transparent;
            Label_DailyDashboard.Font = new Font("Microsoft Sans Serif", 26.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Label_DailyDashboard.Location = new Point(35, 169);
            Label_DailyDashboard.Name = "Label_DailyDashboard";
            Label_DailyDashboard.Size = new Size(288, 39);
            Label_DailyDashboard.TabIndex = 23;
            Label_DailyDashboard.Text = "Daily Dashboard";
            // 
            // panel1
            // 
            panel1.AutoScroll = true;
            panel1.BackColor = Color.Transparent;
            panel1.BackgroundImageLayout = ImageLayout.None;
            panel1.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold);
            panel1.Location = new Point(35, 250);
            panel1.Name = "panel1";
            panel1.Size = new Size(465, 371);
            panel1.TabIndex = 26;
            // 
            // DayContainer
            // 
            DayContainer.Controls.Add(panel2);
            DayContainer.Controls.Add(panel5);
            DayContainer.Controls.Add(panel4);
            DayContainer.Controls.Add(panel7);
            DayContainer.Controls.Add(panel8);
            DayContainer.Controls.Add(panel11);
            DayContainer.Controls.Add(panel10);
            DayContainer.Controls.Add(panel12);
            DayContainer.Controls.Add(panel21);
            DayContainer.Controls.Add(panel20);
            DayContainer.Controls.Add(panel18);
            DayContainer.Controls.Add(panel17);
            DayContainer.Controls.Add(panel16);
            DayContainer.Controls.Add(panel14);
            DayContainer.Controls.Add(panel42);
            DayContainer.Controls.Add(panel51);
            DayContainer.Controls.Add(panel50);
            DayContainer.Controls.Add(panel48);
            DayContainer.Controls.Add(panel47);
            DayContainer.Controls.Add(panel46);
            DayContainer.Controls.Add(panel44);
            DayContainer.Controls.Add(panel52);
            DayContainer.Controls.Add(panel60);
            DayContainer.Controls.Add(panel59);
            DayContainer.Controls.Add(panel58);
            DayContainer.Controls.Add(panel56);
            DayContainer.Controls.Add(panel55);
            DayContainer.Controls.Add(panel54);
            DayContainer.Controls.Add(panel62);
            DayContainer.Controls.Add(panel71);
            DayContainer.Controls.Add(panel70);
            DayContainer.Controls.Add(panel68);
            DayContainer.Controls.Add(panel67);
            DayContainer.Controls.Add(panel66);
            DayContainer.Controls.Add(panel64);
            DayContainer.Controls.Add(panel72);
            DayContainer.Controls.Add(panel80);
            DayContainer.Controls.Add(panel79);
            DayContainer.Controls.Add(panel78);
            DayContainer.Controls.Add(panel76);
            DayContainer.Controls.Add(panel75);
            DayContainer.Controls.Add(panel74);
            DayContainer.Cursor = Cursors.Hand;
            DayContainer.Location = new Point(533, 246);
            DayContainer.Name = "DayContainer";
            DayContainer.Size = new Size(505, 375);
            DayContainer.TabIndex = 28;
            // 
            // panel2
            // 
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(panel3);
            panel2.Location = new Point(3, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(66, 55);
            panel2.TabIndex = 0;
            // 
            // panel3
            // 
            panel3.Location = new Point(63, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(57, 55);
            panel3.TabIndex = 1;
            // 
            // panel5
            // 
            panel5.BorderStyle = BorderStyle.FixedSingle;
            panel5.Controls.Add(panel6);
            panel5.Location = new Point(75, 3);
            panel5.Name = "panel5";
            panel5.Size = new Size(66, 55);
            panel5.TabIndex = 2;
            // 
            // panel6
            // 
            panel6.Location = new Point(63, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(57, 55);
            panel6.TabIndex = 1;
            // 
            // panel4
            // 
            panel4.BorderStyle = BorderStyle.FixedSingle;
            panel4.Location = new Point(147, 3);
            panel4.Name = "panel4";
            panel4.Size = new Size(66, 55);
            panel4.TabIndex = 1;
            // 
            // panel7
            // 
            panel7.BorderStyle = BorderStyle.FixedSingle;
            panel7.Location = new Point(219, 3);
            panel7.Name = "panel7";
            panel7.Size = new Size(66, 55);
            panel7.TabIndex = 3;
            // 
            // panel8
            // 
            panel8.BorderStyle = BorderStyle.FixedSingle;
            panel8.Controls.Add(panel9);
            panel8.Location = new Point(291, 3);
            panel8.Name = "panel8";
            panel8.Size = new Size(66, 55);
            panel8.TabIndex = 5;
            // 
            // panel9
            // 
            panel9.Location = new Point(63, 0);
            panel9.Name = "panel9";
            panel9.Size = new Size(57, 55);
            panel9.TabIndex = 1;
            // 
            // panel11
            // 
            panel11.BorderStyle = BorderStyle.FixedSingle;
            panel11.Location = new Point(363, 3);
            panel11.Name = "panel11";
            panel11.Size = new Size(66, 55);
            panel11.TabIndex = 6;
            // 
            // panel10
            // 
            panel10.BorderStyle = BorderStyle.FixedSingle;
            panel10.Location = new Point(435, 3);
            panel10.Name = "panel10";
            panel10.Size = new Size(66, 55);
            panel10.TabIndex = 4;
            // 
            // panel12
            // 
            panel12.BorderStyle = BorderStyle.FixedSingle;
            panel12.Controls.Add(panel40);
            panel12.Controls.Add(panel38);
            panel12.Controls.Add(panel22);
            panel12.Controls.Add(panel37);
            panel12.Controls.Add(panel24);
            panel12.Controls.Add(panel36);
            panel12.Controls.Add(panel26);
            panel12.Controls.Add(panel34);
            panel12.Controls.Add(panel33);
            panel12.Controls.Add(panel28);
            panel12.Controls.Add(panel32);
            panel12.Controls.Add(panel30);
            panel12.Controls.Add(panel31);
            panel12.Controls.Add(panel13);
            panel12.Location = new Point(3, 64);
            panel12.Name = "panel12";
            panel12.Size = new Size(66, 55);
            panel12.TabIndex = 7;
            // 
            // panel40
            // 
            panel40.Controls.Add(panel41);
            panel40.Location = new Point(0, 61);
            panel40.Name = "panel40";
            panel40.Size = new Size(57, 55);
            panel40.TabIndex = 7;
            // 
            // panel41
            // 
            panel41.Location = new Point(63, 0);
            panel41.Name = "panel41";
            panel41.Size = new Size(57, 55);
            panel41.TabIndex = 1;
            // 
            // panel38
            // 
            panel38.Controls.Add(panel39);
            panel38.Location = new Point(63, 61);
            panel38.Name = "panel38";
            panel38.Size = new Size(57, 55);
            panel38.TabIndex = 9;
            // 
            // panel39
            // 
            panel39.Location = new Point(63, 0);
            panel39.Name = "panel39";
            panel39.Size = new Size(57, 55);
            panel39.TabIndex = 1;
            // 
            // panel22
            // 
            panel22.Controls.Add(panel23);
            panel22.Location = new Point(-189, 0);
            panel22.Name = "panel22";
            panel22.Size = new Size(57, 55);
            panel22.TabIndex = 7;
            // 
            // panel23
            // 
            panel23.Location = new Point(63, 0);
            panel23.Name = "panel23";
            panel23.Size = new Size(57, 55);
            panel23.TabIndex = 1;
            // 
            // panel37
            // 
            panel37.Location = new Point(126, 61);
            panel37.Name = "panel37";
            panel37.Size = new Size(57, 55);
            panel37.TabIndex = 8;
            // 
            // panel24
            // 
            panel24.Controls.Add(panel25);
            panel24.Location = new Point(-126, 0);
            panel24.Name = "panel24";
            panel24.Size = new Size(57, 55);
            panel24.TabIndex = 9;
            // 
            // panel25
            // 
            panel25.Location = new Point(63, 0);
            panel25.Name = "panel25";
            panel25.Size = new Size(57, 55);
            panel25.TabIndex = 1;
            // 
            // panel36
            // 
            panel36.Location = new Point(189, 61);
            panel36.Name = "panel36";
            panel36.Size = new Size(57, 55);
            panel36.TabIndex = 10;
            // 
            // panel26
            // 
            panel26.Location = new Point(-63, 0);
            panel26.Name = "panel26";
            panel26.Size = new Size(57, 55);
            panel26.TabIndex = 8;
            // 
            // panel34
            // 
            panel34.Controls.Add(panel35);
            panel34.Location = new Point(252, 61);
            panel34.Name = "panel34";
            panel34.Size = new Size(57, 55);
            panel34.TabIndex = 12;
            // 
            // panel35
            // 
            panel35.Location = new Point(63, 0);
            panel35.Name = "panel35";
            panel35.Size = new Size(57, 55);
            panel35.TabIndex = 1;
            // 
            // panel33
            // 
            panel33.Location = new Point(315, 61);
            panel33.Name = "panel33";
            panel33.Size = new Size(57, 55);
            panel33.TabIndex = 13;
            // 
            // panel28
            // 
            panel28.Controls.Add(panel29);
            panel28.Location = new Point(63, 0);
            panel28.Name = "panel28";
            panel28.Size = new Size(57, 55);
            panel28.TabIndex = 12;
            // 
            // panel29
            // 
            panel29.Location = new Point(63, 0);
            panel29.Name = "panel29";
            panel29.Size = new Size(57, 55);
            panel29.TabIndex = 1;
            // 
            // panel32
            // 
            panel32.Location = new Point(378, 61);
            panel32.Name = "panel32";
            panel32.Size = new Size(57, 55);
            panel32.TabIndex = 11;
            // 
            // panel30
            // 
            panel30.Location = new Point(126, 0);
            panel30.Name = "panel30";
            panel30.Size = new Size(57, 55);
            panel30.TabIndex = 13;
            // 
            // panel31
            // 
            panel31.Location = new Point(189, 0);
            panel31.Name = "panel31";
            panel31.Size = new Size(57, 55);
            panel31.TabIndex = 11;
            // 
            // panel13
            // 
            panel13.Location = new Point(63, 0);
            panel13.Name = "panel13";
            panel13.Size = new Size(57, 55);
            panel13.TabIndex = 1;
            // 
            // panel21
            // 
            panel21.BorderStyle = BorderStyle.FixedSingle;
            panel21.Location = new Point(75, 64);
            panel21.Name = "panel21";
            panel21.Size = new Size(66, 55);
            panel21.TabIndex = 11;
            // 
            // panel20
            // 
            panel20.BorderStyle = BorderStyle.FixedSingle;
            panel20.Location = new Point(147, 64);
            panel20.Name = "panel20";
            panel20.Size = new Size(66, 55);
            panel20.TabIndex = 13;
            // 
            // panel18
            // 
            panel18.BorderStyle = BorderStyle.FixedSingle;
            panel18.Controls.Add(panel19);
            panel18.Location = new Point(219, 64);
            panel18.Name = "panel18";
            panel18.Size = new Size(66, 55);
            panel18.TabIndex = 12;
            // 
            // panel19
            // 
            panel19.Location = new Point(63, 0);
            panel19.Name = "panel19";
            panel19.Size = new Size(57, 55);
            panel19.TabIndex = 1;
            // 
            // panel17
            // 
            panel17.BorderStyle = BorderStyle.FixedSingle;
            panel17.Location = new Point(291, 64);
            panel17.Name = "panel17";
            panel17.Size = new Size(66, 55);
            panel17.TabIndex = 10;
            // 
            // panel16
            // 
            panel16.BorderStyle = BorderStyle.FixedSingle;
            panel16.Location = new Point(363, 64);
            panel16.Name = "panel16";
            panel16.Size = new Size(66, 55);
            panel16.TabIndex = 8;
            // 
            // panel14
            // 
            panel14.BorderStyle = BorderStyle.FixedSingle;
            panel14.Controls.Add(panel15);
            panel14.Location = new Point(435, 64);
            panel14.Name = "panel14";
            panel14.Size = new Size(66, 55);
            panel14.TabIndex = 9;
            // 
            // panel15
            // 
            panel15.Location = new Point(63, 0);
            panel15.Name = "panel15";
            panel15.Size = new Size(57, 55);
            panel15.TabIndex = 1;
            // 
            // panel42
            // 
            panel42.BorderStyle = BorderStyle.FixedSingle;
            panel42.Controls.Add(panel43);
            panel42.Location = new Point(3, 125);
            panel42.Name = "panel42";
            panel42.Size = new Size(66, 55);
            panel42.TabIndex = 7;
            // 
            // panel43
            // 
            panel43.Location = new Point(63, 0);
            panel43.Name = "panel43";
            panel43.Size = new Size(57, 55);
            panel43.TabIndex = 1;
            // 
            // panel51
            // 
            panel51.BorderStyle = BorderStyle.FixedSingle;
            panel51.Location = new Point(75, 125);
            panel51.Name = "panel51";
            panel51.Size = new Size(66, 55);
            panel51.TabIndex = 11;
            // 
            // panel50
            // 
            panel50.BorderStyle = BorderStyle.FixedSingle;
            panel50.Location = new Point(147, 125);
            panel50.Name = "panel50";
            panel50.Size = new Size(66, 55);
            panel50.TabIndex = 13;
            // 
            // panel48
            // 
            panel48.BorderStyle = BorderStyle.FixedSingle;
            panel48.Controls.Add(panel49);
            panel48.Location = new Point(219, 125);
            panel48.Name = "panel48";
            panel48.Size = new Size(66, 55);
            panel48.TabIndex = 12;
            // 
            // panel49
            // 
            panel49.Location = new Point(63, 0);
            panel49.Name = "panel49";
            panel49.Size = new Size(57, 55);
            panel49.TabIndex = 1;
            // 
            // panel47
            // 
            panel47.BorderStyle = BorderStyle.FixedSingle;
            panel47.Location = new Point(291, 125);
            panel47.Name = "panel47";
            panel47.Size = new Size(66, 55);
            panel47.TabIndex = 10;
            // 
            // panel46
            // 
            panel46.BorderStyle = BorderStyle.FixedSingle;
            panel46.Location = new Point(363, 125);
            panel46.Name = "panel46";
            panel46.Size = new Size(66, 55);
            panel46.TabIndex = 8;
            // 
            // panel44
            // 
            panel44.BorderStyle = BorderStyle.FixedSingle;
            panel44.Controls.Add(panel45);
            panel44.Location = new Point(435, 125);
            panel44.Name = "panel44";
            panel44.Size = new Size(66, 55);
            panel44.TabIndex = 9;
            // 
            // panel45
            // 
            panel45.Location = new Point(63, 0);
            panel45.Name = "panel45";
            panel45.Size = new Size(57, 55);
            panel45.TabIndex = 1;
            // 
            // panel52
            // 
            panel52.BorderStyle = BorderStyle.FixedSingle;
            panel52.Controls.Add(panel53);
            panel52.Location = new Point(3, 186);
            panel52.Name = "panel52";
            panel52.Size = new Size(66, 55);
            panel52.TabIndex = 14;
            // 
            // panel53
            // 
            panel53.Location = new Point(63, 0);
            panel53.Name = "panel53";
            panel53.Size = new Size(57, 55);
            panel53.TabIndex = 1;
            // 
            // panel60
            // 
            panel60.BorderStyle = BorderStyle.FixedSingle;
            panel60.Controls.Add(panel61);
            panel60.Location = new Point(75, 186);
            panel60.Name = "panel60";
            panel60.Size = new Size(66, 55);
            panel60.TabIndex = 16;
            // 
            // panel61
            // 
            panel61.Location = new Point(63, 0);
            panel61.Name = "panel61";
            panel61.Size = new Size(57, 55);
            panel61.TabIndex = 1;
            // 
            // panel59
            // 
            panel59.BorderStyle = BorderStyle.FixedSingle;
            panel59.Location = new Point(147, 186);
            panel59.Name = "panel59";
            panel59.Size = new Size(66, 55);
            panel59.TabIndex = 15;
            // 
            // panel58
            // 
            panel58.BorderStyle = BorderStyle.FixedSingle;
            panel58.Location = new Point(219, 186);
            panel58.Name = "panel58";
            panel58.Size = new Size(66, 55);
            panel58.TabIndex = 17;
            // 
            // panel56
            // 
            panel56.BorderStyle = BorderStyle.FixedSingle;
            panel56.Controls.Add(panel57);
            panel56.Location = new Point(291, 186);
            panel56.Name = "panel56";
            panel56.Size = new Size(66, 55);
            panel56.TabIndex = 19;
            // 
            // panel57
            // 
            panel57.Location = new Point(63, 0);
            panel57.Name = "panel57";
            panel57.Size = new Size(57, 55);
            panel57.TabIndex = 1;
            // 
            // panel55
            // 
            panel55.BorderStyle = BorderStyle.FixedSingle;
            panel55.Location = new Point(363, 186);
            panel55.Name = "panel55";
            panel55.Size = new Size(66, 55);
            panel55.TabIndex = 20;
            // 
            // panel54
            // 
            panel54.BorderStyle = BorderStyle.FixedSingle;
            panel54.Location = new Point(435, 186);
            panel54.Name = "panel54";
            panel54.Size = new Size(66, 55);
            panel54.TabIndex = 18;
            // 
            // panel62
            // 
            panel62.BorderStyle = BorderStyle.FixedSingle;
            panel62.Controls.Add(panel63);
            panel62.Location = new Point(3, 247);
            panel62.Name = "panel62";
            panel62.Size = new Size(66, 55);
            panel62.TabIndex = 21;
            // 
            // panel63
            // 
            panel63.Location = new Point(63, 0);
            panel63.Name = "panel63";
            panel63.Size = new Size(57, 55);
            panel63.TabIndex = 1;
            // 
            // panel71
            // 
            panel71.BorderStyle = BorderStyle.FixedSingle;
            panel71.Location = new Point(75, 247);
            panel71.Name = "panel71";
            panel71.Size = new Size(66, 55);
            panel71.TabIndex = 25;
            // 
            // panel70
            // 
            panel70.BorderStyle = BorderStyle.FixedSingle;
            panel70.Location = new Point(147, 247);
            panel70.Name = "panel70";
            panel70.Size = new Size(66, 55);
            panel70.TabIndex = 27;
            // 
            // panel68
            // 
            panel68.BorderStyle = BorderStyle.FixedSingle;
            panel68.Controls.Add(panel69);
            panel68.Location = new Point(219, 247);
            panel68.Name = "panel68";
            panel68.Size = new Size(66, 55);
            panel68.TabIndex = 26;
            // 
            // panel69
            // 
            panel69.Location = new Point(63, 0);
            panel69.Name = "panel69";
            panel69.Size = new Size(57, 55);
            panel69.TabIndex = 1;
            // 
            // panel67
            // 
            panel67.BorderStyle = BorderStyle.FixedSingle;
            panel67.Location = new Point(291, 247);
            panel67.Name = "panel67";
            panel67.Size = new Size(66, 55);
            panel67.TabIndex = 24;
            // 
            // panel66
            // 
            panel66.BorderStyle = BorderStyle.FixedSingle;
            panel66.Location = new Point(363, 247);
            panel66.Name = "panel66";
            panel66.Size = new Size(66, 55);
            panel66.TabIndex = 22;
            // 
            // panel64
            // 
            panel64.BorderStyle = BorderStyle.FixedSingle;
            panel64.Controls.Add(panel65);
            panel64.Location = new Point(435, 247);
            panel64.Name = "panel64";
            panel64.Size = new Size(66, 55);
            panel64.TabIndex = 23;
            // 
            // panel65
            // 
            panel65.Location = new Point(63, 0);
            panel65.Name = "panel65";
            panel65.Size = new Size(57, 55);
            panel65.TabIndex = 1;
            // 
            // panel72
            // 
            panel72.BorderStyle = BorderStyle.FixedSingle;
            panel72.Controls.Add(panel73);
            panel72.Location = new Point(3, 308);
            panel72.Name = "panel72";
            panel72.Size = new Size(66, 55);
            panel72.TabIndex = 28;
            // 
            // panel73
            // 
            panel73.Location = new Point(63, 0);
            panel73.Name = "panel73";
            panel73.Size = new Size(57, 55);
            panel73.TabIndex = 1;
            // 
            // panel80
            // 
            panel80.BorderStyle = BorderStyle.FixedSingle;
            panel80.Controls.Add(panel81);
            panel80.Location = new Point(75, 308);
            panel80.Name = "panel80";
            panel80.Size = new Size(66, 55);
            panel80.TabIndex = 30;
            // 
            // panel81
            // 
            panel81.Location = new Point(63, 0);
            panel81.Name = "panel81";
            panel81.Size = new Size(57, 55);
            panel81.TabIndex = 1;
            // 
            // panel79
            // 
            panel79.BorderStyle = BorderStyle.FixedSingle;
            panel79.Location = new Point(147, 308);
            panel79.Name = "panel79";
            panel79.Size = new Size(66, 55);
            panel79.TabIndex = 29;
            // 
            // panel78
            // 
            panel78.BorderStyle = BorderStyle.FixedSingle;
            panel78.Location = new Point(219, 308);
            panel78.Name = "panel78";
            panel78.Size = new Size(66, 55);
            panel78.TabIndex = 31;
            // 
            // panel76
            // 
            panel76.BorderStyle = BorderStyle.FixedSingle;
            panel76.Controls.Add(panel77);
            panel76.Location = new Point(291, 308);
            panel76.Name = "panel76";
            panel76.Size = new Size(66, 55);
            panel76.TabIndex = 33;
            // 
            // panel77
            // 
            panel77.Location = new Point(63, 0);
            panel77.Name = "panel77";
            panel77.Size = new Size(57, 55);
            panel77.TabIndex = 1;
            // 
            // panel75
            // 
            panel75.BorderStyle = BorderStyle.FixedSingle;
            panel75.Location = new Point(363, 308);
            panel75.Name = "panel75";
            panel75.Size = new Size(66, 55);
            panel75.TabIndex = 34;
            // 
            // panel74
            // 
            panel74.BorderStyle = BorderStyle.FixedSingle;
            panel74.Location = new Point(435, 308);
            panel74.Name = "panel74";
            panel74.Size = new Size(66, 55);
            panel74.TabIndex = 32;
            // 
            // Button_Previous
            // 
            Button_Previous.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Bold);
            Button_Previous.Location = new Point(533, 627);
            Button_Previous.Name = "Button_Previous";
            Button_Previous.Size = new Size(106, 32);
            Button_Previous.TabIndex = 28;
            Button_Previous.Text = "Previous";
            Button_Previous.UseVisualStyleBackColor = true;
            Button_Previous.Click += button1_Click;
            // 
            // Button_Next
            // 
            Button_Next.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Bold);
            Button_Next.ImageAlign = ContentAlignment.BottomRight;
            Button_Next.Location = new Point(932, 627);
            Button_Next.Name = "Button_Next";
            Button_Next.Size = new Size(106, 32);
            Button_Next.TabIndex = 29;
            Button_Next.Text = "Next";
            Button_Next.UseVisualStyleBackColor = true;
            Button_Next.Click += Button_Next_Click;
            // 
            // Label_Monday
            // 
            Label_Monday.AutoSize = true;
            Label_Monday.BackColor = Color.Transparent;
            Label_Monday.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Label_Monday.Location = new Point(608, 218);
            Label_Monday.Name = "Label_Monday";
            Label_Monday.Size = new Size(57, 15);
            Label_Monday.TabIndex = 29;
            Label_Monday.Text = "Monday";
            // 
            // Label_Tuesday
            // 
            Label_Tuesday.AutoSize = true;
            Label_Tuesday.BackColor = Color.Transparent;
            Label_Tuesday.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Label_Tuesday.Location = new Point(680, 218);
            Label_Tuesday.Name = "Label_Tuesday";
            Label_Tuesday.Size = new Size(60, 15);
            Label_Tuesday.TabIndex = 30;
            Label_Tuesday.Text = "Tuesday";
            // 
            // Label_Wednesday
            // 
            Label_Wednesday.AutoSize = true;
            Label_Wednesday.BackColor = Color.Transparent;
            Label_Wednesday.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Label_Wednesday.Location = new Point(752, 218);
            Label_Wednesday.Name = "Label_Wednesday";
            Label_Wednesday.Size = new Size(61, 15);
            Label_Wednesday.TabIndex = 31;
            Label_Wednesday.Text = "Wed day";
            // 
            // Label_Thursday
            // 
            Label_Thursday.AutoSize = true;
            Label_Thursday.BackColor = Color.Transparent;
            Label_Thursday.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Label_Thursday.Location = new Point(824, 218);
            Label_Thursday.Name = "Label_Thursday";
            Label_Thursday.Size = new Size(65, 15);
            Label_Thursday.TabIndex = 32;
            Label_Thursday.Text = "Thursday";
            // 
            // Label_Friday
            // 
            Label_Friday.AutoSize = true;
            Label_Friday.BackColor = Color.Transparent;
            Label_Friday.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Label_Friday.Location = new Point(896, 218);
            Label_Friday.Name = "Label_Friday";
            Label_Friday.Size = new Size(46, 15);
            Label_Friday.TabIndex = 33;
            Label_Friday.Text = "Friday";
            // 
            // Label_Saturday
            // 
            Label_Saturday.AutoSize = true;
            Label_Saturday.BackColor = Color.Transparent;
            Label_Saturday.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Label_Saturday.Location = new Point(968, 218);
            Label_Saturday.Name = "Label_Saturday";
            Label_Saturday.Size = new Size(63, 15);
            Label_Saturday.TabIndex = 34;
            Label_Saturday.Text = "Saturday";
            // 
            // Label_Sunday
            // 
            Label_Sunday.AutoSize = true;
            Label_Sunday.BackColor = Color.Transparent;
            Label_Sunday.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Label_Sunday.Location = new Point(536, 218);
            Label_Sunday.Name = "Label_Sunday";
            Label_Sunday.Size = new Size(54, 15);
            Label_Sunday.TabIndex = 35;
            Label_Sunday.Text = "Sunday";
            // 
            // Label_MANDY
            // 
            Label_MANDY.AutoSize = true;
            Label_MANDY.BackColor = Color.Transparent;
            Label_MANDY.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold | FontStyle.Italic);
            Label_MANDY.Location = new Point(526, 169);
            Label_MANDY.Name = "Label_MANDY";
            Label_MANDY.Size = new Size(147, 24);
            Label_MANDY.TabIndex = 36;
            Label_MANDY.Text = "MONTH YEAR";
            // 
            // comboBox_Year
            // 
            comboBox_Year.BackColor = Color.White;
            comboBox_Year.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_Year.FlatStyle = FlatStyle.Flat;
            comboBox_Year.Font = new Font("Microsoft Sans Serif", 8F, FontStyle.Bold);
            comboBox_Year.FormattingEnabled = true;
            comboBox_Year.Items.AddRange(new object[] { "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029" });
            comboBox_Year.Location = new Point(823, 180);
            comboBox_Year.Name = "comboBox_Year";
            comboBox_Year.Size = new Size(113, 21);
            comboBox_Year.TabIndex = 37;
            comboBox_Year.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // comboBox_Month
            // 
            comboBox_Month.BackColor = SystemColors.InactiveBorder;
            comboBox_Month.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_Month.FlatStyle = FlatStyle.Flat;
            comboBox_Month.Font = new Font("Microsoft Sans Serif", 8F, FontStyle.Bold);
            comboBox_Month.FormattingEnabled = true;
            comboBox_Month.Items.AddRange(new object[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" });
            comboBox_Month.Location = new Point(951, 180);
            comboBox_Month.Name = "comboBox_Month";
            comboBox_Month.Size = new Size(83, 21);
            comboBox_Month.TabIndex = 38;
            comboBox_Month.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // Label_Date
            // 
            Label_Date.AutoSize = true;
            Label_Date.BackColor = Color.Transparent;
            Label_Date.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold | FontStyle.Italic);
            Label_Date.Location = new Point(343, 214);
            Label_Date.Name = "Label_Date";
            Label_Date.Size = new Size(125, 20);
            Label_Date.TabIndex = 40;
            Label_Date.Text = "MONTH YEAR";
            Label_Date.Click += Label_Date_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.Transparent;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(830, 12);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(222, 80);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 129;
            pictureBox5.TabStop = false;
            // 
            // frmVetHP
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 681);
            Controls.Add(pictureBox5);
            Controls.Add(Label_Date);
            Controls.Add(Label_Sunday);
            Controls.Add(Label_Saturday);
            Controls.Add(Label_Friday);
            Controls.Add(Label_Thursday);
            Controls.Add(Label_Wednesday);
            Controls.Add(Label_Tuesday);
            Controls.Add(Label_Monday);
            Controls.Add(comboBox_Month);
            Controls.Add(comboBox_Year);
            Controls.Add(Label_MANDY);
            Controls.Add(DayContainer);
            Controls.Add(panel1);
            Controls.Add(Label_DailyDashboard);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_History);
            Controls.Add(Button_Next);
            Controls.Add(Button_Previous);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "frmVetHP";
            Text = "Form1";
            Load += Homepage_Load;
            DayContainer.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel8.ResumeLayout(false);
            panel12.ResumeLayout(false);
            panel40.ResumeLayout(false);
            panel38.ResumeLayout(false);
            panel22.ResumeLayout(false);
            panel24.ResumeLayout(false);
            panel34.ResumeLayout(false);
            panel28.ResumeLayout(false);
            panel18.ResumeLayout(false);
            panel14.ResumeLayout(false);
            panel42.ResumeLayout(false);
            panel48.ResumeLayout(false);
            panel44.ResumeLayout(false);
            panel52.ResumeLayout(false);
            panel60.ResumeLayout(false);
            panel56.ResumeLayout(false);
            panel62.ResumeLayout(false);
            panel68.ResumeLayout(false);
            panel64.ResumeLayout(false);
            panel72.ResumeLayout(false);
            panel80.ResumeLayout(false);
            panel76.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label Label_History;
        private Label Label_ManageAccount;
        private Label Label_Homepage;
        private Label Label_DailyDashboard;
        private Panel panel1;
        private FlowLayoutPanel DayContainer;
        private Label Label_Monday;
        private Label Label_Tuesday;
        private Label Label_Wednesday;
        private Label Label_Thursday;
        private Label Label_Friday;
        private Label Label_Saturday;
        private Label Label_Sunday;
        private Panel panel2;
        private Panel panel3;
        private Panel panel8;
        private Panel panel9;
        private Panel panel11;
        private Panel panel10;
        private Panel panel12;
        private Panel panel40;
        private Panel panel41;
        private Panel panel38;
        private Panel panel39;
        private Panel panel22;
        private Panel panel23;
        private Panel panel37;
        private Panel panel24;
        private Panel panel25;
        private Panel panel36;
        private Panel panel26;
        private Panel panel34;
        private Panel panel35;
        private Panel panel27;
        private Panel panel33;
        private Panel panel28;
        private Panel panel29;
        private Panel panel32;
        private Panel panel30;
        private Panel panel31;
        private Panel panel13;
        private Panel panel21;
        private Panel panel20;
        private Panel panel18;
        private Panel panel19;
        private Panel panel17;
        private Panel panel16;
        private Panel panel14;
        private Panel panel15;
        private Panel panel42;
        private Panel panel43;
        private Panel panel51;
        private Panel panel50;
        private Panel panel48;
        private Panel panel49;
        private Panel panel47;
        private Panel panel46;
        private Panel panel44;
        private Panel panel45;
        private Panel panel52;
        private Panel panel53;
        private Panel panel60;
        private Panel panel61;
        private Panel panel59;
        private Panel panel58;
        private Panel panel56;
        private Panel panel57;
        private Panel panel55;
        private Panel panel54;
        private Panel panel62;
        private Panel panel63;
        private Panel panel71;
        private Panel panel70;
        private Panel panel68;
        private Panel panel69;
        private Panel panel67;
        private Panel panel66;
        private Panel panel64;
        private Panel panel65;
        private Button Button_Previous;
        private Button Button_Next;
        private Label Label_MANDY;
        private ComboBox comboBox_Year;
        private ComboBox comboBox_Month;
        private Panel panel5;
        private Panel panel6;
        private Panel panel4;
        private Panel panel7;
        private Panel panel72;
        private Panel panel73;
        private Panel panel80;
        private Panel panel81;
        private Panel panel79;
        private Panel panel78;
        private Panel panel76;
        private Panel panel77;
        private Panel panel75;
        private Panel panel74;
        private Label Label_Date;
        private PictureBox pictureBox5;
    }
}