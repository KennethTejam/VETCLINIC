﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using System.Linq;

using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;


namespace Appointment1
{
    public partial class frmVetHP : Form
    {
        public int userid;
        ContextMenuStrip contextMenu = new ContextMenuStrip();
        ContextMenuStrip recordMenu = new ContextMenuStrip();
        SqlConnection conn;
        PROCESSES process = new PROCESSES();
        int month, year;
        public frmVetHP(int userid)
        {

            this.BackColor = Color.FromArgb(215, 175, 125);
            InitializeComponent();
            this.userid = userid;
            Label_Homepage.BackColor = Color.LightSkyBlue;
            DayContainer.BackColor = Color.FromArgb(255, 245, 233);
            if (userid < 0)
            {
                Login login = new Login(userid);
                login.Show();
                this.Hide();
            }
            else
            {
                string useremail = process.getUserEmail(userid);

            }
            comboBox_Year.BackColor = Color.White;
            comboBox_Month.BackColor = Color.White;
            conn = process.getConnection();
            showContextMenu();
            setFont();
            DateTime now = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
            month = now.Month;
            year = now.Year;
            calendar();
            showAppList(now);
        }
        public void showContextMenu()
        {
            ToolStripMenuItem changepass = new ToolStripMenuItem("Manage Account");
            ToolStripMenuItem logoutItem = new ToolStripMenuItem("Logout");
            ToolStripMenuItem newrecord = new ToolStripMenuItem("New Patient");
            ToolStripMenuItem existingrecord = new ToolStripMenuItem("Existing Patient");
            contextMenu.Font = new Font("Arial", 15, FontStyle.Bold);
            recordMenu.Font = new Font("Arial", 15, FontStyle.Bold);
            contextMenu.Items.Add(changepass);
            contextMenu.Items.Add(logoutItem);
            recordMenu.Items.Add(newrecord);
            recordMenu.Items.Add(existingrecord);
            changepass.Click += (sender, e) =>
            {
                frmManageAccount changepass = new frmManageAccount(userid);
                changepass.Show();
                this.Hide();
            };
            logoutItem.Click += (sender, e) =>
            {
                userid = -1;
                Login login = new Login(userid);
                login.Show();
                this.Hide();
            };
            Label_ManageAccount.ContextMenuStrip = contextMenu;
            Label_ManageAccount.MouseEnter += (sender, e) =>
            {
                contextMenu.Show(Label_ManageAccount, Label_ManageAccount.PointToClient(Cursor.Position));
            };


        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void calendar()
        {
            DayContainer.Controls.Clear();
            string monthname = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);


            Label_MANDY.Text = (monthname + " " + year).ToString();
            DateTime startofmonth = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            int daysoftheweek = Convert.ToInt32(startofmonth.DayOfWeek.ToString("d")) + 1;
            for (int i = 1; i < daysoftheweek; i++)
            {
                UserControl_Calendar uccalendar = new UserControl_Calendar();
                DayContainer.Controls.Add(uccalendar);
            }
            for (int i = 1; i <= days; i++)
            {

                UserControldays ucdays = new UserControldays();

                ucdays.BackColor = Color.Empty;
                ucdays.days(i, month, year);
                DayContainer.Controls.Add(ucdays);
                ucdays.Click += (sender, e) =>
                {
                    int day = Convert.ToInt32(ucdays.Label_Day.Text);

                    DateTime clickeddate = new DateTime(year, month, day);
                    showAppList(clickeddate);
                };
                ucdays.Label_Day.Click += (sender, e) =>
                {
                    int day = Convert.ToInt32(ucdays.Label_Day.Text);
                    DateTime clickeddate = new DateTime(year, month, day);
                    showAppList(clickeddate);
                    calendar();



                };
            }




        }

        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        public void showAppList(DateTime clickeddate)
        {
            int month = clickeddate.Month;
            int year = clickeddate.Year;
            int day = clickeddate.Day;
            string monthname = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);



            int currentWidth = Label_Date.Width;

            Label_Date.Text = monthname + " " + day + ", " + year;


            int newWidth = Label_Date.PreferredWidth;

            Label_Date.Left -= (newWidth - currentWidth);


            string query = @"
            WITH RankedAppointments AS (
                    SELECT 
                        a.appid, 
                        a.pname, 
                        a.oname, 
                        FORMAT(s.date, 'dddd, MMMM dd, yyyy') AS date, 
                        s.status,
                        ROW_NUMBER() OVER (
                            PARTITION BY a.appid, s.date 
                            ORDER BY 
                                CASE 
                                    WHEN s.status = 'Pending' THEN 1 
                                    ELSE 2 
                                END
                        ) AS RowNum
                    FROM 
                        appointments a
                    INNER JOIN 
                        schedule s ON a.appid = s.appid
                    WHERE 
                        CAST(s.date AS DATE) = CAST(@dateandtime AS DATE)
                )
                SELECT 
                    appid, 
                    pname, 
                    oname, 
                    date, 
                    status
                FROM 
                    RankedAppointments
                WHERE 
                    RowNum = 1
                ORDER BY 
                    appid;
";
            LoadPendingAppointments(query, clickeddate);
        }

        public void setFont()
        {

            ///
            ///
            ///
            ///
            ///


            Button_Next.BackColor = Color.FromArgb(151, 97, 51);
            Button_Previous.BackColor = Color.FromArgb(151, 97, 51);
            Button_Next.ForeColor = Color.White;
            Button_Previous.ForeColor = Color.White;
            Label_ManageAccount.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_ManageAccount.ClientRectangle.X, Label_ManageAccount.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.Right - cornerRadius, Label_ManageAccount.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.Right - cornerRadius, Label_ManageAccount.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_ManageAccount.ClientRectangle.X, Label_ManageAccount.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_ManageAccount.Region = new Region(path);
                }
                Label_ManageAccount.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_ManageAccount.Text, Label_ManageAccount.Font, Label_ManageAccount.ClientRectangle, Label_ManageAccount.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };


            Label_History.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_History.ClientRectangle.X, Label_History.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_History.ClientRectangle.Right - cornerRadius, Label_History.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_History.ClientRectangle.Right - cornerRadius, Label_History.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_History.ClientRectangle.X, Label_History.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_History.Region = new Region(path);
                }
                Label_History.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_History.Text, Label_History.Font, Label_History.ClientRectangle, Label_History.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };


            Label_Homepage.Paint += (s, e) =>
            {
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int cornerRadius = 20;
                    path.AddArc(Label_Homepage.ClientRectangle.X, Label_Homepage.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                    path.AddArc(Label_Homepage.ClientRectangle.Right - cornerRadius, Label_Homepage.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                    path.AddArc(Label_Homepage.ClientRectangle.Right - cornerRadius, Label_Homepage.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                    path.AddArc(Label_Homepage.ClientRectangle.X, Label_Homepage.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                    path.CloseFigure();
                    Label_Homepage.Region = new Region(path);
                }
                Label_Homepage.BackColor = Color.FromArgb(233, 200, 168);
                TextRenderer.DrawText(e.Graphics, Label_Homepage.Text, Label_Homepage.Font, Label_Homepage.ClientRectangle, Label_Homepage.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };

        }///
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void LoadPendingAppointments(string query, DateTime clickeddate)
        {
            panel1.Controls.Clear();
            try
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@dateandtime", clickeddate);



                    SqlDataReader reader = cmd.ExecuteReader();

                    int i = 0;
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Label lblAppointment = new Label();

                            string date = reader["date"].ToString();
                            lblAppointment.Text = $"Pet: {reader["pname"]}  Owner: {reader["oname"]}\nDate: {reader["date"]}";
                            lblAppointment.AutoSize = false;
                            lblAppointment.Size = new Size(425, 70);
                            lblAppointment.TextAlign = ContentAlignment.MiddleCenter;
                            lblAppointment.Location = new Point(10, 10 + (i * 80));
                            lblAppointment.Font = new Font("Poppins SemiBold", 12, FontStyle.Bold);
                            int appID = Convert.ToInt32(reader["appID"]);
                            lblAppointment.Click += (sender, e) => OpenPatientInfoForm(appID, date);
                            lblAppointment.Paint += (s, e) =>
                            {
                                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                                {
                                    int cornerRadius = 45;
                                    path.AddArc(lblAppointment.ClientRectangle.X, lblAppointment.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                                    path.AddArc(lblAppointment.ClientRectangle.Right - cornerRadius, lblAppointment.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                                    path.AddArc(lblAppointment.ClientRectangle.Right - cornerRadius, lblAppointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                                    path.AddArc(lblAppointment.ClientRectangle.X, lblAppointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                                    path.CloseFigure();
                                    lblAppointment.Region = new Region(path);
                                }
                                lblAppointment.BackColor = Color.FromArgb(255, 245, 233);

                            };
                            panel1.Controls.Add(lblAppointment);
                            i++;
                        }
                    }
                    else
                    {
                        Label lblAppointment = new Label();
                        lblAppointment.Text = "There Are No Appointments For This Day!";
                        lblAppointment.AutoSize = false;
                        lblAppointment.Size = new Size(425, 200);
                        lblAppointment.TextAlign = ContentAlignment.MiddleCenter;
                        lblAppointment.Font = new Font("Poppins SemiBold", 12, FontStyle.Bold);
                        lblAppointment.Paint += (s, e) =>
                        {
                            using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                            {
                                int cornerRadius = 45;
                                path.AddArc(lblAppointment.ClientRectangle.X, lblAppointment.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                                path.AddArc(lblAppointment.ClientRectangle.Right - cornerRadius, lblAppointment.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                                path.AddArc(lblAppointment.ClientRectangle.Right - cornerRadius, lblAppointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                                path.AddArc(lblAppointment.ClientRectangle.X, lblAppointment.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                                path.CloseFigure();
                                lblAppointment.Region = new Region(path);
                            }
                            lblAppointment.BackColor = Color.FromArgb(255, 245, 233);

                        };
                        panel1.Controls.Add(lblAppointment);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading appointments: " + ex.Message);
            }
            finally { conn.Close(); }
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void OpenPatientInfoForm(int appID, string date)
        {
            frmAppointments patientInfoForm = new frmAppointments(appID, date);
            patientInfoForm.Show();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        private void Label_History_Click(object sender, EventArgs e)
        {
            int userid = this.userid;
            HistoryRecordsDone history = new HistoryRecordsDone(userid);
            history.Show();
            this.Hide();
        }
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        /////////////
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Rectangle rectangle = new Rectangle(0, 0, 1080, 160); // X, Y, Width, Height

            // Create a semi-transparent brush
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(151, 97, 51))) // 128 = 50% opacity, Green color
            {
                // Draw the rectangle in the specified position
                e.Graphics.FillRectangle(brush, rectangle);
            }
            using (Pen pen = new Pen(Color.Black, 2)) // Black border with 3px thickness
            {
                e.Graphics.DrawRectangle(pen, rectangle);
            }
        }

        private void Homepage_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (month == 1) { year--; month = 12; calendar(); }
            else
            {
                DayContainer.Controls.Clear();
                month--;
                calendar();
            }

        }

        private void Button_Next_Click(object sender, EventArgs e)
        {
            if (month == 12) { year++; month = 1; calendar(); }
            else
            {
                DayContainer.Controls.Clear();
                month++;
                calendar();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(comboBox_Year.Text))
            {
                return;
            }

            if (!int.TryParse(comboBox_Year.Text, out year))
            {
                return;
            }
            string cmonth = comboBox_Month.Text;
            month = getmonth(cmonth);
            calendar();
        }
        private int getmonth(string cmonth)
        {
            if (cmonth == "December")
            { return 12; }
            else if (cmonth == "November")
            { return 11; }
            else if (cmonth == "October")
            { return 10; }
            else if (cmonth == "September")
            { return 9; }
            else if (cmonth == "August")
            { return 8; }
            else if (cmonth == "July")
            { return 7; }
            else if (cmonth == "June")
            { return 6; }
            else if (cmonth == "May")
            { return 5; }
            else if (cmonth == "April")
            { return 4; }
            else if (cmonth == "March")
            { return 3; }
            else if (cmonth == "February")
            { return 2; }
            else { return 1; }

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            year = Convert.ToInt32(comboBox_Year.Text);
            string cmonth = comboBox_Month.Text;
            month = getmonth(cmonth);
            calendar();
        }

        private void Label_Shop_Click(object sender, EventArgs e)
        {
            staff_inventory staffinvent = new staff_inventory(userid);

            staffinvent.Show();
            this.Hide();
        }

        private void Label_Homepage_Click(object sender, EventArgs e)
        {

        }

        private void Label_ManageAccount_Click(object sender, EventArgs e)
        {
            frmManageAccount frmmngacct = new frmManageAccount(userid);
            frmmngacct.Show();
            this.Hide();
        }

        private void Label_Date_Click(object sender, EventArgs e)
        {

        }
    }
}
