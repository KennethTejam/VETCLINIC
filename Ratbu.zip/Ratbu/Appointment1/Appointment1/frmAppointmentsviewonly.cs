﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appointment1
{
    public partial class frmAppointmentsviewonly : Form
    {
        private int appID;
        int userid;
        PROCESSES process = new PROCESSES();
        SqlConnection conn;
        string ownerName;
        string petName;
        string breed;
        DateTime birthday;
        string gender;
        string contactNo;
        string email;
        string appDate;
        string status;


        public frmAppointmentsviewonly(int appID, string date)
        {
            InitializeComponent();
            this.appID = appID;
            this.BackColor = Color.FromArgb(218, 177, 126);
            txtServices.Multiline = true;
            txtServices.ScrollBars = ScrollBars.Vertical;
            txtServices.ReadOnly = true;


            // Validate and parse the date
            if (!DateTime.TryParse(date, out DateTime parsedDate))
            {
                MessageBox.Show("Invalid appointment date format.");
                return;
            }

            this.appDate = parsedDate.ToString("yyyy-MM-dd");

            // Add more detailed logging
            Console.WriteLine($"Constructed with appID: {appID}, Date: {this.appDate}");

            conn = process.getConnection();
            FetchAndAssignAppointmentDetails();

        }


        public void FetchAndAssignAppointmentDetails()
        {
            // Updated query with more robust error handling and logging
            string query = @"
    SELECT TOP 1
        a.oname, 
        a.pname, 
        a.breed, 
        a.birthday, 
        a.gender, 
        a.contactNo, 
        a.email, 
        FORMAT(s.date, 'MMMM dd, yyyy') AS date,
        s.status
    FROM 
        appointments a
    INNER JOIN 
        schedule s ON a.appid = s.appid
    WHERE 
        a.appID = @appID AND CAST(s.date AS DATE) = @date
    ORDER BY 
        CASE 
            WHEN s.status = 'Pending' THEN 1 
            ELSE 2 
        END;


    SELECT 
     
        s.service
    FROM 
        appointments a
    INNER JOIN 
        schedule s ON a.appid = s.appid
    WHERE 
        a.appID = @appID AND CAST(s.date AS DATE) = @date AND service IS NOT NULL and s.status = 'Pending'


    SELECT 
     
        s.service as doneservice
    FROM 
        appointments a
    INNER JOIN 
        schedule s ON a.appid = s.appid
    WHERE 
        a.appID = @appID AND CAST(s.date AS DATE) = @date AND service IS NOT NULL and s.status = 'Done'
    ";

            try
            {
                // Ensure connection is open
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    // Add parameters with null checks
                    command.Parameters.AddWithValue("@appID", appID);
                    command.Parameters.AddWithValue("@date", DateTime.Parse(appDate).Date);

                    // Use ExecuteReader with more robust error checking
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Check if any rows are returned
                        if (reader.HasRows)
                        {
                            // Only read if there are rows
                            if (reader.Read())
                            {
                                // Null-coalescing and null checks for all fields
                                ownerName = reader["oname"] as string ?? "N/A";
                                petName = reader["pname"] as string ?? "N/A";
                                breed = reader["breed"] as string ?? "N/A";

                                // Handle birthday carefully
                                birthday = reader["birthday"] != DBNull.Value
                                    ? Convert.ToDateTime(reader["birthday"])
                                    : DateTime.MinValue;

                                gender = reader["gender"] as string ?? "N/A";
                                contactNo = reader["contactNo"] as string ?? "N/A";
                                email = reader["email"] as string ?? "N/A";
                                appDate = reader["date"] as string ?? "N/A";
                                status = reader["status"] as string ?? "N/A";

                                if (reader.NextResult())
                                {
                                    List<string> services = new List<string>();

                                    while (reader.Read())
                                    {
                                        string service = reader["service"] as string;
                                        if (!string.IsNullOrEmpty(service))
                                        {
                                            services.Add(service);
                                        }
                                    }

                                    if (services.Count > 0)
                                    {
                                        // Output services to a multi-line text box or other UI element
                                        txtServices.Text = string.Join(Environment.NewLine, services);
                                        txtServices.Visible = true; // Ensure the textbox is visible if there are services
                                        lblPending.Visible = true;
                                    }
                                    else
                                    {
                                        txtServices.Visible = false; // Hide the textbox if no services are found
                                        lblPending.Visible = false;
                                    }
                                }



                                // Update UI elements
                                try
                                {

                                    int age = CalculateAge(birthday);

                                    txtOwnerName.Text = ownerName;
                                    txtPetName.Text = petName;
                                    txtPetBreed.Text = breed;
                                    txtAge.Text = age.ToString();
                                    txtGender.Text = gender;
                                    txtContact.Text = contactNo;
                                    txtEmail.Text = email;
                                    txtDate.Text = appDate;
                                    txtStatus.Text = status;
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show($"Error updating UI elements: {ex.Message}");
                                }

                                if (reader.NextResult())
                                {
                                    Dictionary<string, decimal> servicePrices = new Dictionary<string, decimal>
                                    {
                                        { "Distemper Vaccine", 500 },
                                        { "Parvovirus Vaccine", 500 },
                                        { "Bordetella (Kennel Cough) Vaccine", 450 },
                                        { "Dental Cleaning", 1000 },
                                        { "Heartworm Test", 300 },
                                        { "Annual Wellness Exam", 700 },
                                        { "Flea and Tick Prevention", 200 },
                                        { "Leptospirosis Vaccine", 400 },
                                        { "Deworming", 250 },
                                        { "Rabies Vaccine", 600 }
                                    };

                                    List<string> doneServices = new List<string>();
                                    decimal totalAmount = 0;

                                    while (reader.Read())
                                    {
                                        string service = reader["doneservice"] as string;
                                        if (!string.IsNullOrEmpty(service) && servicePrices.ContainsKey(service))
                                        {
                                            decimal price = servicePrices[service];
                                            doneServices.Add($"{service} - PHP {price}");
                                            totalAmount += price;
                                        }
                                    }

                                    if (doneServices.Count > 0)
                                    {
                                        receiptPanel.Controls.Clear();
                                        receiptPanel.Visible = true;

                                        int yPosition = 10;
                                        foreach (string doneService in doneServices)
                                        {
                                            Label lblService = new Label
                                            {
                                                Text = doneService,
                                                AutoSize = false,
                                                Size = new Size(380, 50),
                                                TextAlign = ContentAlignment.MiddleCenter,
                                                Margin = new Padding(15, 5, 15, 5),
                                                Location = new Point(10, 10 + (yPosition * 3)), // Adjusted y-position
                                                BackColor = Color.FromArgb(255, 245, 233)
                                            };
                                            receiptPanel.Controls.Add(lblService);
                                            yPosition += 20;

                                            lblService.Paint += (s, e) =>
                                            {
                                                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                                                {
                                                    int cornerRadius = 45;
                                                    path.AddArc(lblService.ClientRectangle.X, lblService.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                                                    path.AddArc(lblService.ClientRectangle.Right - cornerRadius, lblService.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                                                    path.AddArc(lblService.ClientRectangle.Right - cornerRadius, lblService.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                                                    path.AddArc(lblService.ClientRectangle.X, lblService.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                                                    path.CloseFigure();
                                                    lblService.Region = new Region(path);
                                                }
                                            };
                                        }


                                        Label lblTotal = new Label
                                        {
                                            Text = $"Total Amount: PHP {totalAmount}",
                                            AutoSize = false,
                                            Size = new Size(380, 50),
                                            ForeColor = Color.White,
                                            TextAlign = ContentAlignment.MiddleCenter,
                                            Margin = new Padding(15, 5, 15, 5),

                                            Location = new Point(10, 10 + (yPosition * 4)), // Adjusted y-position
                                            BackColor = Color.FromArgb(226, 201, 62)
                                        };
                                        receiptPanel.Controls.Add(lblTotal);
                                        yPosition += 20;

                                        lblTotal.Paint += (s, e) =>
                                        {
                                            using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                                            {
                                                int cornerRadius = 45;
                                                path.AddArc(lblTotal.ClientRectangle.X, lblTotal.ClientRectangle.Y, cornerRadius, cornerRadius, 180, 90); // Top-left corner
                                                path.AddArc(lblTotal.ClientRectangle.Right - cornerRadius, lblTotal.ClientRectangle.Y, cornerRadius, cornerRadius, 270, 90); // Top-right corner
                                                path.AddArc(lblTotal.ClientRectangle.Right - cornerRadius, lblTotal.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 0, 90); // Bottom-right corner
                                                path.AddArc(lblTotal.ClientRectangle.X, lblTotal.ClientRectangle.Bottom - cornerRadius, cornerRadius, cornerRadius, 90, 90); // Bottom-left corner
                                                path.CloseFigure();
                                                lblTotal.Region = new Region(path);
                                            }
                                        };

                                        receiptPanel.Controls.Add(lblTotal);
                                    }
                                    else
                                    {
                                        receiptPanel.Visible = false; // Hide the panel if no services are done
                                    }
                                }



                            }
                            else
                            {
                                MessageBox.Show("No appointment details could be read.");
                            }
                        }
                        else
                        {
                            MessageBox.Show($"No appointment found for AppID {appID} on date {appDate}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error in FetchAndAssignAppointmentDetails: {ex.Message}\n\nStack Trace: {ex.StackTrace}");
                Console.WriteLine($"Exception Details: {ex}");
            }
            finally
            {
                // Ensure connection is closed
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }



        private int CalculateAge(DateTime birthday)
        {
            // Existing age calculation method
            int age = DateTime.Now.Year - birthday.Year;
            if (DateTime.Now.DayOfYear < birthday.DayOfYear)
            {
                age--;
            }
            return age;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            DateTime formattedDate = DateTime.Parse(appDate);
            string formattedAppDate = formattedDate.ToString("yyyy-MM-dd");

            frmFollowUp patientInfoForm = new frmFollowUp(
                this,
                formattedAppDate,
                appID,
                ownerName,
                petName,
                breed,
                birthday,
                gender,
                contactNo,
                email,
                status
            );
            patientInfoForm.Show();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // Define the dimensions of the rectangle
            Rectangle rectangle = new Rectangle(15, 20, 370, 430); // X, Y, Width, Height
            int cornerRadius = 30; // Radius of the curved corners

            // Create a GraphicsPath for the rounded rectangle
            using (System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath())
            {
                // Top-left corner
                path.AddArc(rectangle.Left, rectangle.Top, cornerRadius * 2, cornerRadius * 2, 180, 90);
                // Top-right corner
                path.AddArc(rectangle.Right - cornerRadius * 2, rectangle.Top, cornerRadius * 2, cornerRadius * 2, 270, 90);
                // Bottom-right corner
                path.AddArc(rectangle.Right - cornerRadius * 2, rectangle.Bottom - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 0, 90);
                // Bottom-left corner
                path.AddArc(rectangle.Left, rectangle.Bottom - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 90, 90);
                path.CloseFigure(); // Close the path to form a complete rounded rectangle



                // Create a semi-transparent brush
                using (SolidBrush brush = new SolidBrush(Color.FromArgb(255, 245, 233))) // 200 = 80% opacity
                {
                    // Fill the rounded rectangle
                    e.Graphics.FillPath(brush, path);
                }


                // Create a pen for the border


            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}