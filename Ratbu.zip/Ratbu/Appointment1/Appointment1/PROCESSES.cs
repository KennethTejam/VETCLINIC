﻿using Microsoft.VisualBasic.ApplicationServices;
using System.Data;
using System.Data.SqlClient;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Appointment1
{
    internal class PROCESSES
    {
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-MSA24LI\SQLEXPRESS;Initial Catalog=CLINIC_DB;Integrated Security=True;");
        string connectionString = "Data Source=DESKTOP-MSA24LI\\SQLEXPRESS;Initial Catalog=CLINIC_DB;Integrated Security=True;";
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        public SqlConnection getConnection()
        {
            return conn;
        }
        ///////////////
        ///////////////
        public string getStringConnection()
        {

            return "Data Source=LAPTOP-C2670BG2\\SQLEXPRESS;Initial Catalog=CLINIC_DB;Integrated Security=True;";
        }
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        public int Signup_AccChecker(string email)
        {
            string querry;
            SqlDataAdapter sda;
            DataTable dtable;
            try
            {
                querry = "SELECT * FROM UserInfo WHERE email = '" + email + "';";
                sda = new SqlDataAdapter(querry, conn);

                dtable = new DataTable();
                sda.Fill(dtable);

                if (dtable.Rows.Count > 0)
                {
                    return dtable.Rows.Count;
                }
                return 0;
            }
            catch
            {
                return -1;
            }
            finally { conn.Close(); }
        }
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        public bool Signup_AddToDatabase(string fname, string lname, string mname, string position, string email, string pass, string pin)
        {
            try
            {
                conn.Open();
                string query = "INSERT INTO UserInfo (fname, mname, lname, email, position, pass,pin,datecreated) VALUES (@fname, @mname, @lname, @Email, @position, @Pass,@Pin,GETDATE())";

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@fname", fname);
                    command.Parameters.AddWithValue("@mname", mname);
                    command.Parameters.AddWithValue("@lname", lname);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@position", position);
                    command.Parameters.AddWithValue("@Pass", pass);
                    command.Parameters.AddWithValue("@Pin", pin);


                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Registration successful!");
                int userid = -1;
                Login login = new Login(userid);
                login.Show();
                return true;

            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        public int login_CheckAccount(string useremail, string user_password)
        {
            int id = -1;
            try
            {

                string querry = "SELECT * FROM UserInfo WHERE email = '" + useremail + "' AND pass = '" + user_password + "';";
                SqlDataAdapter sda = new SqlDataAdapter(querry, conn);

                DataTable dtable = new DataTable();
                sda.Fill(dtable);
                id = Convert.ToInt32(dtable.Rows[0]["userid"]);
                if (dtable.Rows.Count > 0)
                {
                    return id;
                }
                else
                {
                    return id;
                }
            }
            catch
            {
                return id;
            }
            finally { conn.Close(); }
        }
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        public string getPosition(string useremail, string user_password)
        {
            string role = "";
            try
            {

                string querry = "SELECT * FROM UserInfo WHERE email = '" + useremail + "' AND pass = '" + user_password + "';";
                SqlDataAdapter sda = new SqlDataAdapter(querry, conn);

                DataTable dtable = new DataTable();
                sda.Fill(dtable);
                role = dtable.Rows[0]["position"].ToString();
                if (dtable.Rows.Count > 0)
                {
                    return role;
                }
                else
                {
                    return role;
                }
            }
            catch
            {
                return role;
            }
            finally { conn.Close(); }
        }
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        public bool ForgotPassword_CheckAccount(string email, string pin)
        {
            try
            {
                string querryemail = "SELECT * FROM UserInfo WHERE email = '" + email + "';";

                SqlDataAdapter sdaemail = new SqlDataAdapter(querryemail, conn);


                DataTable dtableemail = new DataTable();

                sdaemail.Fill(dtableemail);

                string dbPin = dtableemail.Rows[0]["pin"].ToString();

                if (dtableemail.Rows.Count == 0)
                {
                    MessageBox.Show("Wrong Email!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }
                else if (dtableemail.Rows.Count > 0 && dbPin != pin)
                {
                    MessageBox.Show("Wrong Pin!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
                return false;
            }
            finally { conn.Close(); }
        }
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        public bool ForgotPassword_SetPassword(string email, int pin, string pass)
        {
            try
            {
                conn.Open();
                string query = "Update UserInfo set pass = @password WHERE email = @email AND pin = @pin";

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@password", pass);
                    command.Parameters.AddWithValue("@email", email);
                    command.Parameters.AddWithValue("@pin", pin);
                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Password change successful!");
                return true;
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
                return false;
            }
            finally
            {
                conn.Close();
            }

        }
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        public void AddRecord_AddToDatabase(string petname, DateTime petbday, string breed, string petgender, string owner, string contactnum, string email, string status, List<(string Note, DateTime Date)> medicalNotes)
        {
            try
            {
                conn.Open();

                // Insert query for Appointments table
                string query = "INSERT INTO Appointments (pname, breed, birthday, gender, oname, contactNo, email, appDate, appTime, status) " +
                               "VALUES (@petname, @breed, @petbday, @petgender, @owner, @contactnum, @email, GETDATE(), CONVERT(TIME, GETDATE()), @status);" +
                               "SELECT SCOPE_IDENTITY();"; // Get the last inserted identity (appid)

                int appid = 0; // Variable to store the appid

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@petname", petname);
                    command.Parameters.AddWithValue("@breed", breed);
                    command.Parameters.AddWithValue("@petbday", petbday);
                    command.Parameters.AddWithValue("@petgender", petgender);
                    command.Parameters.AddWithValue("@owner", owner);
                    command.Parameters.AddWithValue("@contactnum", contactnum);
                    command.Parameters.AddWithValue("@email", email);
                    command.Parameters.AddWithValue("@status", status);

                    // Execute the query and get the appid (last inserted identity)
                    appid = Convert.ToInt32(command.ExecuteScalar());
                }

                // If there are medical notes, insert them into the Services table
                if (medicalNotes != null && medicalNotes.Count > 0)
                {
                    string notesQuery = "INSERT INTO Services (service, date, appID) VALUES (@note, @date, @appid)";
                    foreach (var (note, date) in medicalNotes)
                    {
                        using (SqlCommand command = new SqlCommand(notesQuery, conn))
                        {
                            command.Parameters.AddWithValue("@note", note);
                            command.Parameters.AddWithValue("@date", date);
                            command.Parameters.AddWithValue("@appid", appid); // Use the appid retrieved from the first insert
                            command.ExecuteNonQuery();
                        }
                    }
                }

                MessageBox.Show("Record Added successfully!");
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
                return;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
                return;
            }
            finally
            {
                conn.Close();
            }
        }
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        public int AddRecord_CheckDatabase(string petname, string owner, string email)
        {

            DateTime datechecker = DateTime.Now.Date;
            try
            {
                string queryEmail = "SELECT * FROM Appointments WHERE email = @email AND pname = @pname AND oname = @oname AND appDate = @DATETODAY";
                DataTable dtableEmail = new DataTable();
                conn.Open();
                using (SqlCommand command = new SqlCommand(queryEmail, conn))
                {
                    command.Parameters.AddWithValue("@email", email);
                    command.Parameters.AddWithValue("@pname", petname);
                    command.Parameters.AddWithValue("@oname", owner);
                    command.Parameters.AddWithValue("@DATETODAY", datechecker);
                    using (SqlDataAdapter sdaEmail = new SqlDataAdapter(command))
                    {
                        sdaEmail.Fill(dtableEmail);
                    }
                }

                if (dtableEmail.Rows.Count > 0)
                {
                    return dtableEmail.Rows.Count;
                }
                else
                {
                    return dtableEmail.Rows.Count;
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
                return -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
                return -1;
            }
            finally { conn.Close(); }
        }
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        public int getUserID(string name)
        {
            try
            {
                string query = "SELECT userID FROM UserInfo WHERE (fname + ' ' + mname + ' ' + lname) = @fullName";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@fullName", name.Trim());

                    SqlDataAdapter sdaemail = new SqlDataAdapter(cmd);
                    DataTable dtableemail = new DataTable();
                    sdaemail.Fill(dtableemail);

                    if (dtableemail.Rows.Count > 0)
                    {
                        int userid = Convert.ToInt32(dtableemail.Rows[0]["userID"]);
                        return userid;
                    }
                    else
                    {
                        MessageBox.Show("Please Select A Veterinarian!!");
                        return -1;
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
                return -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
                return -1;
            }
            finally
            {
                conn.Close();
            }
        }
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        public bool getNameSpace(string fname, string lname, string mname, string position, string email, string pass, string pin)
        {

            int fnamespace, mnamespace, lnamespace;


            fnamespace = fname.IndexOf(' ');

            if (fnamespace == -1)
            {
                fname = char.ToUpper(fname[0]) + fname.Substring(1).ToLower();
            }
            else
            {
                fname = char.ToUpper(fname[0]) + fname.Substring(1, fnamespace).ToLower() + char.ToUpper(fname[fnamespace + 1]) + fname.Substring(fnamespace + 2).ToLower();
            }
            ///
            ///
            mnamespace = mname.IndexOf(' ');

            if (mnamespace == -1)
            {
                mname = char.ToUpper(mname[0]) + mname.Substring(1).ToLower();
            }
            else
            {
                mname = char.ToUpper(mname[0]) + mname.Substring(1, mnamespace).ToLower() + char.ToUpper(mname[mnamespace + 1]) + mname.Substring(mnamespace + 2).ToLower();

            }
            ///
            ///
            lnamespace = lname.IndexOf(' ');

            if (lnamespace == -1)
            { lname = char.ToUpper(lname[0]) + lname.Substring(1).ToLower(); }
            else
            {
                lname = char.ToUpper(lname[0]) + lname.Substring(1, lnamespace).ToLower() + char.ToUpper(lname[lnamespace + 1]) + lname.Substring(lnamespace + 2).ToLower();
            }
            ///
            ///
            if (email != "")
            {
                email = char.ToUpper(email[0]) + email.Substring(1).ToLower();
            }
            bool processofsignup = Signup_AddToDatabase(fname, lname, mname, position, email, pass, pin);
            return processofsignup;
        }
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        ///////////////
        public string GetPicture(int userid) {
            try
            {
                string query = "SELECT Iconlocation FROM UserInfo WHERE userId = @id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", userid);
                    SqlDataAdapter sdaemail = new SqlDataAdapter(cmd);
                    DataTable dtableemail = new DataTable();
                    sdaemail.Fill(dtableemail);

                    if (dtableemail.Rows.Count > 0)
                    {
                        return (dtableemail.Rows[0]["IconLocation"]).ToString();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
                return "";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
                return "";
            }
            finally
            {
                conn.Close();
            }
            return "";
        }


        public string getUserEmail(int userid)
        {
            try
            {
                string querryemail = "SELECT * FROM UserInfo WHERE userid = '" + userid + "';";
                SqlDataAdapter sdaemail = new SqlDataAdapter(querryemail, conn);
                DataTable dtableemail = new DataTable();

                sdaemail.Fill(dtableemail);

                string fullname = dtableemail.Rows[0]["fname"].ToString() + " " + dtableemail.Rows[0]["mname"].ToString() + " " + dtableemail.Rows[0]["lname"].ToString();

                if (dtableemail.Rows.Count > 0)
                {
                    return fullname;
                }
                else { return ""; }

            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
                return "";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
                return "";
            }
            finally { conn.Close(); }
        }



        public bool validatePassword(int userid, string password)
        {
            try
            {
                string querryemail = "SELECT * FROM UserInfo WHERE userid = '" + userid + "';";
                SqlDataAdapter sdaemail = new SqlDataAdapter(querryemail, conn);
                DataTable dtableemail = new DataTable();

                sdaemail.Fill(dtableemail);

                string verifypassword = dtableemail.Rows[0]["pass"].ToString();

                if (dtableemail.Rows.Count > 0)
                {
                    if (verifypassword == password)
                    {
                        MessageBox.Show("Verification Successful!!");
                        return true;
                    }
                }
                return false;

            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
                return false; ;
            }
            finally { conn.Close(); }
        }

        public void addToInventory(string txt, int price, string type, int cntr)
        {
            try
            {
                conn.Open();
                string querryemail = "SELECT * FROM inventory WHERE product_name = '" + txt + "' AND type = '" + type + "';";
                SqlDataAdapter sdaemail = new SqlDataAdapter(querryemail, conn);
                DataTable dtableemail = new DataTable();

                sdaemail.Fill(dtableemail);
                if (dtableemail.Rows.Count > 0)
                {
                    MessageBox.Show("Product is already listed!!");
                    return;
                }
                else
                {

                    string query = "INSERT INTO inventory (product_name, quantity, price, type, date_added) " +
                       "VALUES (@pname, @qty, @price, @type, GETDATE())";

                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@pname", txt);
                        command.Parameters.AddWithValue("@qty", cntr);
                        command.Parameters.AddWithValue("@price", price);
                        command.Parameters.AddWithValue("@type", type);

                        command.ExecuteNonQuery();
                    }

                    MessageBox.Show("Successfully Added to Inventory!!");

                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
                return;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
                return;
            }
            finally { conn.Close(); }
        }


        public DataTable getTable() {
            DataTable dataTable = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {

                    string query = "SELECT productid, product_name, quantity, price,type FROM inventory";


                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);


                    
                    dataAdapter.Fill(dataTable);

                    return dataTable;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
                return dataTable;
            }
        }

        public void Addicontodb(int userid, string imgloc) {
            conn.Open();
            try
            {
                string query = "Update UserInfo set IconLocation = @omgloc WHERE userid = @userid";

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@omgloc", imgloc);
                    command.Parameters.AddWithValue("@userid", userid);
                    command.ExecuteNonQuery();
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }       
        }


        public void FetchDetailsByAppId(int appid, out string breed, out DateTime birthday, out string gender, out string contactNo, out string email)
        {
            string query = "SELECT breed, birthday, gender, contactNo, email FROM appointments WHERE appid = @appid";

            breed = string.Empty;
            birthday = DateTime.MinValue;
            gender = string.Empty;
            contactNo = string.Empty;
            email = string.Empty;

            try
            {
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@appid", appid);

                if (conn.State != ConnectionState.Open)
                    conn.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    breed = reader["breed"].ToString();
                    birthday = Convert.ToDateTime(reader["birthday"]);
                    gender = reader["gender"].ToString();
                    contactNo = reader["contactNo"].ToString();
                    email = reader["email"].ToString();
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }
        }




        public void Search(string searchText, ComboBox comboBox, out Dictionary<string, int> itemAppIdMap)
        {
            string query = "SELECT appid, pname, oname FROM appointments WHERE pname LIKE @search OR oname LIKE @search";
            itemAppIdMap = new Dictionary<string, int>();

            try
            {
                comboBox.Items.Clear();

                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@search", $"%{searchText}%");

                if (conn.State != ConnectionState.Open)
                    conn.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    string item = $"{reader["pname"]} ({reader["oname"]})";
                    int appid = Convert.ToInt32(reader["appid"]);

                    comboBox.Items.Add(item);
                    itemAppIdMap[item] = appid; // Store the appid for the ComboBox item
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }
        }
















        public void Book(int appid)
        {
            // Define the query to insert into the database
            string query = "INSERT INTO schedule (date, appid, status) VALUES (@date, @appid, @status)";

            try
            {
                // Open the connection if it's not open
                if (conn.State != ConnectionState.Open)
                    conn.Open();

                // Create the command and set parameters
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@date", DateTime.Today); // Insert today's date
                command.Parameters.AddWithValue("@appid", appid);        // Insert the AppID
                command.Parameters.AddWithValue("@status", "Pending");   // Set status to "Pending"

                // Execute the query
                int rowsAffected = command.ExecuteNonQuery();

                // Show confirmation if successful
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Booking successfully created!");
                }
                else
                {
                    MessageBox.Show("Failed to create booking. Please try again.");
                }
            }   
            catch (Exception ex)
            {
                // Handle exceptions
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                // Close the connection
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }
        }






    }

}
