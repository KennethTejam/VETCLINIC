﻿namespace Appointment1
{
    partial class frmPending
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pAppointment = new Panel();
            lblDone = new Label();
            lblPending = new Label();
            cbSort = new ComboBox();
            txtSearch = new TextBox();
            Label_ManageAccount = new Label();
            Label_History = new Label();
            Label_Homepage = new Label();
            SuspendLayout();
            // 
            // pAppointment
            // 
            pAppointment.AutoScroll = true;
            pAppointment.Location = new Point(180, 277);
            pAppointment.Name = "pAppointment";
            pAppointment.Size = new Size(297, 172);
            pAppointment.TabIndex = 0;
            // 
            // lblDone
            // 
            lblDone.AutoSize = true;
            lblDone.Location = new Point(421, 185);
            lblDone.Name = "lblDone";
            lblDone.Size = new Size(45, 20);
            lblDone.TabIndex = 5;
            lblDone.Text = "Done";
            lblDone.Click += lblDone_Click;
            // 
            // lblPending
            // 
            lblPending.AutoSize = true;
            lblPending.Location = new Point(198, 185);
            lblPending.Name = "lblPending";
            lblPending.Size = new Size(62, 20);
            lblPending.TabIndex = 4;
            lblPending.Text = "Pending";
            // 
            // cbSort
            // 
            cbSort.FormattingEnabled = true;
            cbSort.Location = new Point(572, 149);
            cbSort.Name = "cbSort";
            cbSort.Size = new Size(151, 28);
            cbSort.TabIndex = 6;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(556, 101);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(141, 27);
            txtSearch.TabIndex = 7;
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.BorderStyle = BorderStyle.Fixed3D;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.Location = new Point(499, 43);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Size = new Size(210, 34);
            Label_ManageAccount.TabIndex = 16;
            Label_ManageAccount.Text = "Manage Account";
            Label_ManageAccount.Click += Label_ManageAccount_Click;
            // 
            // Label_History
            // 
            Label_History.AutoSize = true;
            Label_History.BorderStyle = BorderStyle.Fixed3D;
            Label_History.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_History.Location = new Point(310, 43);
            Label_History.Name = "Label_History";
            Label_History.Size = new Size(179, 34);
            Label_History.TabIndex = 15;
            Label_History.Text = "Appointments";
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = SystemColors.Control;
            Label_Homepage.BorderStyle = BorderStyle.Fixed3D;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = SystemColors.ControlText;
            Label_Homepage.Location = new Point(147, 43);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Size = new Size(140, 34);
            Label_Homepage.TabIndex = 18;
            Label_Homepage.Text = "Homepage";
            Label_Homepage.Click += Label_Homepage_Click;
            // 
            // frmPending
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(782, 484);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_History);
            Controls.Add(txtSearch);
            Controls.Add(cbSort);
            Controls.Add(lblDone);
            Controls.Add(lblPending);
            Controls.Add(pAppointment);
            Name = "frmPending";
            Text = "Appointments - Pending";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pAppointment;
        private Label lblDone;
        private Label lblPending;
        private ComboBox cbSort;
        private TextBox txtSearch;
        private Label Label_ManageAccount;
        private Label Label_History;
        private Label Label_Homepage;
    }
}