﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appointment1
{
    public partial class frmAppointments : Form
    {
        private int appID;
        int userid;
        PROCESSES process = new PROCESSES();
        SqlConnection conn;
        string ownerName;
        string petName;
        string breed;
        DateTime birthday;
        string gender;
        string contactNo;
        string email;
        string appDate;
        string status;

        public frmAppointments(int appID, string date)
        {
            InitializeComponent();
            this.appID = appID;

            // Validate and parse the date
            if (!DateTime.TryParse(date, out DateTime parsedDate))
            {
                MessageBox.Show("Invalid appointment date format.");
                return;
            }

            this.appDate = parsedDate.ToString("yyyy-MM-dd");

            // Add more detailed logging
            Console.WriteLine($"Constructed with appID: {appID}, Date: {this.appDate}");

            conn = process.getConnection();
            FetchAndAssignAppointmentDetails();
        }

        public void FetchAndAssignAppointmentDetails()
        {
            // Updated query with more robust error handling and logging
            string query = @"
    SELECT TOP 1
        a.oname, 
        a.pname, 
        a.breed, 
        a.birthday, 
        a.gender, 
        a.contactNo, 
        a.email, 
        FORMAT(s.date, 'yyyy-MM-dd') AS date,
        s.status
    FROM 
        appointments a
    INNER JOIN 
        schedule s ON a.appid = s.appid
    WHERE 
        a.appID = @appID AND CAST(s.date AS DATE) = @date
    ORDER BY 
        CASE 
            WHEN s.status = 'Pending' THEN 1 
            ELSE 2 
        END;
    ";

            try
            {
                // Ensure connection is open
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    // Add parameters with null checks
                    command.Parameters.AddWithValue("@appID", appID);
                    command.Parameters.AddWithValue("@date", DateTime.Parse(appDate).Date);

                    // Use ExecuteReader with more robust error checking
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Check if any rows are returned
                        if (reader.HasRows)
                        {
                            // Only read if there are rows
                            if (reader.Read())
                            {
                                // Null-coalescing and null checks for all fields
                                ownerName = reader["oname"] as string ?? "N/A";
                                petName = reader["pname"] as string ?? "N/A";
                                breed = reader["breed"] as string ?? "N/A";

                                // Handle birthday carefully
                                birthday = reader["birthday"] != DBNull.Value
                                    ? Convert.ToDateTime(reader["birthday"])
                                    : DateTime.MinValue;

                                gender = reader["gender"] as string ?? "N/A";
                                contactNo = reader["contactNo"] as string ?? "N/A";
                                email = reader["email"] as string ?? "N/A";
                                appDate = reader["date"] as string ?? "N/A";
                                status = reader["status"] as string ?? "N/A";

                                // Additional debugging output
                                Console.WriteLine($"Fetched Appointment Details - Name: {ownerName}, Pet: {petName}, Status: {status}");

                                // Update UI elements
                                UpdateUIElements();
                            }
                            else
                            {
                                MessageBox.Show("No appointment details could be read.");
                            }
                        }
                        else
                        {
                            MessageBox.Show($"No appointment found for AppID {appID} on date {appDate}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // More detailed error logging
                MessageBox.Show($"Error in FetchAndAssignAppointmentDetails: {ex.Message}\n\nStack Trace: {ex.StackTrace}");
                Console.WriteLine($"Exception Details: {ex}");
            }
            finally
            {
                // Ensure connection is closed
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        private void UpdateUIElements()
        {
            // Separate method to update UI to improve readability
            try
            {
                btnNext.Visible = (status == "Pending");

                int age = CalculateAge(birthday);

                txtOwnerName.Text = ownerName;
                txtPetName.Text = petName;
                txtPetBreed.Text = breed;
                txtAge.Text = age.ToString();
                txtGender.Text = gender;
                txtContact.Text = contactNo;
                txtEmail.Text = email;
                txtAppointmentDate.Text = appDate;
                txtStatus.Text = status;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating UI elements: {ex.Message}");
            }
        }

        private int CalculateAge(DateTime birthday)
        {
            // Existing age calculation method
            int age = DateTime.Now.Year - birthday.Year;
            if (DateTime.Now.DayOfYear < birthday.DayOfYear)
            {
                age--;
            }
            return age;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            DateTime formattedDate = DateTime.Parse(appDate);
            string formattedAppDate = formattedDate.ToString("yyyy-MM-dd");

            frmFollowUp patientInfoForm = new frmFollowUp(
                this,
                formattedAppDate,
                appID,
                ownerName,
                petName,
                breed,
                birthday,
                gender,
                contactNo,
                email,
                status
            );
            patientInfoForm.Show();
        }
    }
}