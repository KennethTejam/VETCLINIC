﻿namespace Appointment1
{
    partial class ExistingRecord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExistingRecord));
            txtBreed = new TextBox();
            btnBook = new Button();
            Label_Mname = new Label();
            label3 = new Label();
            Label_Email = new Label();
            Label_Fname = new Label();
            Label_Homepage = new Label();
            Label_ManageAccount = new Label();
            Label_Appointment = new Label();
            Label_History = new Label();
            Label_Username = new Label();
            Label_Welcome = new Label();
            Clinic_MainLogo = new PictureBox();
            txtSearch = new TextBox();
            cboPet = new ComboBox();
            txtAge = new TextBox();
            txtGender = new TextBox();
            txtContactNo = new TextBox();
            txtEmail = new TextBox();
            ((System.ComponentModel.ISupportInitialize)Clinic_MainLogo).BeginInit();
            SuspendLayout();
            // 
            // txtBreed
            // 
            txtBreed.BackColor = SystemColors.Window;
            txtBreed.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            txtBreed.Location = new Point(302, 453);
            txtBreed.Margin = new Padding(3, 0, 3, 4);
            txtBreed.Multiline = true;
            txtBreed.Name = "txtBreed";
            txtBreed.ReadOnly = true;
            txtBreed.Size = new Size(295, 40);
            txtBreed.TabIndex = 68;
            // 
            // btnBook
            // 
            btnBook.Enabled = false;
            btnBook.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBook.Location = new Point(914, 796);
            btnBook.Margin = new Padding(3, 4, 3, 4);
            btnBook.Name = "btnBook";
            btnBook.Size = new Size(216, 100);
            btnBook.TabIndex = 70;
            btnBook.Text = "Book Appointment";
            btnBook.UseVisualStyleBackColor = true;
            btnBook.Click += btnBook_Click;
            // 
            // Label_Mname
            // 
            Label_Mname.AutoSize = true;
            Label_Mname.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Mname.Location = new Point(42, 451);
            Label_Mname.Name = "Label_Mname";
            Label_Mname.Size = new Size(107, 37);
            Label_Mname.TabIndex = 73;
            Label_Mname.Text = "BREED:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold);
            label3.Location = new Point(185, 511);
            label3.Name = "label3";
            label3.Size = new Size(0, 50);
            label3.TabIndex = 75;
            // 
            // Label_Email
            // 
            Label_Email.AutoSize = true;
            Label_Email.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Email.Location = new Point(42, 501);
            Label_Email.Name = "Label_Email";
            Label_Email.Size = new Size(76, 37);
            Label_Email.TabIndex = 76;
            Label_Email.Text = "AGE:";
            // 
            // Label_Fname
            // 
            Label_Fname.AutoSize = true;
            Label_Fname.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Fname.Location = new Point(42, 390);
            Label_Fname.Name = "Label_Fname";
            Label_Fname.Size = new Size(158, 37);
            Label_Fname.TabIndex = 77;
            Label_Fname.Text = "PET NAME:";
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = SystemColors.Control;
            Label_Homepage.BorderStyle = BorderStyle.Fixed3D;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = SystemColors.ControlText;
            Label_Homepage.Location = new Point(454, 194);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Size = new Size(140, 34);
            Label_Homepage.TabIndex = 66;
            Label_Homepage.Text = "Homepage";
            Label_Homepage.Click += Label_Homepage_Click;
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.BorderStyle = BorderStyle.Fixed3D;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.Location = new Point(945, 194);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Size = new Size(210, 34);
            Label_ManageAccount.TabIndex = 65;
            Label_ManageAccount.Text = "Manage Account";
            // 
            // Label_Appointment
            // 
            Label_Appointment.AutoSize = true;
            Label_Appointment.BorderStyle = BorderStyle.Fixed3D;
            Label_Appointment.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Appointment.Location = new Point(589, 194);
            Label_Appointment.Name = "Label_Appointment";
            Label_Appointment.Size = new Size(181, 34);
            Label_Appointment.TabIndex = 64;
            Label_Appointment.Text = "Add to Record";
            // 
            // Label_History
            // 
            Label_History.AutoSize = true;
            Label_History.BackColor = SystemColors.Control;
            Label_History.BorderStyle = BorderStyle.Fixed3D;
            Label_History.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_History.ForeColor = SystemColors.ControlText;
            Label_History.Location = new Point(759, 194);
            Label_History.Name = "Label_History";
            Label_History.Size = new Size(198, 34);
            Label_History.TabIndex = 63;
            Label_History.Text = "History Records";
            Label_History.Click += Label_History_Click;
            // 
            // Label_Username
            // 
            Label_Username.AutoSize = true;
            Label_Username.Font = new Font("Sitka Subheading", 27.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Label_Username.Location = new Point(249, 105);
            Label_Username.Name = "Label_Username";
            Label_Username.Size = new Size(339, 68);
            Label_Username.TabIndex = 62;
            Label_Username.Text = "@GMAIL.COM";
            // 
            // Label_Welcome
            // 
            Label_Welcome.AutoSize = true;
            Label_Welcome.Font = new Font("Sitka Subheading", 36F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Label_Welcome.Location = new Point(249, 13);
            Label_Welcome.Name = "Label_Welcome";
            Label_Welcome.Size = new Size(358, 87);
            Label_Welcome.TabIndex = 61;
            Label_Welcome.Text = "WELCOME!";
            // 
            // Clinic_MainLogo
            // 
            Clinic_MainLogo.Image = (Image)resources.GetObject("Clinic_MainLogo.Image");
            Clinic_MainLogo.Location = new Point(13, 30);
            Clinic_MainLogo.Margin = new Padding(3, 4, 3, 4);
            Clinic_MainLogo.Name = "Clinic_MainLogo";
            Clinic_MainLogo.Size = new Size(187, 200);
            Clinic_MainLogo.SizeMode = PictureBoxSizeMode.Zoom;
            Clinic_MainLogo.TabIndex = 60;
            Clinic_MainLogo.TabStop = false;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(914, 300);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(164, 27);
            txtSearch.TabIndex = 84;
            // 
            // cboPet
            // 
            cboPet.FormattingEnabled = true;
            cboPet.Location = new Point(302, 394);
            cboPet.Name = "cboPet";
            cboPet.Size = new Size(286, 28);
            cboPet.TabIndex = 85;
            // 
            // txtAge
            // 
            txtAge.BackColor = SystemColors.Window;
            txtAge.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            txtAge.Location = new Point(302, 501);
            txtAge.Margin = new Padding(3, 0, 3, 4);
            txtAge.Multiline = true;
            txtAge.Name = "txtAge";
            txtAge.ReadOnly = true;
            txtAge.Size = new Size(295, 40);
            txtAge.TabIndex = 86;
            // 
            // txtGender
            // 
            txtGender.BackColor = SystemColors.Window;
            txtGender.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            txtGender.Location = new Point(302, 551);
            txtGender.Margin = new Padding(3, 0, 3, 4);
            txtGender.Multiline = true;
            txtGender.Name = "txtGender";
            txtGender.ReadOnly = true;
            txtGender.Size = new Size(295, 40);
            txtGender.TabIndex = 87;
            // 
            // txtContactNo
            // 
            txtContactNo.BackColor = SystemColors.Window;
            txtContactNo.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            txtContactNo.Location = new Point(302, 605);
            txtContactNo.Margin = new Padding(3, 0, 3, 4);
            txtContactNo.Multiline = true;
            txtContactNo.Name = "txtContactNo";
            txtContactNo.ReadOnly = true;
            txtContactNo.Size = new Size(295, 40);
            txtContactNo.TabIndex = 88;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = SystemColors.Window;
            txtEmail.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            txtEmail.Location = new Point(302, 659);
            txtEmail.Margin = new Padding(3, 0, 3, 4);
            txtEmail.Multiline = true;
            txtEmail.Name = "txtEmail";
            txtEmail.ReadOnly = true;
            txtEmail.Size = new Size(295, 40);
            txtEmail.TabIndex = 89;
            // 
            // ExistingRecord
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1216, 908);
            Controls.Add(txtEmail);
            Controls.Add(txtContactNo);
            Controls.Add(txtGender);
            Controls.Add(txtAge);
            Controls.Add(cboPet);
            Controls.Add(txtSearch);
            Controls.Add(txtBreed);
            Controls.Add(btnBook);
            Controls.Add(Label_Mname);
            Controls.Add(label3);
            Controls.Add(Label_Email);
            Controls.Add(Label_Fname);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_Appointment);
            Controls.Add(Label_History);
            Controls.Add(Label_Username);
            Controls.Add(Label_Welcome);
            Controls.Add(Clinic_MainLogo);
            Name = "ExistingRecord";
            Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)Clinic_MainLogo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnDelete;
        private Button btnAdd;
        private Panel medpanel;
        private DateTimePicker dateTimePicker1;
        private RadioButton RadioButton_Female;
        private RadioButton RadioButton_Male;
        private TextBox txtBreed;
        private Button btnBook;
        private Label Label_Mname;
        private Label label3;
        private Label Label_Email;
        private Label Label_Fname;
        private Label Label_Homepage;
        private Label Label_ManageAccount;
        private Label Label_Appointment;
        private Label Label_History;
        private Label Label_Username;
        private Label Label_Welcome;
        private PictureBox Clinic_MainLogo;
        private TextBox txtSearch;
        private ComboBox cboPet;
        private TextBox txtAge;
        private TextBox txtGender;
        private TextBox txtContactNo;
        private TextBox txtEmail;
    }
}