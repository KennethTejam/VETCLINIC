﻿namespace Appointment1
{
    partial class ManageAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManageAccount));
            Clinic_MainLogo = new PictureBox();
            Button_PassConfirm = new Button();
            Button_PinConfirm = new Button();
            Button_EmailConfirm = new Button();
            pictureBox4 = new PictureBox();
            Label_Role = new Label();
            Label_Fullname = new Label();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            pictureBox3 = new PictureBox();
            label4 = new Label();
            label1 = new Label();
            Label_MemberSince = new Label();
            Label_Homepage = new Label();
            Label_ManageAccount = new Label();
            Label_AddRecord = new Label();
            Label_Appointment = new Label();
            Label_Username = new Label();
            label3 = new Label();
            TextBox_ChangeEmail = new TextBox();
            TextBox_ChangePassword = new TextBox();
            label2 = new Label();
            TextBox_ChangePin = new TextBox();
            ((System.ComponentModel.ISupportInitialize)Clinic_MainLogo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // Clinic_MainLogo
            // 
            Clinic_MainLogo.Image = (Image)resources.GetObject("Clinic_MainLogo.Image");
            Clinic_MainLogo.Location = new Point(31, 22);
            Clinic_MainLogo.Name = "Clinic_MainLogo";
            Clinic_MainLogo.Size = new Size(164, 150);
            Clinic_MainLogo.SizeMode = PictureBoxSizeMode.Zoom;
            Clinic_MainLogo.TabIndex = 90;
            Clinic_MainLogo.TabStop = false;
            // 
            // Button_PassConfirm
            // 
            Button_PassConfirm.Enabled = false;
            Button_PassConfirm.Font = new Font("Quadrat-Serial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Button_PassConfirm.Location = new Point(861, 437);
            Button_PassConfirm.Name = "Button_PassConfirm";
            Button_PassConfirm.Size = new Size(150, 50);
            Button_PassConfirm.TabIndex = 89;
            Button_PassConfirm.Text = "Confirm";
            Button_PassConfirm.UseVisualStyleBackColor = true;
            Button_PassConfirm.Visible = false;
            Button_PassConfirm.Click += Button_PassConfirm_Click;
            // 
            // Button_PinConfirm
            // 
            Button_PinConfirm.Enabled = false;
            Button_PinConfirm.Font = new Font("Quadrat-Serial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Button_PinConfirm.Location = new Point(861, 355);
            Button_PinConfirm.Name = "Button_PinConfirm";
            Button_PinConfirm.Size = new Size(150, 50);
            Button_PinConfirm.TabIndex = 88;
            Button_PinConfirm.Text = "Confirm";
            Button_PinConfirm.UseVisualStyleBackColor = true;
            Button_PinConfirm.Visible = false;
            Button_PinConfirm.Click += Button_PinConfirm_Click;
            // 
            // Button_EmailConfirm
            // 
            Button_EmailConfirm.Enabled = false;
            Button_EmailConfirm.Font = new Font("Quadrat-Serial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Button_EmailConfirm.Location = new Point(861, 272);
            Button_EmailConfirm.Name = "Button_EmailConfirm";
            Button_EmailConfirm.Size = new Size(150, 50);
            Button_EmailConfirm.TabIndex = 87;
            Button_EmailConfirm.Text = "Confirm";
            Button_EmailConfirm.UseVisualStyleBackColor = true;
            Button_EmailConfirm.Visible = false;
            Button_EmailConfirm.Click += Button_EmailConfirm_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.BackgroundImage = (Image)resources.GetObject("pictureBox4.BackgroundImage");
            pictureBox4.BorderStyle = BorderStyle.Fixed3D;
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(31, 251);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(248, 230);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 86;
            pictureBox4.TabStop = false;
            // 
            // Label_Role
            // 
            Label_Role.AutoSize = true;
            Label_Role.Font = new Font("Sitka Small", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label_Role.Location = new Point(31, 551);
            Label_Role.Name = "Label_Role";
            Label_Role.Size = new Size(138, 24);
            Label_Role.TabIndex = 85;
            Label_Role.Text = "Company Role:";
            // 
            // Label_Fullname
            // 
            Label_Fullname.AutoSize = true;
            Label_Fullname.Font = new Font("Sitka Small", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label_Fullname.Location = new Point(31, 527);
            Label_Fullname.Name = "Label_Fullname";
            Label_Fullname.Size = new Size(102, 24);
            Label_Fullname.TabIndex = 84;
            Label_Fullname.Text = "Full name:";
            // 
            // pictureBox2
            // 
            pictureBox2.Cursor = Cursors.Hand;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(790, 282);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(30, 30);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 83;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(790, 365);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 30);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 82;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Cursor = Cursors.Hand;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(790, 447);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(30, 30);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 81;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Small", 12F, FontStyle.Bold);
            label4.Location = new Point(401, 417);
            label4.Name = "label4";
            label4.Size = new Size(123, 24);
            label4.TabIndex = 80;
            label4.Text = "PASSWORD : ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Small", 12F, FontStyle.Bold);
            label1.Location = new Point(401, 251);
            label1.Name = "label1";
            label1.Size = new Size(85, 24);
            label1.TabIndex = 79;
            label1.Text = "EMAIL : ";
            // 
            // Label_MemberSince
            // 
            Label_MemberSince.AutoSize = true;
            Label_MemberSince.Font = new Font("Sitka Small", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label_MemberSince.Location = new Point(31, 503);
            Label_MemberSince.Name = "Label_MemberSince";
            Label_MemberSince.Size = new Size(139, 24);
            Label_MemberSince.TabIndex = 72;
            Label_MemberSince.Text = "Member Since: ";
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = SystemColors.Control;
            Label_Homepage.BorderStyle = BorderStyle.Fixed3D;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = SystemColors.ControlText;
            Label_Homepage.Location = new Point(401, 145);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Size = new Size(112, 27);
            Label_Homepage.TabIndex = 78;
            Label_Homepage.Text = "Homepage";
            Label_Homepage.Click += Label_Homepage_Click;
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.BorderStyle = BorderStyle.Fixed3D;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.Location = new Point(830, 145);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Size = new Size(165, 27);
            Label_ManageAccount.TabIndex = 77;
            Label_ManageAccount.Text = "Manage Account";
            // 
            // Label_AddRecord
            // 
            Label_AddRecord.AutoSize = true;
            Label_AddRecord.BorderStyle = BorderStyle.Fixed3D;
            Label_AddRecord.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_AddRecord.Location = new Point(519, 145);
            Label_AddRecord.Name = "Label_AddRecord";
            Label_AddRecord.Size = new Size(143, 27);
            Label_AddRecord.TabIndex = 76;
            Label_AddRecord.Text = "Add to Record";
            Label_AddRecord.Click += Label_AddRecord_Click;
            // 
            // Label_Appointment
            // 
            Label_Appointment.AutoSize = true;
            Label_Appointment.BackColor = SystemColors.Control;
            Label_Appointment.BorderStyle = BorderStyle.Fixed3D;
            Label_Appointment.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Appointment.ForeColor = SystemColors.ControlText;
            Label_Appointment.Location = new Point(668, 145);
            Label_Appointment.Name = "Label_Appointment";
            Label_Appointment.Size = new Size(156, 27);
            Label_Appointment.TabIndex = 75;
            Label_Appointment.Text = "History Records";
            Label_Appointment.Click += Label_Appointment_Click;
            // 
            // Label_Username
            // 
            Label_Username.AutoSize = true;
            Label_Username.Font = new Font("Sitka Subheading", 27.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Label_Username.Location = new Point(218, 78);
            Label_Username.Name = "Label_Username";
            Label_Username.Size = new Size(268, 53);
            Label_Username.TabIndex = 74;
            Label_Username.Text = "@GMAIL.COM";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Subheading", 36F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.Location = new Point(221, 9);
            label3.Name = "label3";
            label3.Size = new Size(286, 69);
            label3.TabIndex = 73;
            label3.Text = "WELCOME!";
            // 
            // TextBox_ChangeEmail
            // 
            TextBox_ChangeEmail.BackColor = SystemColors.Window;
            TextBox_ChangeEmail.Enabled = false;
            TextBox_ChangeEmail.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            TextBox_ChangeEmail.ForeColor = SystemColors.WindowText;
            TextBox_ChangeEmail.Location = new Point(401, 277);
            TextBox_ChangeEmail.Name = "TextBox_ChangeEmail";
            TextBox_ChangeEmail.Size = new Size(361, 39);
            TextBox_ChangeEmail.TabIndex = 71;
            TextBox_ChangeEmail.TextChanged += TextBox_ChangeEmail_TextChanged;
            // 
            // TextBox_ChangePassword
            // 
            TextBox_ChangePassword.BackColor = SystemColors.Window;
            TextBox_ChangePassword.Enabled = false;
            TextBox_ChangePassword.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            TextBox_ChangePassword.ForeColor = SystemColors.WindowText;
            TextBox_ChangePassword.Location = new Point(401, 442);
            TextBox_ChangePassword.Name = "TextBox_ChangePassword";
            TextBox_ChangePassword.Size = new Size(361, 39);
            TextBox_ChangePassword.TabIndex = 69;
            TextBox_ChangePassword.UseSystemPasswordChar = true;
            TextBox_ChangePassword.TextChanged += TextBox_ChangePassword_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Small", 12F, FontStyle.Bold);
            label2.Location = new Point(401, 331);
            label2.Name = "label2";
            label2.Size = new Size(58, 24);
            label2.TabIndex = 70;
            label2.Text = "PIN : ";
            // 
            // TextBox_ChangePin
            // 
            TextBox_ChangePin.BackColor = SystemColors.Window;
            TextBox_ChangePin.Enabled = false;
            TextBox_ChangePin.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            TextBox_ChangePin.ForeColor = SystemColors.WindowText;
            TextBox_ChangePin.Location = new Point(401, 360);
            TextBox_ChangePin.Name = "TextBox_ChangePin";
            TextBox_ChangePin.Size = new Size(361, 39);
            TextBox_ChangePin.TabIndex = 68;
            TextBox_ChangePin.TextChanged += TextBox_ChangePin_TextChanged;
            // 
            // ManageAccount
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 681);
            Controls.Add(Clinic_MainLogo);
            Controls.Add(Button_PassConfirm);
            Controls.Add(Button_PinConfirm);
            Controls.Add(Button_EmailConfirm);
            Controls.Add(pictureBox4);
            Controls.Add(Label_Role);
            Controls.Add(Label_Fullname);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox3);
            Controls.Add(label4);
            Controls.Add(label1);
            Controls.Add(Label_MemberSince);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_AddRecord);
            Controls.Add(Label_Appointment);
            Controls.Add(Label_Username);
            Controls.Add(label3);
            Controls.Add(TextBox_ChangeEmail);
            Controls.Add(TextBox_ChangePassword);
            Controls.Add(label2);
            Controls.Add(TextBox_ChangePin);
            Name = "ManageAccount";
            Text = "ManageAccount";
            ((System.ComponentModel.ISupportInitialize)Clinic_MainLogo).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox Clinic_MainLogo;
        private Button Button_PassConfirm;
        private Button Button_PinConfirm;
        private Button Button_EmailConfirm;
        private PictureBox pictureBox4;
        private Label Label_Role;
        private Label Label_Fullname;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
        private Label label4;
        private Label label1;
        private Label Label_MemberSince;
        private Label Label_Homepage;
        private Label Label_ManageAccount;
        private Label Label_AddRecord;
        private Label Label_Appointment;
        private Label Label_Username;
        private Label label3;
        private TextBox TextBox_ChangeEmail;
        private TextBox TextBox_ChangePassword;
        private Label label2;
        private TextBox TextBox_ChangePin;
    }
}