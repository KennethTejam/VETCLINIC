﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace Appointment1
{
    public partial class ExistingRecord : Form
    {
        public string username;
        public int userid;
        ContextMenuStrip contextMenu = new ContextMenuStrip();
        ContextMenuStrip recordMenu = new ContextMenuStrip();
        SqlConnection conn;
        PROCESSES process = new PROCESSES();
        Dictionary<string, int> itemAppIdMap;
        public ExistingRecord(int userid)
        {
            InitializeComponent();
            this.userid = userid;

            Label_Appointment.BackColor = Color.LightSkyBlue;
            if (userid < 0)
            {
                this.Hide();
                Login login = new Login(userid);
                login.Show();
            }
            else
            {
                string useremail = process.getUserEmail(userid);
                Label_Username.Text = useremail;

            }
            conn = process.getConnection();

            showContextMenu();
            txtSearch.TextChanged += (sender, e) => LoadRecords();
            cboPet.SelectedIndexChanged += cboPet_SelectedIndexChanged;

        }

        public void LoadRecords()
        {
            string searchText = txtSearch.Text.Trim();

            process.Search(searchText, cboPet, out itemAppIdMap);
        }

        private void cboPet_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedItem = cboPet.SelectedItem.ToString();
            DateTime today = DateTime.Today;

            if (itemAppIdMap.TryGetValue(selectedItem, out int appid))
            {
                process.FetchDetailsByAppId(appid, out string breed, out DateTime birthday, out string gender, out string contactNo, out string email);

                int age = today.Year - birthday.Year;

                if (birthday > today.AddYears(-age))
                {
                    age--;

                }
                txtBreed.Text = $"{breed}";
                txtGender.Text = $"{gender}";
                txtContactNo.Text = $"{contactNo}";
                txtEmail.Text = $"{email}";
                txtAge.Text = $"{age}";

                btnBook.Enabled = true ;
            }
            else
            {
                MessageBox.Show("AppID not found for the selected item.");
            }
        }

        public void showContextMenu()
        {
            ToolStripMenuItem changepass = new ToolStripMenuItem("Manage Account");
            ToolStripMenuItem logoutItem = new ToolStripMenuItem("Logout");
            ToolStripMenuItem newrecord = new ToolStripMenuItem("New Patient");
            ToolStripMenuItem existingrecord = new ToolStripMenuItem("Existing Patient");
            contextMenu.Font = new Font("Arial", 15, FontStyle.Bold);
            recordMenu.Font = new Font("Arial", 15, FontStyle.Bold);
            contextMenu.Items.Add(changepass);
            contextMenu.Items.Add(logoutItem);
            recordMenu.Items.Add(newrecord);
            recordMenu.Items.Add(existingrecord);
            changepass.Click += (sender, e) =>
            {
                ManageAccount changepass = new ManageAccount(userid);
                changepass.Show();
                this.Hide();
            };
            logoutItem.Click += (sender, e) =>
            {
                userid = -1;
                Login login = new Login(userid);
                login.Show();
                this.Hide();
            };

            newrecord.Click += (sender, e) =>
            {
                AddRecord changepass = new AddRecord(userid);
                changepass.Show();
                this.Hide();
            };
            existingrecord.Click += (sender, e) =>
            {
                ExistingRecord changepass = new ExistingRecord(userid);
                changepass.Show();
                this.Hide();
            };

            Label_ManageAccount.ContextMenuStrip = contextMenu;
            Label_ManageAccount.MouseEnter += (sender, e) =>
            {
                contextMenu.Show(Label_ManageAccount, Label_ManageAccount.PointToClient(Cursor.Position));
            };

            Label_Appointment.ContextMenuStrip = recordMenu;
            Label_Appointment.MouseEnter += (sender, e) =>
            {
                recordMenu.Show(Label_Appointment, Label_Appointment.PointToClient(Cursor.Position));
            };
        }



        private void Label_History_Click(object sender, EventArgs e)
        {

            int userid = this.userid;
            HistoryRecordsPending history = new HistoryRecordsPending(userid);
            history.Show();
            this.Hide();

        }

        private void Label_Homepage_Click(object sender, EventArgs e)
        {

            string Username = username;
            Homepage homepage = new Homepage(userid);
            homepage.Show();
            this.Hide();

        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            itemAppIdMap.TryGetValue(cboPet.SelectedItem.ToString(), out int appid);
            process.Book(appid);
        }
    }
}