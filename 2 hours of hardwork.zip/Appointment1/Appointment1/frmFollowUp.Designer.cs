﻿namespace Appointment1
{
    partial class frmFollowUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnConfirm = new Button();
            cb1 = new CheckBox();
            cb2 = new CheckBox();
            cb3 = new CheckBox();
            cb4 = new CheckBox();
            cb5 = new CheckBox();
            cb10 = new CheckBox();
            cb9 = new CheckBox();
            cb8 = new CheckBox();
            cb7 = new CheckBox();
            cb6 = new CheckBox();
            SuspendLayout();
            // 
            // btnConfirm
            // 
            btnConfirm.Location = new Point(530, 402);
            btnConfirm.Name = "btnConfirm";
            btnConfirm.Size = new Size(94, 29);
            btnConfirm.TabIndex = 7;
            btnConfirm.Text = "confirm";
            btnConfirm.UseVisualStyleBackColor = true;
            btnConfirm.Click += btnConfirm_Click;
            // 
            // cb1
            // 
            cb1.AutoSize = true;
            cb1.Location = new Point(69, 87);
            cb1.Name = "cb1";
            cb1.Size = new Size(154, 24);
            cb1.TabIndex = 8;
            cb1.Text = "Distemper Vaccine";
            cb1.UseVisualStyleBackColor = true;
            // 
            // cb2
            // 
            cb2.AutoSize = true;
            cb2.Location = new Point(69, 117);
            cb2.Name = "cb2";
            cb2.Size = new Size(151, 24);
            cb2.TabIndex = 9;
            cb2.Text = "Parvovirus Vaccine";
            cb2.UseVisualStyleBackColor = true;
            // 
            // cb3
            // 
            cb3.AutoSize = true;
            cb3.Location = new Point(69, 147);
            cb3.Name = "cb3";
            cb3.Size = new Size(260, 24);
            cb3.TabIndex = 10;
            cb3.Text = "Bordetella (Kennel Cough) Vaccine";
            cb3.UseVisualStyleBackColor = true;
            // 
            // cb4
            // 
            cb4.AutoSize = true;
            cb4.Location = new Point(69, 177);
            cb4.Name = "cb4";
            cb4.Size = new Size(137, 24);
            cb4.TabIndex = 11;
            cb4.Text = "Dental Cleaning";
            cb4.UseVisualStyleBackColor = true;
            // 
            // cb5
            // 
            cb5.AutoSize = true;
            cb5.Location = new Point(69, 207);
            cb5.Name = "cb5";
            cb5.Size = new Size(136, 24);
            cb5.TabIndex = 12;
            cb5.Text = "Heartworm Test";
            cb5.UseVisualStyleBackColor = true;
            // 
            // cb10
            // 
            cb10.AutoSize = true;
            cb10.Location = new Point(69, 357);
            cb10.Name = "cb10";
            cb10.Size = new Size(129, 24);
            cb10.TabIndex = 17;
            cb10.Text = "Rabies Vaccine";
            cb10.UseVisualStyleBackColor = true;
            // 
            // cb9
            // 
            cb9.AutoSize = true;
            cb9.Location = new Point(69, 327);
            cb9.Name = "cb9";
            cb9.Size = new Size(109, 24);
            cb9.TabIndex = 16;
            cb9.Text = "Deworming";
            cb9.UseVisualStyleBackColor = true;
            // 
            // cb8
            // 
            cb8.AutoSize = true;
            cb8.Location = new Point(69, 297);
            cb8.Name = "cb8";
            cb8.Size = new Size(172, 24);
            cb8.TabIndex = 15;
            cb8.Text = "Leptospirosis Vaccine";
            cb8.UseVisualStyleBackColor = true;
            // 
            // cb7
            // 
            cb7.AutoSize = true;
            cb7.Location = new Point(69, 267);
            cb7.Name = "cb7";
            cb7.Size = new Size(191, 24);
            cb7.TabIndex = 14;
            cb7.Text = "Flea and Tick Prevention";
            cb7.UseVisualStyleBackColor = true;
            // 
            // cb6
            // 
            cb6.AutoSize = true;
            cb6.Location = new Point(69, 237);
            cb6.Name = "cb6";
            cb6.Size = new Size(178, 24);
            cb6.TabIndex = 13;
            cb6.Text = "Annual Wellness Exam";
            cb6.UseVisualStyleBackColor = true;
            // 
            // frmFollowUp
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(686, 470);
            Controls.Add(cb10);
            Controls.Add(cb9);
            Controls.Add(cb8);
            Controls.Add(cb7);
            Controls.Add(cb6);
            Controls.Add(cb5);
            Controls.Add(cb4);
            Controls.Add(cb3);
            Controls.Add(cb2);
            Controls.Add(cb1);
            Controls.Add(btnConfirm);
            Name = "frmFollowUp";
            Text = "Form4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnConfirm;
        private CheckBox cb1;
        private CheckBox cb2;
        private CheckBox cb3;
        private CheckBox cb4;
        private CheckBox cb5;
        private CheckBox cb10;
        private CheckBox cb9;
        private CheckBox cb8;
        private CheckBox cb7;
        private CheckBox cb6;
    }
}