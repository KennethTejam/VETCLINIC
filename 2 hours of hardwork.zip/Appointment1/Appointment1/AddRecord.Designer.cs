﻿namespace Appointment1
{
    partial class AddRecord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddRecord));
            Label_Homepage = new Label();
            Label_ManageAccount = new Label();
            Label_Appointment = new Label();
            Label_History = new Label();
            Label_Username = new Label();
            Label_Welcome = new Label();
            Clinic_MainLogo = new PictureBox();
            Label_ForgotPass = new Label();
            TextBox_Breed = new TextBox();
            TextBox_PetName = new TextBox();
            Button_AddToRecord = new Button();
            Label_Password = new Label();
            Label_Gender = new Label();
            Label_Mname = new Label();
            Label_ConfirmPass = new Label();
            label3 = new Label();
            Label_Email = new Label();
            Label_Fname = new Label();
            TextBox_Email = new TextBox();
            TextBox_ContactNumber = new TextBox();
            TextBox_Owner = new TextBox();
            RadioButton_Male = new RadioButton();
            RadioButton_Female = new RadioButton();
            dateTimePicker1 = new DateTimePicker();
            medpanel = new Panel();
            btnAdd = new Button();
            btnDelete = new Button();
            ((System.ComponentModel.ISupportInitialize)Clinic_MainLogo).BeginInit();
            SuspendLayout();
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = SystemColors.Control;
            Label_Homepage.BorderStyle = BorderStyle.Fixed3D;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = SystemColors.ControlText;
            Label_Homepage.Location = new Point(450, 193);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Size = new Size(140, 34);
            Label_Homepage.TabIndex = 21;
            Label_Homepage.Text = "Homepage";
            Label_Homepage.Click += Label_Homepage_Click;
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.BorderStyle = BorderStyle.Fixed3D;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.Location = new Point(941, 193);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Size = new Size(210, 34);
            Label_ManageAccount.TabIndex = 17;
            Label_ManageAccount.Text = "Manage Account";
            // 
            // Label_Appointment
            // 
            Label_Appointment.AutoSize = true;
            Label_Appointment.BorderStyle = BorderStyle.Fixed3D;
            Label_Appointment.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Appointment.Location = new Point(585, 193);
            Label_Appointment.Name = "Label_Appointment";
            Label_Appointment.Size = new Size(181, 34);
            Label_Appointment.TabIndex = 16;
            Label_Appointment.Text = "Add to Record";
            // 
            // Label_History
            // 
            Label_History.AutoSize = true;
            Label_History.BackColor = SystemColors.Control;
            Label_History.BorderStyle = BorderStyle.Fixed3D;
            Label_History.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_History.ForeColor = SystemColors.ControlText;
            Label_History.Location = new Point(755, 193);
            Label_History.Name = "Label_History";
            Label_History.Size = new Size(198, 34);
            Label_History.TabIndex = 15;
            Label_History.Text = "History Records";
            Label_History.Click += Label_History_Click;
            // 
            // Label_Username
            // 
            Label_Username.AutoSize = true;
            Label_Username.Font = new Font("Sitka Subheading", 27.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Label_Username.Location = new Point(245, 104);
            Label_Username.Name = "Label_Username";
            Label_Username.Size = new Size(339, 68);
            Label_Username.TabIndex = 14;
            Label_Username.Text = "@GMAIL.COM";
            // 
            // Label_Welcome
            // 
            Label_Welcome.AutoSize = true;
            Label_Welcome.Font = new Font("Sitka Subheading", 36F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Label_Welcome.Location = new Point(245, 12);
            Label_Welcome.Name = "Label_Welcome";
            Label_Welcome.Size = new Size(358, 87);
            Label_Welcome.TabIndex = 13;
            Label_Welcome.Text = "WELCOME!";
            // 
            // Clinic_MainLogo
            // 
            Clinic_MainLogo.Image = (Image)resources.GetObject("Clinic_MainLogo.Image");
            Clinic_MainLogo.Location = new Point(9, 29);
            Clinic_MainLogo.Margin = new Padding(3, 4, 3, 4);
            Clinic_MainLogo.Name = "Clinic_MainLogo";
            Clinic_MainLogo.Size = new Size(187, 200);
            Clinic_MainLogo.SizeMode = PictureBoxSizeMode.Zoom;
            Clinic_MainLogo.TabIndex = 12;
            Clinic_MainLogo.TabStop = false;
            // 
            // Label_ForgotPass
            // 
            Label_ForgotPass.AutoSize = true;
            Label_ForgotPass.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_ForgotPass.Location = new Point(15, 625);
            Label_ForgotPass.Name = "Label_ForgotPass";
            Label_ForgotPass.Size = new Size(113, 37);
            Label_ForgotPass.TabIndex = 37;
            Label_ForgotPass.Text = "EMAIL: ";
            // 
            // TextBox_Breed
            // 
            TextBox_Breed.BackColor = SystemColors.Window;
            TextBox_Breed.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            TextBox_Breed.Location = new Point(275, 367);
            TextBox_Breed.Margin = new Padding(3, 0, 3, 4);
            TextBox_Breed.Multiline = true;
            TextBox_Breed.Name = "TextBox_Breed";
            TextBox_Breed.Size = new Size(295, 40);
            TextBox_Breed.TabIndex = 29;
            TextBox_Breed.TextChanged += TextBox_Breed_TextChanged;
            // 
            // TextBox_PetName
            // 
            TextBox_PetName.BackColor = SystemColors.Window;
            TextBox_PetName.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            TextBox_PetName.Location = new Point(275, 297);
            TextBox_PetName.Margin = new Padding(3, 0, 3, 4);
            TextBox_PetName.Multiline = true;
            TextBox_PetName.Name = "TextBox_PetName";
            TextBox_PetName.Size = new Size(295, 40);
            TextBox_PetName.TabIndex = 28;
            TextBox_PetName.TextChanged += TextBox_PetName_TextChanged;
            // 
            // Button_AddToRecord
            // 
            Button_AddToRecord.Enabled = false;
            Button_AddToRecord.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Button_AddToRecord.Location = new Point(910, 795);
            Button_AddToRecord.Margin = new Padding(3, 4, 3, 4);
            Button_AddToRecord.Name = "Button_AddToRecord";
            Button_AddToRecord.Size = new Size(216, 100);
            Button_AddToRecord.TabIndex = 39;
            Button_AddToRecord.Text = "ADD TO RECORD";
            Button_AddToRecord.UseVisualStyleBackColor = true;
            Button_AddToRecord.Click += Button_AddToRecord_Click;
            // 
            // Label_Password
            // 
            Label_Password.AutoSize = true;
            Label_Password.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Password.Location = new Point(838, 261);
            Label_Password.Name = "Label_Password";
            Label_Password.Size = new Size(361, 37);
            Label_Password.TabIndex = 40;
            Label_Password.Text = "NOTE: (MEDICAL HISTORY)";
            // 
            // Label_Gender
            // 
            Label_Gender.AutoSize = true;
            Label_Gender.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Gender.Location = new Point(16, 503);
            Label_Gender.Name = "Label_Gender";
            Label_Gender.Size = new Size(218, 37);
            Label_Gender.TabIndex = 41;
            Label_Gender.Text = "OWNER NAME: ";
            // 
            // Label_Mname
            // 
            Label_Mname.AutoSize = true;
            Label_Mname.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Mname.Location = new Point(15, 365);
            Label_Mname.Name = "Label_Mname";
            Label_Mname.Size = new Size(107, 37);
            Label_Mname.TabIndex = 42;
            Label_Mname.Text = "BREED:";
            // 
            // Label_ConfirmPass
            // 
            Label_ConfirmPass.AutoSize = true;
            Label_ConfirmPass.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_ConfirmPass.Location = new Point(15, 564);
            Label_ConfirmPass.Name = "Label_ConfirmPass";
            Label_ConfirmPass.Size = new Size(285, 37);
            Label_ConfirmPass.TabIndex = 43;
            Label_ConfirmPass.Text = "CONTACT NUMBER:  ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold);
            label3.Location = new Point(158, 425);
            label3.Name = "label3";
            label3.Size = new Size(0, 50);
            label3.TabIndex = 44;
            // 
            // Label_Email
            // 
            Label_Email.AutoSize = true;
            Label_Email.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Email.Location = new Point(15, 439);
            Label_Email.Name = "Label_Email";
            Label_Email.Size = new Size(211, 37);
            Label_Email.TabIndex = 45;
            Label_Email.Text = "PET BIRTHDAY:";
            // 
            // Label_Fname
            // 
            Label_Fname.AutoSize = true;
            Label_Fname.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold);
            Label_Fname.Location = new Point(15, 304);
            Label_Fname.Name = "Label_Fname";
            Label_Fname.Size = new Size(158, 37);
            Label_Fname.TabIndex = 47;
            Label_Fname.Text = "PET NAME:";
            // 
            // TextBox_Email
            // 
            TextBox_Email.BackColor = SystemColors.Window;
            TextBox_Email.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            TextBox_Email.Location = new Point(275, 627);
            TextBox_Email.Margin = new Padding(3, 0, 3, 4);
            TextBox_Email.Multiline = true;
            TextBox_Email.Name = "TextBox_Email";
            TextBox_Email.Size = new Size(427, 40);
            TextBox_Email.TabIndex = 50;
            TextBox_Email.TextChanged += TextBox_Email_TextChanged;
            // 
            // TextBox_ContactNumber
            // 
            TextBox_ContactNumber.BackColor = SystemColors.Window;
            TextBox_ContactNumber.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            TextBox_ContactNumber.Location = new Point(275, 565);
            TextBox_ContactNumber.Margin = new Padding(3, 0, 3, 4);
            TextBox_ContactNumber.Multiline = true;
            TextBox_ContactNumber.Name = "TextBox_ContactNumber";
            TextBox_ContactNumber.Size = new Size(427, 40);
            TextBox_ContactNumber.TabIndex = 49;
            TextBox_ContactNumber.TextChanged += TextBox_ContactNumber_TextChanged;
            // 
            // TextBox_Owner
            // 
            TextBox_Owner.BackColor = SystemColors.Window;
            TextBox_Owner.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            TextBox_Owner.Location = new Point(275, 504);
            TextBox_Owner.Margin = new Padding(3, 0, 3, 4);
            TextBox_Owner.Multiline = true;
            TextBox_Owner.Name = "TextBox_Owner";
            TextBox_Owner.Size = new Size(427, 40);
            TextBox_Owner.TabIndex = 48;
            TextBox_Owner.TextChanged += TextBox_Owner_TextChanged;
            // 
            // RadioButton_Male
            // 
            RadioButton_Male.AutoSize = true;
            RadioButton_Male.Font = new Font("Microsoft Sans Serif", 14.25F);
            RadioButton_Male.Location = new Point(597, 308);
            RadioButton_Male.Margin = new Padding(3, 4, 3, 4);
            RadioButton_Male.Name = "RadioButton_Male";
            RadioButton_Male.Size = new Size(87, 33);
            RadioButton_Male.TabIndex = 52;
            RadioButton_Male.Text = "Male";
            RadioButton_Male.UseVisualStyleBackColor = true;
            RadioButton_Male.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // RadioButton_Female
            // 
            RadioButton_Female.AutoSize = true;
            RadioButton_Female.Font = new Font("Microsoft Sans Serif", 14.25F);
            RadioButton_Female.Location = new Point(597, 367);
            RadioButton_Female.Margin = new Padding(3, 4, 3, 4);
            RadioButton_Female.Name = "RadioButton_Female";
            RadioButton_Female.Size = new Size(116, 33);
            RadioButton_Female.TabIndex = 53;
            RadioButton_Female.TabStop = true;
            RadioButton_Female.Text = "Female";
            RadioButton_Female.UseVisualStyleBackColor = true;
            RadioButton_Female.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold);
            dateTimePicker1.Location = new Point(275, 439);
            dateTimePicker1.Margin = new Padding(3, 4, 3, 4);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(427, 37);
            dateTimePicker1.TabIndex = 54;
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // medpanel
            // 
            medpanel.AutoScroll = true;
            medpanel.Location = new Point(775, 326);
            medpanel.Name = "medpanel";
            medpanel.Size = new Size(392, 395);
            medpanel.TabIndex = 57;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(982, 727);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(94, 29);
            btnAdd.TabIndex = 58;
            btnAdd.Text = "add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(838, 727);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 29);
            btnDelete.TabIndex = 59;
            btnDelete.Text = "delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // AddRecord
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1216, 908);
            Controls.Add(btnDelete);
            Controls.Add(btnAdd);
            Controls.Add(medpanel);
            Controls.Add(dateTimePicker1);
            Controls.Add(RadioButton_Female);
            Controls.Add(RadioButton_Male);
            Controls.Add(TextBox_Email);
            Controls.Add(TextBox_ContactNumber);
            Controls.Add(TextBox_Owner);
            Controls.Add(Label_ForgotPass);
            Controls.Add(TextBox_Breed);
            Controls.Add(TextBox_PetName);
            Controls.Add(Button_AddToRecord);
            Controls.Add(Label_Password);
            Controls.Add(Label_Gender);
            Controls.Add(Label_Mname);
            Controls.Add(Label_ConfirmPass);
            Controls.Add(label3);
            Controls.Add(Label_Email);
            Controls.Add(Label_Fname);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_Appointment);
            Controls.Add(Label_History);
            Controls.Add(Label_Username);
            Controls.Add(Label_Welcome);
            Controls.Add(Clinic_MainLogo);
            Margin = new Padding(3, 4, 3, 4);
            Name = "AddRecord";
            Text = "Form1";
            Load += AddRecord_Load;
            ((System.ComponentModel.ISupportInitialize)Clinic_MainLogo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label Label_Homepage;
        private Label Label_ManageAccount;
        private Label Label_Appointment;
        private Label Label_History;
        private Label Label_Username;
        private Label Label_Welcome;
        private PictureBox Clinic_MainLogo;
        private Label Label_ForgotPass;
        private TextBox TextBox_Breed;
        private TextBox TextBox_PetName;
        private Button Button_AddToRecord;
        private Label Label_Password;
        private Label Label_Gender;
        private Label Label_Mname;
        private Label Label_ConfirmPass;
        private Label label3;
        private Label Label_Email;
        private Label Label_Fname;
        private TextBox TextBox_Email;
        private TextBox TextBox_ContactNumber;
        private TextBox TextBox_Owner;
        private RadioButton RadioButton_Male;
        private RadioButton RadioButton_Female;
        private DateTimePicker dateTimePicker1;
        private Panel medpanel;
        private Button btnAdd;
        private Button btnDelete;
    }
}