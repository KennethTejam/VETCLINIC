﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Appointment1
{
    public partial class frmVetHP : Form
    {

        PROCESSES process = new PROCESSES();
        SqlConnection conn;
        int userid;
        DateTime dateandtime;
        string query;
        string status;
        DateTime today = DateTime.Today;
        public frmVetHP(int userid)
        {
            this.userid = userid;
            InitializeComponent();

            if (userid < 0)
            {
                this.Hide();
                Login login = new Login(userid);
                login.Show();
            }
            else
            {
                string useremail = process.getUserEmail(userid);
                label1.Text = useremail;
            }

            Label_Homepage.BackColor = Color.LightBlue;
            conn = process.getConnection();
            query = @"
                WITH RankedAppointments AS (
                    SELECT 
                        a.appid, 
                        a.pname, 
                        a.oname, 
                        FORMAT(s.date, 'dddd, MMMM dd, yyyy') AS date, 
                        s.status,
                        ROW_NUMBER() OVER (
                            PARTITION BY a.appid, s.date 
                            ORDER BY 
                                CASE 
                                    WHEN s.status = 'Pending' THEN 1 
                                    ELSE 2 
                                END
                        ) AS RowNum
                    FROM 
                        appointments a
                    INNER JOIN 
                        schedule s ON a.appid = s.appid
                    WHERE 
                        CAST(s.date AS DATE) = CAST(GETDATE() AS DATE)
                )
                SELECT 
                    appid, 
                    pname, 
                    oname, 
                    date, 
                    status
                FROM 
                    RankedAppointments
                WHERE 
                    RowNum = 1
                ORDER BY 
                    appid;
            ";

            LoadPendingAppointments();

        }

        private void LoadPendingAppointments()
        {
            dateandtime = monthCalendar1.SelectionRange.Start;
            pAppointment.Controls.Clear();

            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    cmd.Parameters.AddWithValue("@dateandtime", dateandtime);
                    SqlDataReader reader = cmd.ExecuteReader();

                    int i = 0;
                    while (reader.Read())
                    {

                        Label lblAppointment = new Label();

                        status = reader["status"].ToString();
                        string date = reader["date"].ToString();

                        lblAppointment.Text = $"Pet: {reader["pname"]}\nOwner: {reader["oname"]}\nTime: {reader["date"]}";

                        lblAppointment.AutoSize = true;
                        lblAppointment.Location = new Point(10, 10 + (i * 90));


                        int appID = Convert.ToInt32(reader["appID"]);
                        lblAppointment.Click += (sender, e) =>
                        {
                            MessageBox.Show($"Opening appointment with appID: {appID}");
                            MessageBox.Show($"Status: {status}");
                            OpenPatientInfoForm(appID, date);

                        };




                        pAppointment.Controls.Add(lblAppointment);

                        i++;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading appointments: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void OpenPatientInfoForm(int appID, string date)
        {
            frmAppointments apprecord = new frmAppointments(appID, date);
            apprecord.Show();

        }

        private void Label_History_Click(object sender, EventArgs e)
        {
            frmVetPending patientInfoForm = new frmVetPending(userid);
            patientInfoForm.Show();
            this.Hide();
        }

        private void Label_ManageAccount_Click(object sender, EventArgs e)
        {
            frmManageAccount patientInfoForm = new frmManageAccount(userid);
            patientInfoForm.Show();
            this.Hide();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            query = @"
        WITH RankedAppointments AS (
            SELECT 
                a.appid, 
                a.pname, 
                a.oname, 
                FORMAT(s.date, 'dddd, MMMM dd, yyyy') AS date, 
                s.status,
                ROW_NUMBER() OVER (
                    PARTITION BY a.appid, s.date 
                    ORDER BY 
                        CASE 
                            WHEN s.status = 'Pending' THEN 1 
                            ELSE 2 
                        END
                ) AS RowNum
            FROM 
                appointments a
            INNER JOIN 
                schedule s ON a.appid = s.appid
            WHERE 
                CAST(s.date AS DATE) = CAST(@dateandtime AS DATE)
        )
        SELECT 
            appid, 
            pname, 
            oname, 
            date, 
            status
        FROM 
            RankedAppointments
        WHERE 
            RowNum = 1
        ORDER BY 
            appid;
    ";

            LoadPendingAppointments();
        }

    }
}
