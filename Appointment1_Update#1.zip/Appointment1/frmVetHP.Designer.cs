﻿namespace Appointment1
{
    partial class frmVetHP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVetHP));
            pAppointment = new Panel();
            Label_Homepage = new Label();
            Label_ManageAccount = new Label();
            Label_History = new Label();
            label1 = new Label();
            label2 = new Label();
            Clinic_MainLogo = new PictureBox();
            monthCalendar1 = new MonthCalendar();
            Label_HistoryText = new Label();
            ((System.ComponentModel.ISupportInitialize)Clinic_MainLogo).BeginInit();
            SuspendLayout();
            // 
            // pAppointment
            // 
            pAppointment.AutoScroll = true;
            pAppointment.Location = new Point(286, 244);
            pAppointment.Margin = new Padding(3, 2, 3, 2);
            pAppointment.Name = "pAppointment";
            pAppointment.Size = new Size(338, 304);
            pAppointment.TabIndex = 2;
            // 
            // Label_Homepage
            // 
            Label_Homepage.AutoSize = true;
            Label_Homepage.BackColor = SystemColors.Control;
            Label_Homepage.BorderStyle = BorderStyle.Fixed3D;
            Label_Homepage.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_Homepage.ForeColor = SystemColors.ControlText;
            Label_Homepage.Location = new Point(586, 162);
            Label_Homepage.Name = "Label_Homepage";
            Label_Homepage.Size = new Size(112, 27);
            Label_Homepage.TabIndex = 14;
            Label_Homepage.Text = "Homepage";
            // 
            // Label_ManageAccount
            // 
            Label_ManageAccount.AutoSize = true;
            Label_ManageAccount.BorderStyle = BorderStyle.Fixed3D;
            Label_ManageAccount.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_ManageAccount.Location = new Point(886, 162);
            Label_ManageAccount.Name = "Label_ManageAccount";
            Label_ManageAccount.Size = new Size(165, 27);
            Label_ManageAccount.TabIndex = 13;
            Label_ManageAccount.Text = "Manage Account";
            Label_ManageAccount.Click += Label_ManageAccount_Click;
            // 
            // Label_History
            // 
            Label_History.AutoSize = true;
            Label_History.BorderStyle = BorderStyle.Fixed3D;
            Label_History.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold);
            Label_History.Location = new Point(714, 162);
            Label_History.Name = "Label_History";
            Label_History.Size = new Size(141, 27);
            Label_History.TabIndex = 12;
            Label_History.Text = "Appointments";
            Label_History.Click += Label_History_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Subheading", 27.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(217, 78);
            label1.Name = "label1";
            label1.Size = new Size(268, 53);
            label1.TabIndex = 35;
            label1.Text = "@GMAIL.COM";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Subheading", 36F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.Location = new Point(217, 9);
            label2.Name = "label2";
            label2.Size = new Size(286, 69);
            label2.TabIndex = 34;
            label2.Text = "WELCOME!";
            // 
            // Clinic_MainLogo
            // 
            Clinic_MainLogo.Image = (Image)resources.GetObject("Clinic_MainLogo.Image");
            Clinic_MainLogo.Location = new Point(42, 22);
            Clinic_MainLogo.Name = "Clinic_MainLogo";
            Clinic_MainLogo.Size = new Size(164, 150);
            Clinic_MainLogo.SizeMode = PictureBoxSizeMode.Zoom;
            Clinic_MainLogo.TabIndex = 33;
            Clinic_MainLogo.TabStop = false;
            // 
            // monthCalendar1
            // 
            monthCalendar1.Location = new Point(42, 260);
            monthCalendar1.Name = "monthCalendar1";
            monthCalendar1.TabIndex = 37;
            monthCalendar1.TodayDate = new DateTime(2024, 11, 13, 0, 0, 0, 0);
            monthCalendar1.DateChanged += monthCalendar1_DateChanged;
            // 
            // Label_HistoryText
            // 
            Label_HistoryText.AutoSize = true;
            Label_HistoryText.Font = new Font("Sitka Subheading", 27.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Label_HistoryText.Location = new Point(286, 189);
            Label_HistoryText.Name = "Label_HistoryText";
            Label_HistoryText.Size = new Size(306, 53);
            Label_HistoryText.TabIndex = 36;
            Label_HistoryText.Text = "Daily Dashboard";
            Label_HistoryText.Visible = false;
            // 
            // frmVetHP
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 681);
            Controls.Add(monthCalendar1);
            Controls.Add(Label_HistoryText);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(Clinic_MainLogo);
            Controls.Add(Label_Homepage);
            Controls.Add(Label_ManageAccount);
            Controls.Add(Label_History);
            Controls.Add(pAppointment);
            Margin = new Padding(3, 2, 3, 2);
            Name = "frmVetHP";
            Text = "Hompage";
            ((System.ComponentModel.ISupportInitialize)Clinic_MainLogo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pAppointment;
        private Label Label_Homepage;
        private Label Label_ManageAccount;
        private Label Label_History;
        private Label label1;
        private Label label2;
        private PictureBox Clinic_MainLogo;
        private MonthCalendar monthCalendar1;
        private Label Label_HistoryText;
    }
}