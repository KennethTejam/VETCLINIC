﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Appointment1
{
    public partial class frmVetPending : Form
    {
        PROCESSES process = new PROCESSES();
        SqlConnection conn;
        string query;

        int userid;
        public frmVetPending(int userid)
        {

            this.userid = userid;
            InitializeComponent();
            conn = process.getConnection();
            Label_History.BackColor = Color.LightBlue;

            cbSort.DropDownStyle = ComboBoxStyle.DropDownList;
            cbSort.Items.Add("Date ↑");
            cbSort.Items.Add("Date ↓");
            cbSort.SelectedIndex = 0;
            txtSearch.PlaceholderText = "Enter name";

            if (userid < 0)
            {
                this.Hide();
                Login login = new Login(userid);
                login.Show();
            }
            else
            {
                string useremail = process.getUserEmail(userid);
                Label_Username.Text = useremail;
            }



            query = @"
        SELECT appID, pname AS PetName, oname AS OwnerName, 
               CONVERT(VARCHAR, apptime, 100) AS AppointmentTime
        FROM Appointments  
        WHERE userid=@userid";
            LoadPendingAppointments(query);
            cbSort.SelectedIndexChanged += (sender, e) => LoadPendingAppointments(query);
            txtSearch.TextChanged += (sender, e) => LoadPendingAppointments(query);
        }

        private void LoadPendingAppointments(string query)
        {
            string searchText = txtSearch.Text.Trim();


            if (!string.IsNullOrEmpty(searchText))
            {
                query += " AND (pname LIKE @searchText OR oname LIKE @searchText)";
            }

            if (cbSort.SelectedItem.ToString() == "Date ↓")
            {
                query += " ORDER BY apptime DESC";
            }
            else
            {
                query += " ORDER BY apptime ASC";
            }

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@userid", userid);

                if (!string.IsNullOrEmpty(searchText))
                {
                    cmd.Parameters.AddWithValue("@searchText", "%" + searchText + "%");
                }

                SqlDataReader reader = cmd.ExecuteReader();
                pAppointment.Controls.Clear();

                int i = 0;
                while (reader.Read())
                {
                    Label lblAppointment = new Label
                    {
                        Text = $"Pet: {reader["PetName"]}\nOwner: {reader["OwnerName"]}\nTime: {reader["AppointmentTime"]}",
                        AutoSize = true,
                        Location = new Point(10, 10 + (i * 90))
                    };

                    int appID = Convert.ToInt32(reader["appID"]);
                    lblAppointment.Click += (sender, e) => OpenPatientInfoForm(appID);

                    pAppointment.Controls.Add(lblAppointment);
                    i++;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading appointments: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }


        private void OpenPatientInfoForm(int appID)
        {
            frmAppRecord patientInfoForm = new frmAppRecord(appID);
            patientInfoForm.Show();
        }

        private void lblDone_Click(object sender, EventArgs e)
        {
            lblPending.BackColor = Color.White;
            lblDone.BackColor = Color.LightBlue;
            query = @"
                SELECT appID, pname AS PetName, oname AS OwnerName, 
                       CONVERT(VARCHAR, apptime, 100) AS AppointmentTime
                FROM Appointments  
                WHERE status = 'Done' AND userid = @userid";
            LoadPendingAppointments(query);
        }

        private void Label_Homepage_Click(object sender, EventArgs e)
        {
            frmVetHP patientInfoForm = new frmVetHP(userid);
            patientInfoForm.Show();
            this.Hide();
        }

        private void Label_ManageAccount_Click(object sender, EventArgs e)
        {
            frmManageAccount patientInfoForm = new frmManageAccount(userid);
            patientInfoForm.Show();
            this.Hide();
        }

        private void lblPending_Click(object sender, EventArgs e)
        {
            lblPending.BackColor = Color.LightBlue;
            lblDone.BackColor = Color.White;
             query = @"
                SELECT appID, pname AS PetName, oname AS OwnerName, 
                       CONVERT(VARCHAR, apptime, 100) AS AppointmentTime
                FROM Appointments  
                WHERE status = 'Pending' AND userid = @userid";
            LoadPendingAppointments(query);
        }
    }
}
